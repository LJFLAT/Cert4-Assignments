﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace InsuranceInterface.Data_Access_Layer
{
    public class ConnectionManager
    {
        //Code to connect the database throughout the program
        public static SqlConnection DatabaseConnection()
        {
            string connection = "Data Source=MSI\\SQLEXPRESS;Initial Catalog=Acme;User ID=sa;Password=administration";
            SqlConnection conn = new SqlConnection(connection);
            return conn;
        }
    }
}
