﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceInterface.Business_Logic_Layer
{
    class Products
    {
        private int _productID, _productTypeID;
        private string _productName, _productType;
        private decimal _yearlyPremium;

        public int ProductID
        {
            get { return _productID; }
            set { _productID = value; }
        }

        public int ProductTypeID
        {
            get { return _productTypeID;}
            set { _productTypeID = value; }
        }

        public string ProductType
        {
            get { return _productType; }
            set { _productType = value; }
        }

        public string ProductName
        {
            get { return _productName; }
            set { _productName = value; }
        }

        public decimal YearlyPremium
        {
            get { return _yearlyPremium; }
            set { _yearlyPremium = value; }
        }

        public Products() { }

        public Products(int productID, int productTypeID, string productType, string productName, decimal yearlyPremium)
        {
            ProductID = productID;
            ProductTypeID = productTypeID;
            ProductType = productType;
            ProductName = productName;
            YearlyPremium = yearlyPremium;
        }

        public string CheckValues(string item, string valueCheck)
        {
            string errorMessage = "";
            if (valueCheck.Any(char.IsLetter)) //found this solution online https://stackoverflow.com/questions/18251875/in-c-how-to-check-whether-a-string-contains-an-integer
            {
                errorMessage = item + " contains a letter.\n"; //Concatenate this to the correct item being checked
                return errorMessage;
            }
            try
            {
                if (decimal.Parse(valueCheck) < 0.00m)
                {
                    errorMessage = item + " cannot be a negative number.";
                }
            }
            catch (Exception ex)
            {
                ex.ToString(); //used this to remove the warning
                errorMessage = item + " is not entered correctly.";
            }
            return errorMessage;
        }
    }
}
