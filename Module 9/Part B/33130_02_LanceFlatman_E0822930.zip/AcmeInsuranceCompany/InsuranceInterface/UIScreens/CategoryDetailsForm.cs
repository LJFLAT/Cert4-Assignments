﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmCategoryDetailsForm : Form
    {
        Categories category = new Categories();

        public frmCategoryDetailsForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //before leaving the details screen - check to see if the information has changed - verify with user they wish to exit without saving?
            if (!GlobalVariables.CategoryAdd) //only check when information is being updated
            {
                if (!CategoryChangedDetails())
                {
                    DialogResult dialogResult = MessageBox.Show("Information has changed. Are you sure you wish to exit?",
                        "Exit without saving", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.No)
                    {
                        return;
                    }
                }
            }
            GlobalVariables.CategoryAdd = true;
            frmCategoryMaintenance viewForm = new frmCategoryMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void FrmCategoryDetailsForm_Load(object sender, EventArgs e)
        {
            if (GlobalVariables.CategoryAdd)
            {
                //load a clear data form
                btnVariousFunctions.Text = "Add Category:"; //change the button to reflect the user action
            }
            else
            {
                //load the existing data into the form as a class object
                btnVariousFunctions.Text = "Update Category:";  //change the button to reflect the user action
                LoadCategoryDetails();
            }
        }

        private void BtnVariousFunctions_Click(object sender, EventArgs e)
        {
            if(!CheckFields()) //a check to see if the entered fields are valid
            {
                return;
            }

            //Code for confirmation of a new category
            string confirmMessage = "Do you wish to update this category?";
            string confirmTitle = "Update Category";
            if (GlobalVariables.CategoryAdd)
            {
                confirmMessage = "Do you wish to add a new category?";
                confirmTitle = "Add Category";
            }
            DialogResult userResponse = MessageBox.Show(confirmMessage, confirmTitle, MessageBoxButtons.YesNo);

            if (userResponse == DialogResult.Yes)
            {
                //Code to add or update the category
                AddUpdateCategory();
            }
            else
            {
                return;
            }

            GlobalVariables.CategoryAdd = true;
            frmCategoryMaintenance viewForm = new frmCategoryMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void LoadCategoryDetails()
        {
            string selectQuery = "sp_Categories_GetCategories";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter categoryId = cmd.Parameters.AddWithValue("@CategoryID", GlobalVariables.SelectedCategory);

                rdr = cmd.ExecuteReader();
                rdr.Read();

                //populate category instance for verifying changes
                category.CategoryID = int.Parse(rdr["CategoryID"].ToString());
                category.Category = rdr["Category"].ToString();

                //populate form
                txtCategoryID.Text = rdr["CategoryID"].ToString();
                txtCategory.Text = rdr["Category"].ToString();

                rdr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("unsuccessful " + ex);
            }
        }

        private void AddUpdateCategory()
        {
            if (!GlobalVariables.CategoryAdd)
            {
                category.CategoryID = int.Parse(txtCategoryID.Text);
            }
            category.Category = txtCategory.Text;

            string databaseAction;
            if (GlobalVariables.CategoryAdd)
            {
                databaseAction = "sp_Categories_CreateCategory";
            }
            else
            {
                databaseAction = "sp_Categories_UpdateCategory";
            }

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            conn.Open();

            SqlCommand cmd = new SqlCommand(databaseAction, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            if (!GlobalVariables.CategoryAdd)
            {
                cmd.Parameters.AddWithValue("@CategoryID", category.CategoryID);
            }
            cmd.Parameters.AddWithValue("@Category", category.Category);
            if (GlobalVariables.CategoryAdd)
            {
                cmd.Parameters.AddWithValue("@NewCategoryID", SqlDbType.Int).Direction = ParameterDirection.Output;
            }
            cmd.Transaction = conn.BeginTransaction();
            cmd.ExecuteNonQuery();
            cmd.Transaction.Commit();

            conn.Close();
        }

        private bool CategoryChangedDetails()
        {
            if (!category.Category.Equals(txtCategory.Text))
            {
                return false;
            }
            return true;
        }

        private bool CheckFields()
        {
            string errorMessages = "";
            errorMessages += GlobalVariables.FieldBlank("Category", txtCategory.Text);
            if (errorMessages.Length > 0)
            {
                MessageBox.Show("The following information is incorrect:\n\n" + errorMessages,
                    "Incorrect Category Information");
                return false;
            }
            return true; //entered information is technically valid
        }
    }
}
