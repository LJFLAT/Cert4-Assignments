﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmProductMaintenance : Form
    {
        public frmProductMaintenance()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            //Clear and reset the filters
            GlobalVariables.ProductFilterReset();

            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void BtnSearchFilterProducts_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the product data - pressing the button clears 
            //the filter and resets the colour of the button.
            if (GlobalVariables.ProdSearchFilterSet)
            {
                btnSearchFilterProducts.Text = "Search / Filter Product:";
                btnSearchFilterProducts.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.ProductFilterReset();
                DisplayProducts();
            }
            else
            {
                frmProductsSearchForm viewForm = new frmProductsSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.ProdSearchFilterSet)
                {
                    btnSearchFilterProducts.Text = "Press to clear Product filter:";
                    btnSearchFilterProducts.BackColor = Color.LightSteelBlue;

                    //code to filter the products being displayed
                    DisplayProducts();
                }
            }
        }

        private void BtnDelectSelectedProduct_Click(object sender, EventArgs e)
        {
            //check to see if a product has been selected - otherwise advise user
            if (lvProductList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Product to Delete.");
                DisplayProducts();
                return;
            }

            GlobalVariables.SelectedProduct = int.Parse(lvProductList.SelectedItems[0].Text);

            //Code to check if the product has sales records already
            string checkQuery = "sp_Products_AllowDeleteProduct";
            SqlConnection deleteCheck = ConnectionManager.DatabaseConnection();


            // Start the TRANSACTION code from time of check - someone else might be interacting with the data.
            //similar code from Microsoft at https://docs.microsoft.com/en-us/dotnet/api/system.data.sqlclient.sqltransaction?view=netframework-4.8
            SqlTransaction transaction;

            try
            {
                //MS implementation displays the open and transaction commands outside the try/catch block
                //as you cannot use transaction.rollback in the catch area as it is seen as not being assigned if inside.
                deleteCheck.Open();
                SqlCommand cmd = deleteCheck.CreateCommand();
                transaction = deleteCheck.BeginTransaction();

                cmd.Connection = deleteCheck;
                cmd.Transaction = transaction;

                cmd.CommandText = checkQuery;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ProductID", GlobalVariables.SelectedProduct);
                cmd.Parameters.Add("@RecordCount", SqlDbType.Int);
                cmd.Parameters["@RecordCount"].Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();

                //similar reference to record count from https://blog.cloudboost.io/how-to-use-sql-output-parameters-in-stored-procedures-578e7c4ff188
                int recordCount = Convert.ToInt32(cmd.Parameters["@RecordCount"].Value);

                if (recordCount > 0)
                {
                    MessageBox.Show("Selected Product has sales history.\n\nThis product cannot be deleted.",
                        "Delete Product - Invalid");
                    transaction.Rollback();

                    deleteCheck.Dispose();
                    deleteCheck.Close();

                    DisplayProducts();
                    return;
                }

                string confirmMessage = "Product: " + lvProductList.SelectedItems[0].SubItems[2].Text + " " +
                    "\n\nDo you wish delete this Product?";

                DialogResult userResponse = MessageBox.Show(confirmMessage, "Delete Selected Product",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

                if (userResponse == DialogResult.Yes)
                {

                    string deleteQuery = "sp_Products_DeleteProduct";
                    cmd.CommandText = deleteQuery;

                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@ProductID", GlobalVariables.SelectedProduct);

                    cmd.ExecuteNonQuery();
                    cmd.Transaction.Commit();
                    //finish TRANSACTION after database has been altered
                }
                else
                {
                    transaction.Rollback();
                }
                deleteCheck.Close(); //if open was successful, then close the connection.
            }
            catch (Exception ex)
            {
                //transaction.rollback() - only works when open() and transaction are outside the try/catch block.
                deleteCheck.Close();
                MessageBox.Show("Unsuccessful " + ex);
            }

            //Code to refresh the view of the Product List
            DisplayProducts();
        }

        private void BtnAddProducts_Click(object sender, EventArgs e)
        {
            GlobalVariables.ProductAdd = true;
            GlobalVariables.SelectedProduct = 0;

            frmProductDetailsForm viewForm = new frmProductDetailsForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDisplayUpdateSelectedProduct_Click(object sender, EventArgs e)
        {
            //Check if a product has been selected from the list - otherwise advise the user
            if (lvProductList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Product to udpate.");
                return;
            }

            //Store the currently selected product to GlobalVariable.selectedProduct
            GlobalVariables.ProductAdd = false;
            GlobalVariables.SelectedProduct = int.Parse(lvProductList.SelectedItems[0].Text);

            frmProductDetailsForm viewForm = new frmProductDetailsForm();
            viewForm.Show();
            this.Hide();
        }

        private void FrmProductMaintenance_Load(object sender, EventArgs e)
        {
            GlobalVariables.CategoryAdd = true;
            DisplayProducts();
        }

        private void DisplayProducts()
        {
            lvProductList.Items.Clear();
            int recordCount = 0;
            lblNoRecordsToShow.Visible = false;

            string selectQuery = "SELECT " + GlobalVariables.ProductsDatabaseFields() + ", "
                + GlobalVariables.ProductTypesDatabaseFields() + " FROM Products " +
                "INNER JOIN ProductTypes ON Products.ProductTypeID = ProductTypes.ProductTypeID ";

            if (GlobalVariables.ProdSearchFilterSet)
            {
                selectQuery += "WHERE " + GlobalVariables.ProdFilter();
            }

            selectQuery += " ORDER BY ProductType, ProductName";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ProductID", 0);

                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    Products product = new Products(int.Parse(rdr["ProductID"].ToString()),
                        int.Parse(rdr["ProductTypeID"].ToString()), rdr["ProductType"].ToString(), rdr["ProductName"].ToString(),
                        decimal.Parse(rdr["YearlyPremium"].ToString()));
                    
                    //calculate the montly and fortnightly payments and hold as a string
                    string monthlyPremium = Math.Round((product.YearlyPremium / 12),2).ToString("C2");
                    string fortnightlyPremium = Math.Round((product.YearlyPremium / 26),2).ToString("C2");

                    ListViewItem lvi = new ListViewItem(product.ProductID.ToString());
                    lvi.SubItems.Add(product.ProductType);
                    lvi.SubItems.Add(product.ProductName);
                    lvi.SubItems.Add(product.YearlyPremium.ToString("C2"));
                    lvi.SubItems.Add(monthlyPremium);
                    lvi.SubItems.Add(fortnightlyPremium);
                    lvProductList.Items.Add(lvi);

                    recordCount++;
                }
                if (rdr != null)
                {
                    rdr.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unsuccessful " + ex);
            }

            if (recordCount == 0)
            {
                lblNoRecordsToShow.Visible = true;
            }
            return;
        }
    }
}
