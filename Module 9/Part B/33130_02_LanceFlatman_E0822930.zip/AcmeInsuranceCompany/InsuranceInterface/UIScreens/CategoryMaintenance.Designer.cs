﻿namespace InsuranceInterface.UIScreens
{
    partial class frmCategoryMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeleteSelectedCategory = new System.Windows.Forms.Button();
            this.btnDisplayUpdateCategory = new System.Windows.Forms.Button();
            this.btnAddCategory = new System.Windows.Forms.Button();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.lblNoRecordsToShow = new System.Windows.Forms.Label();
            this.lvCategoriesList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btnDeleteSelectedCategory
            // 
            this.btnDeleteSelectedCategory.Location = new System.Drawing.Point(435, 563);
            this.btnDeleteSelectedCategory.Name = "btnDeleteSelectedCategory";
            this.btnDeleteSelectedCategory.Size = new System.Drawing.Size(121, 41);
            this.btnDeleteSelectedCategory.TabIndex = 4;
            this.btnDeleteSelectedCategory.Text = "Delete Selected Category:";
            this.btnDeleteSelectedCategory.UseVisualStyleBackColor = true;
            this.btnDeleteSelectedCategory.Click += new System.EventHandler(this.BtnDeleteSelectedCategory_Click);
            // 
            // btnDisplayUpdateCategory
            // 
            this.btnDisplayUpdateCategory.Location = new System.Drawing.Point(281, 563);
            this.btnDisplayUpdateCategory.Name = "btnDisplayUpdateCategory";
            this.btnDisplayUpdateCategory.Size = new System.Drawing.Size(121, 41);
            this.btnDisplayUpdateCategory.TabIndex = 3;
            this.btnDisplayUpdateCategory.Text = "Display / Update Selected Category:";
            this.btnDisplayUpdateCategory.UseVisualStyleBackColor = true;
            this.btnDisplayUpdateCategory.Click += new System.EventHandler(this.BtnDisplayUpdateCategory_Click);
            // 
            // btnAddCategory
            // 
            this.btnAddCategory.Location = new System.Drawing.Point(127, 563);
            this.btnAddCategory.Name = "btnAddCategory";
            this.btnAddCategory.Size = new System.Drawing.Size(121, 41);
            this.btnAddCategory.TabIndex = 2;
            this.btnAddCategory.Text = "Add Category:";
            this.btnAddCategory.UseVisualStyleBackColor = true;
            this.btnAddCategory.Click += new System.EventHandler(this.BtnAddCategory_Click);
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 563);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 1;
            this.btnReturnToMainMenu.Text = "&Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // lblNoRecordsToShow
            // 
            this.lblNoRecordsToShow.AutoSize = true;
            this.lblNoRecordsToShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblNoRecordsToShow.Location = new System.Drawing.Point(148, 291);
            this.lblNoRecordsToShow.Name = "lblNoRecordsToShow";
            this.lblNoRecordsToShow.Size = new System.Drawing.Size(856, 31);
            this.lblNoRecordsToShow.TabIndex = 7;
            this.lblNoRecordsToShow.Text = "No categories to display - please try a different filter or add some data.";
            this.lblNoRecordsToShow.Visible = false;
            // 
            // lvCategoriesList
            // 
            this.lvCategoriesList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvCategoriesList.FullRowSelect = true;
            this.lvCategoriesList.GridLines = true;
            this.lvCategoriesList.Location = new System.Drawing.Point(12, 8);
            this.lvCategoriesList.MultiSelect = false;
            this.lvCategoriesList.Name = "lvCategoriesList";
            this.lvCategoriesList.Size = new System.Drawing.Size(1128, 549);
            this.lvCategoriesList.TabIndex = 8;
            this.lvCategoriesList.UseCompatibleStateImageBehavior = false;
            this.lvCategoriesList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Category ID";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Category Name";
            this.columnHeader2.Width = 200;
            // 
            // frmCategoryMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.lblNoRecordsToShow);
            this.Controls.Add(this.btnDeleteSelectedCategory);
            this.Controls.Add(this.btnDisplayUpdateCategory);
            this.Controls.Add(this.btnAddCategory);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.lvCategoriesList);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmCategoryMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Category Maintenance:";
            this.Load += new System.EventHandler(this.FrmCategoryMaintenance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnDeleteSelectedCategory;
        private System.Windows.Forms.Button btnDisplayUpdateCategory;
        private System.Windows.Forms.Button btnAddCategory;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.Label lblNoRecordsToShow;
        private System.Windows.Forms.ListView lvCategoriesList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
    }
}