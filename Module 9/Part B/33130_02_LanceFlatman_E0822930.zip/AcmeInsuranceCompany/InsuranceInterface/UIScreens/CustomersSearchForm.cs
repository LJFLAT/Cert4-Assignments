﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmCustomersSearchForm : Form
    {
        public frmCustomersSearchForm()
        {
            InitializeComponent();
        }

        private void BtnSetCustomerSearchCriteria_Click(object sender, EventArgs e)
        {
            //code to set the search / filter variables in the GlobalVariable Class
            GlobalVariables.CustSearchFilterSet = false;
            GlobalVariables.CustomerFilterReset();


            if (txtLastName.TextLength > 0)
            {
                GlobalVariables.CustSearchLastName = txtLastName.Text;
            }
            if (txtCategory.TextLength > 0)
            {
                GlobalVariables.CustSearchCategory = txtCategory.Text;
            }
            if (cbState.Text.Length > 0)
            {
                GlobalVariables.CustSearchState = cbState.Text;
            }
            if (txtPostcode.TextLength > 0)
            {
                GlobalVariables.CustSearchPostcode= txtPostcode.Text;
            }
            if (txtLastName.TextLength > 0 || txtCategory.TextLength > 0 || cbState.Text.Length > 0 || txtPostcode.TextLength > 0)
            {
                GlobalVariables.CustSearchFilterSet = true;
            }
            this.Close();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
