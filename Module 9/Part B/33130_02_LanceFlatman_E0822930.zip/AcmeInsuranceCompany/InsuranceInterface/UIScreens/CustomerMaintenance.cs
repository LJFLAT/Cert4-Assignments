﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using InsuranceInterface;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmCustomerMaintenance : Form
    {
        public frmCustomerMaintenance()
        {
            InitializeComponent();
        }

        private void frmCustomerMaintenance_Load(object sender, EventArgs e)
        {
            GlobalVariables.CustomerAdd = true;
            DisplayCustomers();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            //reset the filter variables
            GlobalVariables.CustomerFilterReset();

            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Close();
        }

        private void BtnAddCustomer_Click(object sender, EventArgs e)
        {
            //there is no selected customer information to pass
            GlobalVariables.CustomerAdd = true;
            GlobalVariables.SelectedCustomer = 0;

            frmCustomerDetailsForm viewForm = new frmCustomerDetailsForm();
            viewForm.Show();
            this.Hide();
        }
        private void BtnDisplayUpdateCustomer_Click(object sender, EventArgs e)
        {
            //Check if a customer has been selected from the list - otherwise advise the user
            if (lvCustomerList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Customer to udpate.");
                return;
            }

            //Store the currently selected customer to GlobalVariable.selectedCustomer
            GlobalVariables.CustomerAdd = false;
            GlobalVariables.SelectedCustomer = int.Parse(lvCustomerList.SelectedItems[0].Text);

            frmCustomerDetailsForm viewForm = new frmCustomerDetailsForm();
            viewForm.Show();
            this.Hide();
        }
        private void BtnDeleteSelectedCustomer_Click(object sender, EventArgs e)
        {
            //check to see if a customer has been selected - otherwise advise user
            if (lvCustomerList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Customer to Delete.");
                DisplayCustomers();
                return;
            }
           
            GlobalVariables.SelectedCustomer = int.Parse(lvCustomerList.SelectedItems[0].Text);

            //Code to check if the customer has sales records already
            string checkQuery = "sp_Customers_AllowDeleteCustomer";
            SqlConnection deleteCheck = ConnectionManager.DatabaseConnection();


            // Start the TRANSACTION code from time of check - someone else might be interacting with the data.
            //similar code from Microsoft at https://docs.microsoft.com/en-us/dotnet/api/system.data.sqlclient.sqltransaction?view=netframework-4.8
            SqlTransaction transaction;

            try
            {
                //MS implementation displays the open and transaction commands outside the try/catch block
                //as you cannot use transaction.rollback in the catch area as it is seen as not being assigned if inside.
                deleteCheck.Open();
                SqlCommand cmd = deleteCheck.CreateCommand();
                transaction = deleteCheck.BeginTransaction();

                cmd.Connection = deleteCheck;
                cmd.Transaction = transaction;

                cmd.CommandText = checkQuery;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CustomerID", GlobalVariables.SelectedCustomer);
                cmd.Parameters.Add("@RecordCount", SqlDbType.Int);
                cmd.Parameters["@RecordCount"].Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();

                //similar reference to record count from https://blog.cloudboost.io/how-to-use-sql-output-parameters-in-stored-procedures-578e7c4ff188
                int recordCount = Convert.ToInt32(cmd.Parameters["@RecordCount"].Value);

                if (recordCount>0)
                {
                    MessageBox.Show("Selected Customer has sales history.\n\nThis customer cannot be deleted.",
                        "Delete Customer - Invalid");
                    transaction.Rollback();

                    deleteCheck.Dispose();
                    deleteCheck.Close();

                    DisplayCustomers();
                    return;
                }

                string confirmMessage = "Customer: " + lvCustomerList.SelectedItems[0].SubItems[2].Text + " " + 
                    lvCustomerList.SelectedItems[0].SubItems[3].Text +"\n\nDo you wish delete this Customer?";

                DialogResult userResponse = MessageBox.Show(confirmMessage, "Delete Selected Customer", 
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

                if (userResponse == DialogResult.Yes)
                {

                    string deleteQuery = "sp_Customers_DeleteCustomer";
                    cmd.CommandText=deleteQuery;
                    //cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@CustomerID", GlobalVariables.SelectedCustomer);

                    cmd.ExecuteNonQuery();
                    cmd.Transaction.Commit();
                    //finish TRANSACTION after database has been altered
                }
                else
                {
                    transaction.Rollback();
                }
                deleteCheck.Close(); //if open was successful, then close the connection.
            }
            catch (Exception ex)
            {
                //transaction.rollback() - only works when open() and transaction are outside the try/catch block.
                deleteCheck.Close();
                MessageBox.Show("Unsuccessful " + ex);
            }

            //Code to refresh the view of the Customer List
            DisplayCustomers();           
        }

        private void BtnSearchFilterCustomer_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the customer data - pressing the button clears the filter and resets the colour of the button.
            if (GlobalVariables.CustSearchFilterSet)
            {
                btnSearchFilterCustomer.Text = "Search / Filter Customer:";
                btnSearchFilterCustomer.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.CustomerFilterReset();

                //re-display the customer list
                DisplayCustomers();

            }
            else
            {
                frmCustomersSearchForm viewForm = new frmCustomersSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.CustSearchFilterSet)
                {
                    btnSearchFilterCustomer.Text = "Press to clear Customer filter:";
                    btnSearchFilterCustomer.BackColor = Color.LightSteelBlue;

                    //code to filter the customer being displayed
                    DisplayCustomers();
                }
            }
        }

        private void DisplayCustomers()
        {
            lvCustomerList.Items.Clear();
            int recordCount = 0;
            lblNoRecordsToShow.Visible = false;

            string selectQuery;

            selectQuery = "SELECT " + GlobalVariables.CustomerDatabaseFields() + ", " + GlobalVariables.CategoryDatabaseFields()+ " ";
            selectQuery += "FROM Customers INNER JOIN Categories ON Customers.CategoryID = Categories.CategoryID ";

            if (GlobalVariables.CustSearchFilterSet)
            {
                selectQuery += "WHERE " + GlobalVariables.CustFilter();
            }

            selectQuery += " ORDER BY LastName";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    DateTime birthDate;
                    birthDate = DateTime.Parse(rdr["BirthDate"].ToString());

                    Customers customer = new Customers(int.Parse(rdr["CustomerID"].ToString()), int.Parse(rdr["CategoryID"].ToString()), 
                        rdr["Category"].ToString(), rdr["FirstName"].ToString(), rdr["LastName"].ToString(), rdr["Address"].ToString(),
                        rdr["Suburb"].ToString(), rdr["State"].ToString(), int.Parse(rdr["Postcode"].ToString()), 
                        rdr["Gender"].ToString(), birthDate);

                    ListViewItem lvi = new ListViewItem(customer.CustomerID.ToString());
                    lvi.SubItems.Add(customer.Category);
                    lvi.SubItems.Add(customer.FirstName);
                    lvi.SubItems.Add(customer.LastName);
                    lvi.SubItems.Add(customer.Address);
                    lvi.SubItems.Add(customer.Suburb);
                    lvi.SubItems.Add(customer.State);
                    lvi.SubItems.Add(customer.Postcode.ToString());
                    lvi.SubItems.Add(customer.BirthDate.ToString("dd/MM/yyyy"));
                    lvCustomerList.Items.Add(lvi);

                    recordCount++;
                }
                if (rdr != null)
                {
                    rdr.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unsuccessful " + ex);
            }

            if (recordCount == 0)
            {
                lblNoRecordsToShow.Visible = true;
            }
            return;
        }
    }
}
