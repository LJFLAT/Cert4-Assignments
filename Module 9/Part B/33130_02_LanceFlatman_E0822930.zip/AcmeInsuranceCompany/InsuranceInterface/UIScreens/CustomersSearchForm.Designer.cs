﻿namespace InsuranceInterface.UIScreens
{
    partial class frmCustomersSearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSetCustomerSearchCriteria = new System.Windows.Forms.Button();
            this.lblState = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblPostcode = new System.Windows.Forms.Label();
            this.txtPostcode = new System.Windows.Forms.TextBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.cbState = new System.Windows.Forms.ComboBox();
            this.txtCategory = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancel.Location = new System.Drawing.Point(12, 130);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(82, 41);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "&Cancel:";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // btnSetCustomerSearchCriteria
            // 
            this.btnSetCustomerSearchCriteria.Location = new System.Drawing.Point(127, 130);
            this.btnSetCustomerSearchCriteria.Name = "btnSetCustomerSearchCriteria";
            this.btnSetCustomerSearchCriteria.Size = new System.Drawing.Size(121, 41);
            this.btnSetCustomerSearchCriteria.TabIndex = 5;
            this.btnSetCustomerSearchCriteria.Text = "Set Customer Search Criteria:";
            this.btnSetCustomerSearchCriteria.UseVisualStyleBackColor = true;
            this.btnSetCustomerSearchCriteria.Click += new System.EventHandler(this.BtnSetCustomerSearchCriteria_Click);
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(9, 74);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(35, 13);
            this.lblState.TabIndex = 19;
            this.lblState.Text = "State:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(9, 14);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 18;
            this.lblLastName.Text = "Last Name:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(103, 11);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(379, 20);
            this.txtLastName.TabIndex = 0;
            // 
            // lblPostcode
            // 
            this.lblPostcode.AutoSize = true;
            this.lblPostcode.Location = new System.Drawing.Point(9, 104);
            this.lblPostcode.Name = "lblPostcode";
            this.lblPostcode.Size = new System.Drawing.Size(55, 13);
            this.lblPostcode.TabIndex = 21;
            this.lblPostcode.Text = "Postcode:";
            // 
            // txtPostcode
            // 
            this.txtPostcode.Location = new System.Drawing.Point(103, 101);
            this.txtPostcode.Name = "txtPostcode";
            this.txtPostcode.Size = new System.Drawing.Size(379, 20);
            this.txtPostcode.TabIndex = 3;
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(9, 44);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(52, 13);
            this.lblCategory.TabIndex = 24;
            this.lblCategory.Text = "Category:";
            // 
            // cbState
            // 
            this.cbState.Items.AddRange(new object[] {
            "WA",
            "ACT",
            "NSW",
            "VIC",
            "QLD",
            "SA",
            "TAS",
            "NT"});
            this.cbState.Location = new System.Drawing.Point(103, 71);
            this.cbState.MaxLength = 3;
            this.cbState.Name = "cbState";
            this.cbState.Size = new System.Drawing.Size(145, 21);
            this.cbState.TabIndex = 2;
            // 
            // txtCategory
            // 
            this.txtCategory.Location = new System.Drawing.Point(103, 41);
            this.txtCategory.Name = "txtCategory";
            this.txtCategory.Size = new System.Drawing.Size(379, 20);
            this.txtCategory.TabIndex = 1;
            // 
            // frmCustomersSearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 183);
            this.ControlBox = false;
            this.Controls.Add(this.txtCategory);
            this.Controls.Add(this.cbState);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.txtPostcode);
            this.Controls.Add(this.lblPostcode);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.btnSetCustomerSearchCriteria);
            this.Controls.Add(this.btnCancel);
            this.MaximumSize = new System.Drawing.Size(513, 222);
            this.MinimumSize = new System.Drawing.Size(513, 222);
            this.Name = "frmCustomersSearchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customers Search Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSetCustomerSearchCriteria;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblPostcode;
        private System.Windows.Forms.TextBox txtPostcode;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ComboBox cbState;
        private System.Windows.Forms.TextBox txtCategory;
    }
}