﻿namespace InsuranceInterface.UIScreens
{
    partial class frmSalesDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVariousFunctions = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblSaleID = new System.Windows.Forms.Label();
            this.txtSaleID = new System.Windows.Forms.TextBox();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.lblProductID = new System.Windows.Forms.Label();
            this.txtLastFirstname = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblPayable = new System.Windows.Forms.Label();
            this.lblStatrDate = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.btnSearchFilterCustomer = new System.Windows.Forms.Button();
            this.btnSearchFilterProducts = new System.Windows.Forms.Button();
            this.cbPayable = new System.Windows.Forms.ComboBox();
            this.lvCustomerList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvProductList = new System.Windows.Forms.ListView();
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblNoProductsToShow = new System.Windows.Forms.Label();
            this.lblNoCustomersToShow = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnVariousFunctions
            // 
            this.btnVariousFunctions.Location = new System.Drawing.Point(127, 560);
            this.btnVariousFunctions.Name = "btnVariousFunctions";
            this.btnVariousFunctions.Size = new System.Drawing.Size(121, 41);
            this.btnVariousFunctions.TabIndex = 10;
            this.btnVariousFunctions.Text = "Add Sale:";
            this.btnVariousFunctions.UseVisualStyleBackColor = true;
            this.btnVariousFunctions.Click += new System.EventHandler(this.BtnVariousFunctions_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancel.Location = new System.Drawing.Point(12, 560);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(82, 41);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "&Cancel:";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // lblSaleID
            // 
            this.lblSaleID.AutoSize = true;
            this.lblSaleID.Location = new System.Drawing.Point(12, 9);
            this.lblSaleID.Name = "lblSaleID";
            this.lblSaleID.Size = new System.Drawing.Size(45, 13);
            this.lblSaleID.TabIndex = 7;
            this.lblSaleID.Text = "Sale ID:";
            // 
            // txtSaleID
            // 
            this.txtSaleID.Location = new System.Drawing.Point(79, 6);
            this.txtSaleID.Name = "txtSaleID";
            this.txtSaleID.ReadOnly = true;
            this.txtSaleID.Size = new System.Drawing.Size(100, 20);
            this.txtSaleID.TabIndex = 0;
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.Location = new System.Drawing.Point(79, 36);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.ReadOnly = true;
            this.txtCustomerID.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerID.TabIndex = 1;
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(12, 39);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(68, 13);
            this.lblCustomerID.TabIndex = 9;
            this.lblCustomerID.Text = "Customer ID:";
            // 
            // txtProductID
            // 
            this.txtProductID.Location = new System.Drawing.Point(79, 284);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.ReadOnly = true;
            this.txtProductID.Size = new System.Drawing.Size(100, 20);
            this.txtProductID.TabIndex = 4;
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.Location = new System.Drawing.Point(12, 287);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(61, 13);
            this.lblProductID.TabIndex = 12;
            this.lblProductID.Text = "Product ID:";
            // 
            // txtLastFirstname
            // 
            this.txtLastFirstname.Enabled = false;
            this.txtLastFirstname.Location = new System.Drawing.Point(185, 36);
            this.txtLastFirstname.Name = "txtLastFirstname";
            this.txtLastFirstname.Size = new System.Drawing.Size(371, 20);
            this.txtLastFirstname.TabIndex = 2;
            // 
            // txtProductName
            // 
            this.txtProductName.Enabled = false;
            this.txtProductName.Location = new System.Drawing.Point(185, 284);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(371, 20);
            this.txtProductName.TabIndex = 5;
            // 
            // lblPayable
            // 
            this.lblPayable.AutoSize = true;
            this.lblPayable.Location = new System.Drawing.Point(12, 534);
            this.lblPayable.Name = "lblPayable";
            this.lblPayable.Size = new System.Drawing.Size(48, 13);
            this.lblPayable.TabIndex = 14;
            this.lblPayable.Text = "Payable:";
            // 
            // lblStatrDate
            // 
            this.lblStatrDate.AutoSize = true;
            this.lblStatrDate.Location = new System.Drawing.Point(292, 538);
            this.lblStatrDate.Name = "lblStatrDate";
            this.lblStatrDate.Size = new System.Drawing.Size(58, 13);
            this.lblStatrDate.TabIndex = 14;
            this.lblStatrDate.Text = "Start Date:";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(356, 531);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(200, 20);
            this.dtpStartDate.TabIndex = 8;
            // 
            // btnSearchFilterCustomer
            // 
            this.btnSearchFilterCustomer.Location = new System.Drawing.Point(280, 560);
            this.btnSearchFilterCustomer.Name = "btnSearchFilterCustomer";
            this.btnSearchFilterCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterCustomer.TabIndex = 11;
            this.btnSearchFilterCustomer.Text = "Search / Filter Customer:";
            this.btnSearchFilterCustomer.UseVisualStyleBackColor = true;
            this.btnSearchFilterCustomer.Click += new System.EventHandler(this.BtnSearchFilterCustomer_Click);
            // 
            // btnSearchFilterProducts
            // 
            this.btnSearchFilterProducts.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnSearchFilterProducts.Location = new System.Drawing.Point(435, 560);
            this.btnSearchFilterProducts.Name = "btnSearchFilterProducts";
            this.btnSearchFilterProducts.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterProducts.TabIndex = 12;
            this.btnSearchFilterProducts.Text = "Search / Filter Product:";
            this.btnSearchFilterProducts.UseVisualStyleBackColor = false;
            this.btnSearchFilterProducts.Click += new System.EventHandler(this.BtnSearchFilterProducts_Click);
            // 
            // cbPayable
            // 
            this.cbPayable.FormattingEnabled = true;
            this.cbPayable.Items.AddRange(new object[] {
            "Yearly",
            "Monthly",
            "Fortnightly"});
            this.cbPayable.Location = new System.Drawing.Point(66, 530);
            this.cbPayable.Name = "cbPayable";
            this.cbPayable.Size = new System.Drawing.Size(182, 21);
            this.cbPayable.TabIndex = 17;
            this.cbPayable.Text = "Yearly";
            // 
            // lvCustomerList
            // 
            this.lvCustomerList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9});
            this.lvCustomerList.FullRowSelect = true;
            this.lvCustomerList.GridLines = true;
            this.lvCustomerList.Location = new System.Drawing.Point(15, 65);
            this.lvCustomerList.MultiSelect = false;
            this.lvCustomerList.Name = "lvCustomerList";
            this.lvCustomerList.Size = new System.Drawing.Size(1126, 207);
            this.lvCustomerList.TabIndex = 18;
            this.lvCustomerList.UseCompatibleStateImageBehavior = false;
            this.lvCustomerList.View = System.Windows.Forms.View.Details;
            this.lvCustomerList.Click += new System.EventHandler(this.LvCustomerList_Click);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Customer ID";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Category";
            this.columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "First Name";
            this.columnHeader3.Width = 120;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Last Name";
            this.columnHeader4.Width = 150;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Address";
            this.columnHeader5.Width = 180;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Suburb";
            this.columnHeader6.Width = 100;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "State";
            this.columnHeader7.Width = 50;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Postcode";
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "D.O.B.";
            this.columnHeader9.Width = 100;
            // 
            // lvProductList
            // 
            this.lvProductList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15});
            this.lvProductList.FullRowSelect = true;
            this.lvProductList.GridLines = true;
            this.lvProductList.Location = new System.Drawing.Point(15, 314);
            this.lvProductList.MultiSelect = false;
            this.lvProductList.Name = "lvProductList";
            this.lvProductList.Size = new System.Drawing.Size(1126, 207);
            this.lvProductList.TabIndex = 19;
            this.lvProductList.UseCompatibleStateImageBehavior = false;
            this.lvProductList.View = System.Windows.Forms.View.Details;
            this.lvProductList.Click += new System.EventHandler(this.LvProductList_Click);
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Product ID";
            this.columnHeader10.Width = 100;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Product Type";
            this.columnHeader11.Width = 150;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Product Name";
            this.columnHeader12.Width = 200;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Yearly Premium";
            this.columnHeader13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader13.Width = 120;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Monthly Premium";
            this.columnHeader14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader14.Width = 120;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Fortnightly Premium";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader15.Width = 120;
            // 
            // lblNoProductsToShow
            // 
            this.lblNoProductsToShow.AutoSize = true;
            this.lblNoProductsToShow.Enabled = false;
            this.lblNoProductsToShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblNoProductsToShow.Location = new System.Drawing.Point(179, 408);
            this.lblNoProductsToShow.Name = "lblNoProductsToShow";
            this.lblNoProductsToShow.Size = new System.Drawing.Size(835, 31);
            this.lblNoProductsToShow.TabIndex = 20;
            this.lblNoProductsToShow.Text = "No products to display - please try a different filter or add some data.";
            this.lblNoProductsToShow.Visible = false;
            // 
            // lblNoCustomersToShow
            // 
            this.lblNoCustomersToShow.AutoSize = true;
            this.lblNoCustomersToShow.Enabled = false;
            this.lblNoCustomersToShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblNoCustomersToShow.Location = new System.Drawing.Point(171, 159);
            this.lblNoCustomersToShow.Name = "lblNoCustomersToShow";
            this.lblNoCustomersToShow.Size = new System.Drawing.Size(856, 31);
            this.lblNoCustomersToShow.TabIndex = 21;
            this.lblNoCustomersToShow.Text = "No customers to display - please try a different filter or add some data.";
            this.lblNoCustomersToShow.Visible = false;
            // 
            // frmSalesDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.lblNoCustomersToShow);
            this.Controls.Add(this.lblNoProductsToShow);
            this.Controls.Add(this.lvProductList);
            this.Controls.Add(this.lvCustomerList);
            this.Controls.Add(this.cbPayable);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.lblStatrDate);
            this.Controls.Add(this.lblPayable);
            this.Controls.Add(this.txtProductID);
            this.Controls.Add(this.lblProductID);
            this.Controls.Add(this.txtProductName);
            this.Controls.Add(this.txtLastFirstname);
            this.Controls.Add(this.txtCustomerID);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.txtSaleID);
            this.Controls.Add(this.lblSaleID);
            this.Controls.Add(this.btnSearchFilterProducts);
            this.Controls.Add(this.btnSearchFilterCustomer);
            this.Controls.Add(this.btnVariousFunctions);
            this.Controls.Add(this.btnCancel);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmSalesDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales Detail Form";
            this.Load += new System.EventHandler(this.FrmSalesDetailForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVariousFunctions;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblSaleID;
        private System.Windows.Forms.TextBox txtSaleID;
        private System.Windows.Forms.TextBox txtCustomerID;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.TextBox txtProductID;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.TextBox txtLastFirstname;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblPayable;
        private System.Windows.Forms.Label lblStatrDate;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.Button btnSearchFilterCustomer;
        private System.Windows.Forms.Button btnSearchFilterProducts;
        private System.Windows.Forms.ComboBox cbPayable;
        private System.Windows.Forms.ListView lvCustomerList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ListView lvProductList;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.Label lblNoProductsToShow;
        private System.Windows.Forms.Label lblNoCustomersToShow;
    }
}