﻿namespace InsuranceInterface.UIScreens
{
    partial class frmProductMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDelectSelectedProduct = new System.Windows.Forms.Button();
            this.btnDisplayUpdateSelectedProduct = new System.Windows.Forms.Button();
            this.btnAddProducts = new System.Windows.Forms.Button();
            this.btnSearchFilterProducts = new System.Windows.Forms.Button();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.lvProductList = new System.Windows.Forms.ListView();
            this.lblNoRecordsToShow = new System.Windows.Forms.Label();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btnDelectSelectedProduct
            // 
            this.btnDelectSelectedProduct.Location = new System.Drawing.Point(435, 563);
            this.btnDelectSelectedProduct.Name = "btnDelectSelectedProduct";
            this.btnDelectSelectedProduct.Size = new System.Drawing.Size(121, 41);
            this.btnDelectSelectedProduct.TabIndex = 4;
            this.btnDelectSelectedProduct.Text = "Delete Selected Product:";
            this.btnDelectSelectedProduct.UseVisualStyleBackColor = true;
            this.btnDelectSelectedProduct.Click += new System.EventHandler(this.BtnDelectSelectedProduct_Click);
            // 
            // btnDisplayUpdateSelectedProduct
            // 
            this.btnDisplayUpdateSelectedProduct.Location = new System.Drawing.Point(281, 563);
            this.btnDisplayUpdateSelectedProduct.Name = "btnDisplayUpdateSelectedProduct";
            this.btnDisplayUpdateSelectedProduct.Size = new System.Drawing.Size(121, 41);
            this.btnDisplayUpdateSelectedProduct.TabIndex = 3;
            this.btnDisplayUpdateSelectedProduct.Text = "Display / Update Selected Product:";
            this.btnDisplayUpdateSelectedProduct.UseVisualStyleBackColor = true;
            this.btnDisplayUpdateSelectedProduct.Click += new System.EventHandler(this.BtnDisplayUpdateSelectedProduct_Click);
            // 
            // btnAddProducts
            // 
            this.btnAddProducts.Location = new System.Drawing.Point(127, 563);
            this.btnAddProducts.Name = "btnAddProducts";
            this.btnAddProducts.Size = new System.Drawing.Size(121, 41);
            this.btnAddProducts.TabIndex = 2;
            this.btnAddProducts.Text = "Add Product:";
            this.btnAddProducts.UseVisualStyleBackColor = true;
            this.btnAddProducts.Click += new System.EventHandler(this.BtnAddProducts_Click);
            // 
            // btnSearchFilterProducts
            // 
            this.btnSearchFilterProducts.Location = new System.Drawing.Point(592, 564);
            this.btnSearchFilterProducts.Name = "btnSearchFilterProducts";
            this.btnSearchFilterProducts.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterProducts.TabIndex = 5;
            this.btnSearchFilterProducts.Text = "Search / Filter Products:";
            this.btnSearchFilterProducts.UseVisualStyleBackColor = true;
            this.btnSearchFilterProducts.Click += new System.EventHandler(this.BtnSearchFilterProducts_Click);
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 563);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 1;
            this.btnReturnToMainMenu.Text = "&Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // lvProductList
            // 
            this.lvProductList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.lvProductList.FullRowSelect = true;
            this.lvProductList.GridLines = true;
            this.lvProductList.Location = new System.Drawing.Point(12, 8);
            this.lvProductList.MultiSelect = false;
            this.lvProductList.Name = "lvProductList";
            this.lvProductList.Size = new System.Drawing.Size(1128, 549);
            this.lvProductList.TabIndex = 6;
            this.lvProductList.UseCompatibleStateImageBehavior = false;
            this.lvProductList.View = System.Windows.Forms.View.Details;
            // 
            // lblNoRecordsToShow
            // 
            this.lblNoRecordsToShow.AutoSize = true;
            this.lblNoRecordsToShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblNoRecordsToShow.Location = new System.Drawing.Point(164, 293);
            this.lblNoRecordsToShow.Name = "lblNoRecordsToShow";
            this.lblNoRecordsToShow.Size = new System.Drawing.Size(835, 31);
            this.lblNoRecordsToShow.TabIndex = 7;
            this.lblNoRecordsToShow.Text = "No products to display - please try a different filter or add some data.";
            this.lblNoRecordsToShow.Visible = false;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Product ID";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Product Type";
            this.columnHeader2.Width = 150;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Product Name";
            this.columnHeader3.Width = 200;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Yearly Premium";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader4.Width = 120;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Monthly Premium";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader5.Width = 120;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Fortnightly Premium";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader6.Width = 120;
            // 
            // frmProductMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.lblNoRecordsToShow);
            this.Controls.Add(this.lvProductList);
            this.Controls.Add(this.btnDelectSelectedProduct);
            this.Controls.Add(this.btnDisplayUpdateSelectedProduct);
            this.Controls.Add(this.btnAddProducts);
            this.Controls.Add(this.btnSearchFilterProducts);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmProductMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Maintenance";
            this.Load += new System.EventHandler(this.FrmProductMaintenance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnDelectSelectedProduct;
        private System.Windows.Forms.Button btnDisplayUpdateSelectedProduct;
        private System.Windows.Forms.Button btnAddProducts;
        private System.Windows.Forms.Button btnSearchFilterProducts;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.ListView lvProductList;
        private System.Windows.Forms.Label lblNoRecordsToShow;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
    }
}