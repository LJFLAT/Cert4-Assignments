﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{

    public partial class frmTutorialSubFormDetails : Form
    {
        string originalText;

        public frmTutorialSubFormDetails()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void PbVarious_MouseHover(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
            rtbItemHelp.Text = "This is an UPDATE (or for new information ADD) button. It will change / add information" +
                "to the database. There is a confirmation prior to proceeding.";
        }

        private void PbVarious_MouseLeave(object sender, EventArgs e)
        {
            rtbItemHelp.Text = originalText;
        }

        private void PbCancel_MouseHover(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
            rtbItemHelp.Text = "The cancel button returns you to the previous screen (usually a maintenance screen)." +
                "This button will cancel any changes or and new information without affecting the database.";
        }

        private void PbCancel_MouseLeave(object sender, EventArgs e)
        {
            rtbItemHelp.Text = originalText;
        }

        private void BtnMainMenu_Click(object sender, EventArgs e)
        {
            frmTutorialMainForm viewForm = new frmTutorialMainForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnMaintenance_Click(object sender, EventArgs e)
        {
            frmTutorialSubFormMaint viewForm = new frmTutorialSubFormMaint();
            viewForm.Show();
            this.Hide();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            frmTutorialSubFormSearch viewForm = new frmTutorialSubFormSearch();
            viewForm.Show();
            this.Hide();
        }

        private void BtnReturnToMainMenu_Click_1(object sender, EventArgs e)
        {
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void FrmTutorialSubFormDetails_Load(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
        }
    }
}
