﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{


    public partial class frmProductDetailsForm : Form
    {
        Products product = new Products();

        public frmProductDetailsForm()
        {
            InitializeComponent();
        }

        private void FrmProductDetailsForm_Load(object sender, EventArgs e)
        {
            //Code to populate the Category List Box - couldn't use stored procedure as it was incorrect order
            string selectQuery;
            selectQuery = "SELECT * FROM ProductTypes ORDER BY ProductTypeID";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                //cmd.CommandType = CommandType.StoredProcedure;  couldn't use the stored procedure as it was in wrong order
                conn.Open();

                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    lbProductType.Items.Add(rdr["ProductTypeID"].ToString());
                    cbProductType.Items.Add(rdr["ProductType"].ToString());
                }
                if (rdr != null)
                    rdr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unsuccessful " + ex);
            }
            if (GlobalVariables.ProductAdd)
            {
                btnVariousFunctions.Text = "Add Product:";
            }
            else
            {
                //load the existing data into the form as a class object
                btnVariousFunctions.Text = "Update Product:";
                LoadProductDetails();
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //before leaving the details screen - check to see if the information has changed - verify with user they wish to exit without saving?
            if (!GlobalVariables.ProductAdd) //only check when information is being updated
            {
                if (ProductChangedDetails())
                {
                    DialogResult dialogResult = MessageBox.Show("Information has changed. Are you sure you wish to exit?",
                        "Exit without saving", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.No)
                    {
                        return;
                    }
                }
            }
            GlobalVariables.ProductAdd = true;
            frmProductMaintenance viewForm = new frmProductMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void BtnVariousFunctions_Click(object sender, EventArgs e)
        {
            if (!CheckDetails()) //check to see if the entered details are valid
            {
                return;
            }
            string confirmMessage = "Do you wish to update this product?";
            string confirmTitle = "Update Product";
            if (GlobalVariables.ProductAdd)
            {
                confirmMessage = "Do you wish to add a new product?";
                confirmTitle = "Add Product";
            }
            DialogResult userResponse = MessageBox.Show(confirmMessage, confirmTitle, MessageBoxButtons.YesNo);

            if (userResponse == DialogResult.Yes)
            {
                //Code to add or update the product
                AddUpdateProduct();
            }
            else
            {
                return;
            }
            GlobalVariables.ProductAdd = true;
            frmProductMaintenance viewForm = new frmProductMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void AddUpdateProduct()
        {
            if (!GlobalVariables.ProductAdd)
            {
                product.ProductID = int.Parse(txtProductID.Text);
            }
            decimal convertPremium = decimal.Parse(txtYearlyPremium.Text);
            product.ProductName = txtProductName.Text;
            product.YearlyPremium = convertPremium;
            product.ProductTypeID = int.Parse(lbProductType.Items[cbProductType.SelectedIndex].ToString());

            string databaseAction;
            if (GlobalVariables.ProductAdd)
            {
                databaseAction = "sp_Products_CreateProduct ";
            }
            else
            {
                databaseAction = "sp_Products_UpdateProduct ";
            }

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            conn.Open();

            SqlCommand cmd = new SqlCommand(databaseAction, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            if (!GlobalVariables.ProductAdd)
            {
                cmd.Parameters.AddWithValue("@ProductID", product.ProductID);
            }
            cmd.Parameters.AddWithValue("@ProductTypeID", product.ProductTypeID);
            cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
            cmd.Parameters.AddWithValue("@YearlyPremium", product.YearlyPremium);
            if (GlobalVariables.ProductAdd)
            {
                cmd.Parameters.AddWithValue("@NewProductID", SqlDbType.Int).Direction = ParameterDirection.Output;
            }
            cmd.Transaction = conn.BeginTransaction();
            cmd.ExecuteNonQuery();
            cmd.Transaction.Commit();

            conn.Close();
        }

        private void LoadProductDetails()
        {
            string selectQuery = "sp_Products_GetProducts";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter categoryId = cmd.Parameters.AddWithValue("@ProductID", GlobalVariables.SelectedProduct);

                rdr = cmd.ExecuteReader();
                rdr.Read();

                //populate product instance for verifying changes
                product.ProductID = int.Parse(rdr["ProductID"].ToString());
                product.ProductTypeID = int.Parse(rdr["ProductTypeID"].ToString());
                product.ProductType = cbProductType.Items[int.Parse(rdr["ProductTypeID"].ToString()) - 1].ToString();
                product.ProductName = rdr["ProductName"].ToString();
                product.YearlyPremium = decimal.Parse(rdr["YearlyPremium"].ToString());

                //populate form
                decimal holdPremium = decimal.Parse(rdr["YearlyPremium"].ToString());
                txtProductID.Text = rdr["ProductID"].ToString();
                cbProductType.Text = rdr["ProductTypeID"].ToString();
                cbProductType.SelectedIndex = int.Parse(rdr["ProductTypeID"].ToString()) - 1;
                txtProductName.Text = rdr["ProductName"].ToString();
                txtYearlyPremium.Text = holdPremium.ToString("0.00");
                rdr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("unsuccessful " + ex);
            }
        }
        private bool CheckDetails()  //used to check the information is correctly entered / if the information has been updated
        {
            string errorMessages = "";
            errorMessages = GlobalVariables.FieldBlank("Product Name", txtProductName.Text);
            errorMessages += GlobalVariables.FieldBlank("Product Type", cbProductType.Text);
            errorMessages += product.CheckValues("Yearly Premium", txtYearlyPremium.Text);
            if (errorMessages.Length > 0)
            {
                MessageBox.Show("The following information is incorrect:\n\n" + errorMessages,
                    "Incorrect Product Information");
                return false;
            }
            return true; //entered information is technically valid
        }

        private bool ProductChangedDetails()
        {
            if (!product.ProductName.Equals(txtProductName.Text) || 
                !txtYearlyPremium.Text.Equals(product.YearlyPremium.ToString("0.00")) || 
                !product.ProductType.Equals(cbProductType.SelectedItem.ToString()))
            {
                return true;
            }
            return false;
        }
    }
}
