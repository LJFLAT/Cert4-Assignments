﻿namespace InsuranceInterface.UIScreens
{
    partial class frmTutorialSubFormDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTutorialSubFormDetails));
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.lblTutuorialHeaderBox = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnDetails = new System.Windows.Forms.Button();
            this.btnMaintenance = new System.Windows.Forms.Button();
            this.rtbItemHelp = new System.Windows.Forms.RichTextBox();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.pbVarious = new System.Windows.Forms.PictureBox();
            this.pbCancel = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVarious)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCancel)).BeginInit();
            this.SuspendLayout();
            // 
            // richTextBox11
            // 
            this.richTextBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.richTextBox11.Location = new System.Drawing.Point(850, 37);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.ReadOnly = true;
            this.richTextBox11.Size = new System.Drawing.Size(291, 517);
            this.richTextBox11.TabIndex = 22;
            this.richTextBox11.Text = resources.GetString("richTextBox11.Text");
            // 
            // lblTutuorialHeaderBox
            // 
            this.lblTutuorialHeaderBox.AutoSize = true;
            this.lblTutuorialHeaderBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblTutuorialHeaderBox.Location = new System.Drawing.Point(13, 3);
            this.lblTutuorialHeaderBox.Name = "lblTutuorialHeaderBox";
            this.lblTutuorialHeaderBox.Size = new System.Drawing.Size(169, 31);
            this.lblTutuorialHeaderBox.TabIndex = 26;
            this.lblTutuorialHeaderBox.Text = "Details Help:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(604, 387);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(589, 560);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(121, 41);
            this.btnSearch.TabIndex = 32;
            this.btnSearch.Text = "Search Help:";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // btnDetails
            // 
            this.btnDetails.Enabled = false;
            this.btnDetails.Location = new System.Drawing.Point(437, 560);
            this.btnDetails.Name = "btnDetails";
            this.btnDetails.Size = new System.Drawing.Size(121, 41);
            this.btnDetails.TabIndex = 31;
            this.btnDetails.Text = "Details Help:";
            this.btnDetails.UseVisualStyleBackColor = true;
            // 
            // btnMaintenance
            // 
            this.btnMaintenance.Location = new System.Drawing.Point(283, 560);
            this.btnMaintenance.Name = "btnMaintenance";
            this.btnMaintenance.Size = new System.Drawing.Size(121, 41);
            this.btnMaintenance.TabIndex = 30;
            this.btnMaintenance.Text = "Maintenance Help:";
            this.btnMaintenance.UseVisualStyleBackColor = true;
            this.btnMaintenance.Click += new System.EventHandler(this.BtnMaintenance_Click);
            // 
            // rtbItemHelp
            // 
            this.rtbItemHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.rtbItemHelp.Location = new System.Drawing.Point(14, 502);
            this.rtbItemHelp.Name = "rtbItemHelp";
            this.rtbItemHelp.Size = new System.Drawing.Size(817, 51);
            this.rtbItemHelp.TabIndex = 29;
            this.rtbItemHelp.Text = "Hover your mouse over an item / area above to get information about it.";
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Location = new System.Drawing.Point(128, 560);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(121, 41);
            this.btnMainMenu.TabIndex = 28;
            this.btnMainMenu.Text = "Main Menu Help:";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            this.btnMainMenu.Click += new System.EventHandler(this.BtnMainMenu_Click);
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 560);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 27;
            this.btnReturnToMainMenu.Text = "Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click_1);
            // 
            // pbVarious
            // 
            this.pbVarious.Image = ((System.Drawing.Image)(resources.GetObject("pbVarious.Image")));
            this.pbVarious.Location = new System.Drawing.Point(139, 369);
            this.pbVarious.Name = "pbVarious";
            this.pbVarious.Size = new System.Drawing.Size(125, 45);
            this.pbVarious.TabIndex = 33;
            this.pbVarious.TabStop = false;
            this.pbVarious.MouseLeave += new System.EventHandler(this.PbVarious_MouseLeave);
            this.pbVarious.MouseHover += new System.EventHandler(this.PbVarious_MouseHover);
            // 
            // pbCancel
            // 
            this.pbCancel.Image = ((System.Drawing.Image)(resources.GetObject("pbCancel.Image")));
            this.pbCancel.Location = new System.Drawing.Point(23, 369);
            this.pbCancel.Name = "pbCancel";
            this.pbCancel.Size = new System.Drawing.Size(91, 48);
            this.pbCancel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCancel.TabIndex = 34;
            this.pbCancel.TabStop = false;
            this.pbCancel.MouseLeave += new System.EventHandler(this.PbCancel_MouseLeave);
            this.pbCancel.MouseHover += new System.EventHandler(this.PbCancel_MouseHover);
            // 
            // frmTutorialSubFormDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.pbCancel);
            this.Controls.Add(this.pbVarious);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnDetails);
            this.Controls.Add(this.btnMaintenance);
            this.Controls.Add(this.rtbItemHelp);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.richTextBox11);
            this.Controls.Add(this.lblTutuorialHeaderBox);
            this.Controls.Add(this.pictureBox1);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmTutorialSubFormDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tutorial - Details";
            this.Load += new System.EventHandler(this.FrmTutorialSubFormDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbVarious)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCancel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.Label lblTutuorialHeaderBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnDetails;
        private System.Windows.Forms.Button btnMaintenance;
        private System.Windows.Forms.RichTextBox rtbItemHelp;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.PictureBox pbVarious;
        private System.Windows.Forms.PictureBox pbCancel;
    }
}