﻿namespace InsuranceInterface.UIScreens
{
    partial class frmAboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtbAbout = new System.Windows.Forms.RichTextBox();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.btnRestoreDatabase = new System.Windows.Forms.Button();
            this.btnBackupDatabase = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtbAbout
            // 
            this.rtbAbout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.rtbAbout.Location = new System.Drawing.Point(13, 13);
            this.rtbAbout.Name = "rtbAbout";
            this.rtbAbout.ReadOnly = true;
            this.rtbAbout.Size = new System.Drawing.Size(1128, 545);
            this.rtbAbout.TabIndex = 0;
            this.rtbAbout.Text = "";
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 564);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 2;
            this.btnReturnToMainMenu.Text = "&Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // btnRestoreDatabase
            // 
            this.btnRestoreDatabase.BackColor = System.Drawing.Color.LightCoral;
            this.btnRestoreDatabase.Location = new System.Drawing.Point(281, 564);
            this.btnRestoreDatabase.Name = "btnRestoreDatabase";
            this.btnRestoreDatabase.Size = new System.Drawing.Size(121, 41);
            this.btnRestoreDatabase.TabIndex = 4;
            this.btnRestoreDatabase.Text = "Restore Database:";
            this.btnRestoreDatabase.UseVisualStyleBackColor = false;
            this.btnRestoreDatabase.Visible = false;
            // 
            // btnBackupDatabase
            // 
            this.btnBackupDatabase.BackColor = System.Drawing.Color.PaleGreen;
            this.btnBackupDatabase.Location = new System.Drawing.Point(127, 564);
            this.btnBackupDatabase.Name = "btnBackupDatabase";
            this.btnBackupDatabase.Size = new System.Drawing.Size(121, 41);
            this.btnBackupDatabase.TabIndex = 3;
            this.btnBackupDatabase.Text = "Backup Database:";
            this.btnBackupDatabase.UseVisualStyleBackColor = false;
            this.btnBackupDatabase.Visible = false;
            // 
            // frmAboutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.btnRestoreDatabase);
            this.Controls.Add(this.btnBackupDatabase);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.rtbAbout);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmAboutForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "About Form";
            this.Load += new System.EventHandler(this.FrmAboutForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbAbout;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.Button btnRestoreDatabase;
        private System.Windows.Forms.Button btnBackupDatabase;
    }
}