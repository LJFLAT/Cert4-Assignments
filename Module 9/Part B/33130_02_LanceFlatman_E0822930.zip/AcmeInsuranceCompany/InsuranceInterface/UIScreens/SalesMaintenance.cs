﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmSalesMaintenance : Form
    {
        public frmSalesMaintenance()
        {
            InitializeComponent();
        }

        private void FrmSalesMaintenance_Load(object sender, EventArgs e)
        {
            GlobalVariables.SaleAdd = true;
            DisplaySales();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            //Clear and reset the filters
            GlobalVariables.CustomerFilterReset(); ;
            GlobalVariables.ProductFilterReset();

            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            GlobalVariables.SaleAdd = true;
            this.Hide();
        }

        private void BtnSearchFilterCustomer_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the customer data - pressing the button clears the filter and resets the colour of the button.
            if (GlobalVariables.CustSearchFilterSet)
            {
                btnSearchFilterCustomer.Text = "Search / Filter Customer:";
                btnSearchFilterCustomer.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.CustomerFilterReset();

                //re-display the customer list
                DisplaySales();
            }
            else
            {
                frmCustomersSearchForm viewForm = new frmCustomersSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.CustSearchFilterSet)
                {
                    btnSearchFilterCustomer.Text = "Press to clear Customer filter:";
                    btnSearchFilterCustomer.BackColor = Color.LightSteelBlue;

                    //code to filter the customer being displayed
                    DisplaySales();
                }
            }
        }

        private void BtnSearchFilterProducts_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the product data - pressing the button clears 
            //the filter and resets the colour of the button.
            if (GlobalVariables.ProdSearchFilterSet)
            {
                btnSearchFilterProducts.Text = "Search / Filter Product:";
                btnSearchFilterProducts.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.ProductFilterReset();
                DisplaySales();
            }
            else
            {
                frmProductsSearchForm viewForm = new frmProductsSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.ProdSearchFilterSet)
                {
                    btnSearchFilterProducts.Text = "Press to clear Product filter:";
                    btnSearchFilterProducts.BackColor = Color.LightSteelBlue;

                    //code to filter the products being displayed
                    DisplaySales();
                }
            }
        }

        private void BtnAddSales_Click(object sender, EventArgs e)
        {
            GlobalVariables.SaleAdd = true;
            GlobalVariables.SelectedSale = 0;

            frmSalesDetailForm viewForm = new frmSalesDetailForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDisplayUpdateSales_Click(object sender, EventArgs e)
        {
            //Check if a sale has been selected from the list - otherwise advise the user
            if (lvSalesList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Sale to Update.");
                DisplaySales();
                return;
            }

            //Store the currently selected customer to GlobalVariable.selectedSale
            GlobalVariables.SaleAdd = false;
            GlobalVariables.SelectedSale = int.Parse(lvSalesList.SelectedItems[0].Text);

            frmSalesDetailForm viewForm = new frmSalesDetailForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDeleteSelectedSalesEntry_Click(object sender, EventArgs e)
        {
            //check to see if a customer has been selected - otherwise advise user
            if (lvSalesList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Sale to Delete.");
                DisplaySales();
                return;
            }

            string confirmMessage = "Sale to: " + lvSalesList.SelectedItems[0].SubItems[1].Text + " "
            + lvSalesList.SelectedItems[0].SubItems[2].Text + "\n"
            + "Product: " + lvSalesList.SelectedItems[0].SubItems[4].Text + "\n\n"
            + "\n\nDo you wish delete this Sale?";

            DialogResult userResponse = MessageBox.Show(confirmMessage, "Delete Selected Sale",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            GlobalVariables.SelectedSale = int.Parse(lvSalesList.SelectedItems[0].Text);

            if (userResponse == DialogResult.No)
            {
                DisplaySales();
                return;
            }

            SqlConnection conn = ConnectionManager.DatabaseConnection();

            try
            {
                conn.Open();
                string deleteQuery = "sp_Sales_DeleteSale";

                SqlCommand cmd = new SqlCommand(deleteQuery, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@SaleID", GlobalVariables.SelectedSale);

                cmd.Transaction = conn.BeginTransaction();
                cmd.ExecuteNonQuery();
                cmd.Transaction.Commit();
                //finish TRANSACTION after database has been altered

                conn.Close();
            }
            catch (Exception ex)
            {
                //transaction.rollback() - only works when open() and transaction are outside the try/catch block.
                conn.Close();
                MessageBox.Show("Unsuccessful " + ex);
            }

            //Code to refresh the view of the Sales List
            DisplaySales();
        }

        private void DisplaySales()
        {
            lvSalesList.Items.Clear();
            int recordCount = 0;
            lblNoRecordsToShow.Visible = false;

            string selectQuery;

            selectQuery = "SELECT " + GlobalVariables.CustomerDatabaseFields() + ", "
                + GlobalVariables.ProductsDatabaseFields() + ", " + GlobalVariables.SalesDatabaseFields() + ", " +
                GlobalVariables.CategoryDatabaseFields() + ", " + GlobalVariables.ProductTypesDatabaseFields() + " ";
            selectQuery += "FROM Sales INNER JOIN Customers ON Customers.CustomerID = Sales.CustomerID ";
            selectQuery += "INNER JOIN Products ON Products.ProductID = Sales.ProductID ";
            selectQuery += "INNER JOIN ProductTypes ON ProductTypes.ProductTypeID = Products.ProductTypeID ";
            selectQuery += "INNER JOIN Categories ON Categories.CategoryID = Customers.CategoryID ";

            if (GlobalVariables.CustSearchFilterSet || GlobalVariables.ProdSearchFilterSet)
            {
                selectQuery += "WHERE ";
                if (GlobalVariables.CustSearchFilterSet)
                {
                    selectQuery += GlobalVariables.CustFilter() + " ";
                    if (GlobalVariables.ProdSearchFilterSet)
                    {
                        selectQuery += "AND ";
                    }
                }
                if (GlobalVariables.ProdSearchFilterSet)
                {
                    selectQuery += GlobalVariables.ProdFilter();
                }
            }
            selectQuery += " ORDER BY LastName, StartDate";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    string paymentCycle = "";

                    switch (rdr["Payable"].ToString())
                    {
                        case "Y":
                            {
                                paymentCycle = "Yearly";
                            }
                            break;
                        case "M":
                            {
                                paymentCycle = "Monthly";
                            }
                            break;
                        case "F":
                            {
                                paymentCycle = "Fortnightly";
                            }
                            break;
                    }

                    DateTime birthDate, policyStart;
                    policyStart = DateTime.Parse(rdr["StartDate"].ToString());
                    birthDate = DateTime.Parse(rdr["BirthDate"].ToString());

                    Sales sale = new Sales(int.Parse(rdr["SaleID"].ToString()), int.Parse(rdr["CustomerID"].ToString()),
                        int.Parse(rdr["ProductID"].ToString()), paymentCycle, policyStart);

                    Customers customer = new Customers(int.Parse(rdr["CustomerID"].ToString()), 
                        int.Parse(rdr["CategoryID"].ToString()), rdr["Category"].ToString() , rdr["FirstName"].ToString(), 
                        rdr["LastName"].ToString(), rdr["Address"].ToString(), rdr["Suburb"].ToString(), 
                        rdr["State"].ToString(), int.Parse(rdr["Postcode"].ToString()), rdr["Gender"].ToString(), 
                        birthDate);

                    Products product = new Products(int.Parse(rdr["ProductID"].ToString()),
                        int.Parse(rdr["ProductTypeID"].ToString()), rdr["ProductType"].ToString(), 
                        rdr["ProductName"].ToString(), decimal.Parse(rdr["YearlyPremium"].ToString()));


                    ListViewItem lvi = new ListViewItem(sale.SaleID.ToString());
                    lvi.SubItems.Add(customer.FirstName);
                    lvi.SubItems.Add(customer.LastName);
                    lvi.SubItems.Add(customer.Category);
                    lvi.SubItems.Add(product.ProductName);
                    lvi.SubItems.Add(product.ProductType);
                    lvi.SubItems.Add(sale.Payable);
                    lvi.SubItems.Add(sale.StartDate.ToString("dd/MM/yyyy"));
                    lvi.SubItems.Add(customer.Suburb);
                    lvi.SubItems.Add(customer.State);
                    lvSalesList.Items.Add(lvi);

                    recordCount++;
                }
                if (rdr != null)
                {
                    rdr.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unsuccessful " + ex);
            }

            if (recordCount == 0)
            {
                lblNoRecordsToShow.Visible = true;
            }
            return;
        }
    }
}
