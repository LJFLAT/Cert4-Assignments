﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceInterface.Business_Logic_Layer
{
    class Categories
    {
        private int _categoryID;
        private string _category;

        public int CategoryID
        {
            get { return _categoryID; }
            set { _categoryID = value; }
        }

        public string Category
        {
            get { return _category; }
            set { _category = value; }
        }

        public Categories() { }

        public Categories(int categoryID, string category)
        {
            CategoryID = categoryID;
            Category = category;
        }
    }
}
