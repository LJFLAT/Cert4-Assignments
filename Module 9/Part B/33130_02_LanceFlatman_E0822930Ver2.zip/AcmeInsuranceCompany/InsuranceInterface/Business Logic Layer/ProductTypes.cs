﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceInterface.Business_Logic_Layer
{
    class ProductTypes
    {
        private int _productTypeID;
        private string _productType;

        public int ProductTypeID
        {
            get { return _productTypeID; }
            set { _productTypeID = value; }
        }

        public string ProductType
        {
            get { return _productType; }
            set { _productType = value; }
        }

        public ProductTypes() { }

        public ProductTypes(int productTypeID, string productType)
        {
            ProductTypeID = productTypeID;
            ProductType = productType;
        }
    }
}
