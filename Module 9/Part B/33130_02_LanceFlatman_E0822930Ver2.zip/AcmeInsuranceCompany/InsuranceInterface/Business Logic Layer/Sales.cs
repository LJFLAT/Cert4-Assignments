﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceInterface.Business_Logic_Layer
{
    class Sales
    {
        private int _saleID, _customerID, _productID;
        private string _payable;
        private DateTime _startDate;

        public int SaleID
        {
            get { return _saleID; }
            set { _saleID = value; }
        }

        public int CustomerID
        {
            get { return _customerID; }
            set { _customerID = value; }
        }

        public int ProductID
        {
            get { return _productID; }
            set { _productID = value; }
        }

        public string Payable
        {
            get { return _payable; }
            set { _payable = value; }
        }

        public DateTime StartDate
        {
            get { return _startDate; }
            set { _startDate = value; }
        }

        public Sales() { }

        public Sales(int saleID, int customerID, int productID, string payable, DateTime startDate)
        {
            SaleID = saleID;
            CustomerID = customerID;
            ProductID = productID;
            Payable = payable;
            StartDate = startDate;
        }

        public string CheckStartDate(DateTime checkStartDate)
        {
            string errorMessage = "";
            if (checkStartDate > DateTime.Today.AddDays(1))
            {
                errorMessage = "The start date is in the future.\n";
            }
            else if (checkStartDate.Year < 1950)
            {
                errorMessage = "The start date is too early.\n";
            }
            return errorMessage;
        }
    }
}
