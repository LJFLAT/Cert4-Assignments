﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceInterface.Business_Logic_Layer
{
    class Customers
    {
        private string _firstName, _lastName, _address, _suburb, _state, _gender, _category;
        private DateTime _birthDate;
        private int _postcode, _customerID, _categoryID;

        public int CustomerID
        {
            get { return _customerID; }
            set { _customerID = value; }
        }

        public int CategoryID //used to hold the reference number while working with the data.
        {
            get { return _categoryID; }
            set { _categoryID = value; }
        }

        public string Category //used for holding the category name while manipulating the data.
        {
            get { return _category; }
            set { _category = value; }
        }

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }

        public string Suburb
        {
            get { return _suburb; }
            set { _suburb = value; }
        }

        public string State
        {
            get { return _state; }
            set { _state = value; }
        }
        public int Postcode
        {
            get { return _postcode; }
            set { _postcode = value; }
        }

        public string Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }

        public DateTime BirthDate
        {
            get { return _birthDate; }
            set { _birthDate = value; }
        }

        public Customers() { }

        public Customers(int customerID, int categoryID, string category, string firstName, string lastName, string address, string suburb, string state,
            int postcode, string gender, DateTime birthDate)
        {
            CustomerID = customerID;
            CategoryID = categoryID;
            Category = category;
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            Suburb = suburb;
            State = state;
            Postcode = postcode;
            Gender = gender;
            BirthDate = birthDate;
        }

        public string CheckPostcode(string state, string postCode)
        {
            string errorMessage = "";
            int postCodeNumber;

            if (postCode.Length == 0)
            {
                errorMessage = "Postcode has not been entered.\n";
                return errorMessage;
            }

            try
            {
                postCodeNumber = int.Parse(postCode);
                if (postCodeNumber >= 10000)
                {
                    errorMessage = "Postcode is incorrect.\n";
                    return errorMessage;
                }
            }
            catch
            {
                errorMessage = "Postcode must be a number.\n";
                return errorMessage;
            }

            switch (postCodeNumber / 1000)
            {
                case 1:
                    if (!state.Equals("NSW"))
                    {
                        errorMessage = "Post code is not correct for " + state + ". Please re-enter a valid post code.\n";
                        return errorMessage;
                    }
                    break;

                case 2:
                    if (!(state.Equals("NSW") || state.Equals("ACT")))
                    {
                        errorMessage = "Post code is not correct for " + state + ". Please re-enter a valid post code.\n";
                        return errorMessage;
                    }
                    break;

                case 3:
                    if (!state.Equals("VIC"))
                    {
                        errorMessage = "Post code is not correct for " + state + ". Please re-enter a valid post code.\n";
                        return errorMessage;
                    }
                    break;

                case 4:
                    if (!state.Equals("QLD"))
                    {
                        errorMessage = "Post code is not correct for " + state + ". Please re-enter a valid post code.\n";
                        return errorMessage;
                    }
                    break;

                case 5:
                    if (!state.Equals("SA"))
                    {
                        errorMessage = "Post code is not correct for " + state + ". Please re-enter a valid post code.\n";
                        return errorMessage;
                    }
                    break;

                case 6:
                    if (!state.Equals("WA"))
                    {
                        errorMessage = "Post code is not correct for " + state + ". Please re-enter a valid post code.\n";
                        return errorMessage;
                    }
                    break;

                case 7:
                    if (!state.Equals("TAS"))
                    {
                        errorMessage = "Post code is not correct for " + state + ". Please re-enter a valid post code.\n";
                        return errorMessage;
                    }
                    break;

                case 8:
                    if (!state.Equals("VIC"))
                    {
                        errorMessage = "Post code is not correct for " + state + ". Please re-enter a valid post code.\n";
                        return errorMessage;
                    }
                    break;

                case 9:
                    if (!state.Equals("QLD"))
                    {
                        errorMessage = "Post code is not correct for " + state + ". Please re-enter a valid post code.\n";
                        return errorMessage;
                    }
                    break;

                default:
                    errorMessage = "";
                    break;
            }

            return errorMessage;
        }
        
        public string CheckBirthDate(DateTime checkBirthDate)
        {
            string errorMessage = "";
            if (checkBirthDate > DateTime.Today.AddDays(1))
            {
                errorMessage = "Please enter a date for birth date.\n";
            }
            else if (checkBirthDate > DateTime.Today)
            {
                errorMessage = "The birth date is incorrect.\n";
            }
            else if (checkBirthDate.Year < 1900)
            {
                errorMessage = "The birth date is too early.\n";
            }
            return errorMessage;
        }
    }
}
