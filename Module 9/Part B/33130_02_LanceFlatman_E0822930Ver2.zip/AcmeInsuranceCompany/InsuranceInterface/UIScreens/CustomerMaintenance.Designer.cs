﻿namespace InsuranceInterface.UIScreens
{
    partial class frmCustomerMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.btnSearchFilterCustomer = new System.Windows.Forms.Button();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.btnDisplayUpdateCustomer = new System.Windows.Forms.Button();
            this.btnDeleteSelectedCustomer = new System.Windows.Forms.Button();
            this.lblNoRecordsToShow = new System.Windows.Forms.Label();
            this.lvCustomerList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 564);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 1;
            this.btnReturnToMainMenu.Text = "&Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // btnSearchFilterCustomer
            // 
            this.btnSearchFilterCustomer.BackColor = System.Drawing.SystemColors.Control;
            this.btnSearchFilterCustomer.Location = new System.Drawing.Point(592, 564);
            this.btnSearchFilterCustomer.Name = "btnSearchFilterCustomer";
            this.btnSearchFilterCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterCustomer.TabIndex = 5;
            this.btnSearchFilterCustomer.Text = "Search / Filter Customer:";
            this.btnSearchFilterCustomer.UseVisualStyleBackColor = false;
            this.btnSearchFilterCustomer.Click += new System.EventHandler(this.BtnSearchFilterCustomer_Click);
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.Location = new System.Drawing.Point(127, 563);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnAddCustomer.TabIndex = 2;
            this.btnAddCustomer.Text = "Add Customer:";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.BtnAddCustomer_Click);
            // 
            // btnDisplayUpdateCustomer
            // 
            this.btnDisplayUpdateCustomer.Location = new System.Drawing.Point(281, 564);
            this.btnDisplayUpdateCustomer.Name = "btnDisplayUpdateCustomer";
            this.btnDisplayUpdateCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnDisplayUpdateCustomer.TabIndex = 3;
            this.btnDisplayUpdateCustomer.Text = "Display / Update Selected Customer:";
            this.btnDisplayUpdateCustomer.UseVisualStyleBackColor = true;
            this.btnDisplayUpdateCustomer.Click += new System.EventHandler(this.BtnDisplayUpdateCustomer_Click);
            // 
            // btnDeleteSelectedCustomer
            // 
            this.btnDeleteSelectedCustomer.Location = new System.Drawing.Point(435, 563);
            this.btnDeleteSelectedCustomer.Name = "btnDeleteSelectedCustomer";
            this.btnDeleteSelectedCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnDeleteSelectedCustomer.TabIndex = 4;
            this.btnDeleteSelectedCustomer.Text = "Delete Selected Customer:";
            this.btnDeleteSelectedCustomer.UseVisualStyleBackColor = true;
            this.btnDeleteSelectedCustomer.Click += new System.EventHandler(this.BtnDeleteSelectedCustomer_Click);
            // 
            // lblNoRecordsToShow
            // 
            this.lblNoRecordsToShow.AutoSize = true;
            this.lblNoRecordsToShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblNoRecordsToShow.Location = new System.Drawing.Point(153, 277);
            this.lblNoRecordsToShow.Name = "lblNoRecordsToShow";
            this.lblNoRecordsToShow.Size = new System.Drawing.Size(856, 31);
            this.lblNoRecordsToShow.TabIndex = 6;
            this.lblNoRecordsToShow.Text = "No customers to display - please try a different filter or add some data.";
            this.lblNoRecordsToShow.Visible = false;
            // 
            // lvCustomerList
            // 
            this.lvCustomerList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9});
            this.lvCustomerList.FullRowSelect = true;
            this.lvCustomerList.GridLines = true;
            this.lvCustomerList.Location = new System.Drawing.Point(12, 8);
            this.lvCustomerList.MultiSelect = false;
            this.lvCustomerList.Name = "lvCustomerList";
            this.lvCustomerList.Size = new System.Drawing.Size(1128, 549);
            this.lvCustomerList.TabIndex = 0;
            this.lvCustomerList.UseCompatibleStateImageBehavior = false;
            this.lvCustomerList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Customer ID";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Category";
            this.columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "First Name";
            this.columnHeader3.Width = 120;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Last Name";
            this.columnHeader4.Width = 150;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Address";
            this.columnHeader5.Width = 180;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Suburb";
            this.columnHeader6.Width = 100;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "State";
            this.columnHeader7.Width = 50;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Postcode";
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "D.O.B.";
            this.columnHeader9.Width = 100;
            // 
            // frmCustomerMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.lblNoRecordsToShow);
            this.Controls.Add(this.btnDeleteSelectedCustomer);
            this.Controls.Add(this.btnDisplayUpdateCustomer);
            this.Controls.Add(this.btnAddCustomer);
            this.Controls.Add(this.btnSearchFilterCustomer);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.lvCustomerList);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmCustomerMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Maintenance";
            this.Load += new System.EventHandler(this.frmCustomerMaintenance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.Button btnSearchFilterCustomer;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.Button btnDisplayUpdateCustomer;
        private System.Windows.Forms.Button btnDeleteSelectedCustomer;
        private System.Windows.Forms.Label lblNoRecordsToShow;
        private System.Windows.Forms.ListView lvCustomerList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
    }
}