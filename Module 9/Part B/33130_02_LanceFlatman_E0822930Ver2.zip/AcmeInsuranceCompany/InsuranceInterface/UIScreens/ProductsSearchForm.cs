﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmProductsSearchForm : Form
    {
        public frmProductsSearchForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnVariousFunctions_Click(object sender, EventArgs e)
        {
            //code to set the search / filter variables in the GlobalVariable Class
            GlobalVariables.ProductFilterReset();

            if (txtProductName.TextLength > 0)
            {
                GlobalVariables.ProdSearchProductName = txtProductName.Text;
                GlobalVariables.ProdSearchFilterSet = true;
            }
            if (txtProductType.TextLength > 0)
            {
                GlobalVariables.ProdSearchProductType = txtProductType.Text;
                GlobalVariables.ProdSearchFilterSet = true;
            }
            this.Close();
        }
    }
}
