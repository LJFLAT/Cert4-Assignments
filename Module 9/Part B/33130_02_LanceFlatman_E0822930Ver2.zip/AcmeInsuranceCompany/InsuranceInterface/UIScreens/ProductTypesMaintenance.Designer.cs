﻿namespace InsuranceInterface.UIScreens
{
    partial class frmProductTypesMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeleteSelectedProductType = new System.Windows.Forms.Button();
            this.btnDisplayEditSelectedProductType = new System.Windows.Forms.Button();
            this.btnAddProductType = new System.Windows.Forms.Button();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.lblNoRecordsToShow = new System.Windows.Forms.Label();
            this.lvProdctTypesList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btnDeleteSelectedProductType
            // 
            this.btnDeleteSelectedProductType.Location = new System.Drawing.Point(434, 563);
            this.btnDeleteSelectedProductType.Name = "btnDeleteSelectedProductType";
            this.btnDeleteSelectedProductType.Size = new System.Drawing.Size(121, 41);
            this.btnDeleteSelectedProductType.TabIndex = 4;
            this.btnDeleteSelectedProductType.Text = "Delete Selected Product Type:";
            this.btnDeleteSelectedProductType.UseVisualStyleBackColor = true;
            this.btnDeleteSelectedProductType.Click += new System.EventHandler(this.BtnDeleteSelectedProductType_Click);
            // 
            // btnDisplayEditSelectedProductType
            // 
            this.btnDisplayEditSelectedProductType.Location = new System.Drawing.Point(279, 563);
            this.btnDisplayEditSelectedProductType.Name = "btnDisplayEditSelectedProductType";
            this.btnDisplayEditSelectedProductType.Size = new System.Drawing.Size(124, 41);
            this.btnDisplayEditSelectedProductType.TabIndex = 3;
            this.btnDisplayEditSelectedProductType.Text = "Display / Update Selected Product Type\r\n";
            this.btnDisplayEditSelectedProductType.UseVisualStyleBackColor = true;
            this.btnDisplayEditSelectedProductType.Click += new System.EventHandler(this.BtnDisplayEditSelectedProductType_Click);
            // 
            // btnAddProductType
            // 
            this.btnAddProductType.Location = new System.Drawing.Point(127, 563);
            this.btnAddProductType.Name = "btnAddProductType";
            this.btnAddProductType.Size = new System.Drawing.Size(121, 41);
            this.btnAddProductType.TabIndex = 2;
            this.btnAddProductType.Text = "Add Product Type:";
            this.btnAddProductType.UseVisualStyleBackColor = true;
            this.btnAddProductType.Click += new System.EventHandler(this.BtnAddProductType_Click);
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 563);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 1;
            this.btnReturnToMainMenu.Text = "&Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // lblNoRecordsToShow
            // 
            this.lblNoRecordsToShow.AutoSize = true;
            this.lblNoRecordsToShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblNoRecordsToShow.Location = new System.Drawing.Point(134, 287);
            this.lblNoRecordsToShow.Name = "lblNoRecordsToShow";
            this.lblNoRecordsToShow.Size = new System.Drawing.Size(894, 31);
            this.lblNoRecordsToShow.TabIndex = 7;
            this.lblNoRecordsToShow.Text = "No product types to display - please try a different filter or add some data.";
            this.lblNoRecordsToShow.Visible = false;
            // 
            // lvProdctTypesList
            // 
            this.lvProdctTypesList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvProdctTypesList.FullRowSelect = true;
            this.lvProdctTypesList.GridLines = true;
            this.lvProdctTypesList.Location = new System.Drawing.Point(12, 8);
            this.lvProdctTypesList.MultiSelect = false;
            this.lvProdctTypesList.Name = "lvProdctTypesList";
            this.lvProdctTypesList.Size = new System.Drawing.Size(1128, 549);
            this.lvProdctTypesList.TabIndex = 8;
            this.lvProdctTypesList.UseCompatibleStateImageBehavior = false;
            this.lvProdctTypesList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Product Type ID";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Product Type";
            this.columnHeader2.Width = 200;
            // 
            // frmProductTypesMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.lblNoRecordsToShow);
            this.Controls.Add(this.btnDeleteSelectedProductType);
            this.Controls.Add(this.btnDisplayEditSelectedProductType);
            this.Controls.Add(this.btnAddProductType);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.lvProdctTypesList);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmProductTypesMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Types Maintenance";
            this.Load += new System.EventHandler(this.FrmProductTypesMaintenance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnDeleteSelectedProductType;
        private System.Windows.Forms.Button btnDisplayEditSelectedProductType;
        private System.Windows.Forms.Button btnAddProductType;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.Label lblNoRecordsToShow;
        private System.Windows.Forms.ListView lvProdctTypesList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
    }
}