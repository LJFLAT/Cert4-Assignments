﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmProductTypesMaintenance : Form
    {
        public frmProductTypesMaintenance()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void BtnAddProductType_Click(object sender, EventArgs e)
        {
            GlobalVariables.ProductTypeAdd = true;
            GlobalVariables.SelectedProductType = 0;

            frmProductTypesDetailForm viewForm = new frmProductTypesDetailForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDisplayEditSelectedProductType_Click(object sender, EventArgs e)
        {
            //Check if a product type has been selected from the list - otherwise advise the user
            if (lvProdctTypesList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Product Type to udpate.");
                return;
            }

            //Store the currently selected product type to GlobalVariable.selectedProductType
            GlobalVariables.ProductTypeAdd = false;
            GlobalVariables.SelectedProductType = int.Parse(lvProdctTypesList.SelectedItems[0].Text);

            frmProductTypesDetailForm viewForm = new frmProductTypesDetailForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDeleteSelectedProductType_Click(object sender, EventArgs e)
        {
            //check to see if a product type has been selected - otherwise advise user
            if (lvProdctTypesList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Product Type to Delete.");
                DisplayProductTypes();
                return;
            }

            GlobalVariables.SelectedProductType = int.Parse(lvProdctTypesList.SelectedItems[0].Text);

            //Code to check if the product type has been used
            string checkQuery = "sp_ProductTypes_AllowDeleteProductType";
            SqlConnection deleteCheck = ConnectionManager.DatabaseConnection();


            // Start the TRANSACTION code from time of check - someone else might be interacting with the data.
            //similar code from Microsoft at https://docs.microsoft.com/en-us/dotnet/api/system.data.sqlclient.sqltransaction?view=netframework-4.8
            SqlTransaction transaction;

            try
            {
                //MS implementation displays the open and transaction commands outside the try/catch block
                //as you cannot use transaction.rollback in the catch area as it is seen as not being assigned if inside.
                deleteCheck.Open();
                SqlCommand cmd = deleteCheck.CreateCommand();
                transaction = deleteCheck.BeginTransaction();

                cmd.Connection = deleteCheck;
                cmd.Transaction = transaction;

                cmd.CommandText = checkQuery;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ProductTypeID", GlobalVariables.SelectedProductType);
                cmd.Parameters.Add("@RecordCount", SqlDbType.Int);
                cmd.Parameters["@RecordCount"].Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();

                //similar reference to record count from https://blog.cloudboost.io/how-to-use-sql-output-parameters-in-stored-procedures-578e7c4ff188
                int recordCount = Convert.ToInt32(cmd.Parameters["@RecordCount"].Value);

                if (recordCount > 0)
                {
                    MessageBox.Show("Selected Product Type has been used.\n\nThis Product Type cannot be deleted.",
                        "Delete Product Type - Invalid");
                    transaction.Rollback();

                    deleteCheck.Dispose();
                    deleteCheck.Close();

                    DisplayProductTypes();
                    return;
                }

                string confirmMessage = "Product Type: " + lvProdctTypesList.SelectedItems[0].SubItems[1].Text 
                    + "\n\nDo you wish delete this Product Type?";

                DialogResult userResponse = MessageBox.Show(confirmMessage, "Delete Selected Product Type",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

                if (userResponse == DialogResult.Yes)
                {

                    string deleteQuery = "sp_ProductTypes_DeleteProductType";
                    cmd.CommandText = deleteQuery;
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@ProductTypeID", GlobalVariables.SelectedProductType);

                    cmd.ExecuteNonQuery();
                    cmd.Transaction.Commit();
                    //finish TRANSACTION after database has been altered
                }
                else
                {
                    transaction.Rollback();
                }
                deleteCheck.Close(); //if open was successful, then close the connection.
            }
            catch (Exception ex)
            {
                //transaction.rollback() - only works when open() and transaction are outside the try/catch block.
                deleteCheck.Close();
                MessageBox.Show("Unsuccessful " + ex);
            }
            //Code to refresh the view of the Customer List
            DisplayProductTypes();
        }

        private void FrmProductTypesMaintenance_Load(object sender, EventArgs e)
        {
            GlobalVariables.CategoryAdd = true;
            DisplayProductTypes();
        }

        private void DisplayProductTypes()
        {
            lvProdctTypesList.Items.Clear();
            int recordCount = 0;
            lblNoRecordsToShow.Visible = false;

            string selectQuery = "sp_ProductTypes_GetProductType";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ProductTypeID", 0);

                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    ProductTypes productType = new ProductTypes(int.Parse(rdr["ProductTypeID"].ToString()),
                        rdr["ProductType"].ToString());

                    ListViewItem lvi = new ListViewItem(productType.ProductTypeID.ToString());
                    lvi.SubItems.Add(productType.ProductType);
                    lvProdctTypesList.Items.Add(lvi);

                    recordCount++;
                }
                if (rdr != null)
                {
                    rdr.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unsuccessful " + ex);
            }

            if (recordCount == 0)
            {
                lblNoRecordsToShow.Visible = true;
            }
            return;
        }
    }
}
