﻿namespace InsuranceInterface.UIScreens
{
    partial class frmProductDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtYearlyPremium = new System.Windows.Forms.TextBox();
            this.lblYearlyPremium = new System.Windows.Forms.Label();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.btnVariousFunctions = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.grpProductDetails = new System.Windows.Forms.GroupBox();
            this.grpOfficeUse = new System.Windows.Forms.GroupBox();
            this.lbProductType = new System.Windows.Forms.ListBox();
            this.cbProductType = new System.Windows.Forms.ComboBox();
            this.grpProductDetails.SuspendLayout();
            this.grpOfficeUse.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 34;
            this.label2.Text = "Product Type:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtYearlyPremium
            // 
            this.txtYearlyPremium.Location = new System.Drawing.Point(90, 61);
            this.txtYearlyPremium.Name = "txtYearlyPremium";
            this.txtYearlyPremium.Size = new System.Drawing.Size(146, 20);
            this.txtYearlyPremium.TabIndex = 1;
            // 
            // lblYearlyPremium
            // 
            this.lblYearlyPremium.AutoSize = true;
            this.lblYearlyPremium.Location = new System.Drawing.Point(6, 64);
            this.lblYearlyPremium.Name = "lblYearlyPremium";
            this.lblYearlyPremium.Size = new System.Drawing.Size(82, 13);
            this.lblYearlyPremium.TabIndex = 32;
            this.lblYearlyPremium.Text = "Yearly Premium:";
            // 
            // txtProductID
            // 
            this.txtProductID.Enabled = false;
            this.txtProductID.Location = new System.Drawing.Point(80, 21);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.ReadOnly = true;
            this.txtProductID.Size = new System.Drawing.Size(147, 20);
            this.txtProductID.TabIndex = 0;
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(90, 24);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(223, 20);
            this.txtProductName.TabIndex = 0;
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(6, 24);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(61, 13);
            this.lblCustomerID.TabIndex = 27;
            this.lblCustomerID.Text = "Product ID:";
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(6, 27);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(78, 13);
            this.lblProductName.TabIndex = 28;
            this.lblProductName.Text = "Product Name:";
            // 
            // btnVariousFunctions
            // 
            this.btnVariousFunctions.Location = new System.Drawing.Point(127, 306);
            this.btnVariousFunctions.Name = "btnVariousFunctions";
            this.btnVariousFunctions.Size = new System.Drawing.Size(121, 41);
            this.btnVariousFunctions.TabIndex = 3;
            this.btnVariousFunctions.Text = "Add Product:";
            this.btnVariousFunctions.UseVisualStyleBackColor = true;
            this.btnVariousFunctions.Click += new System.EventHandler(this.BtnVariousFunctions_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancel.Location = new System.Drawing.Point(12, 306);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(82, 41);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "&Cancel:";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // grpProductDetails
            // 
            this.grpProductDetails.Controls.Add(this.lblProductName);
            this.grpProductDetails.Controls.Add(this.txtProductName);
            this.grpProductDetails.Controls.Add(this.txtYearlyPremium);
            this.grpProductDetails.Controls.Add(this.lblYearlyPremium);
            this.grpProductDetails.Location = new System.Drawing.Point(12, 12);
            this.grpProductDetails.Name = "grpProductDetails";
            this.grpProductDetails.Size = new System.Drawing.Size(319, 100);
            this.grpProductDetails.TabIndex = 0;
            this.grpProductDetails.TabStop = false;
            this.grpProductDetails.Text = "Product Details";
            // 
            // grpOfficeUse
            // 
            this.grpOfficeUse.Controls.Add(this.lbProductType);
            this.grpOfficeUse.Controls.Add(this.cbProductType);
            this.grpOfficeUse.Controls.Add(this.label2);
            this.grpOfficeUse.Controls.Add(this.lblCustomerID);
            this.grpOfficeUse.Controls.Add(this.txtProductID);
            this.grpOfficeUse.Location = new System.Drawing.Point(351, 12);
            this.grpOfficeUse.Name = "grpOfficeUse";
            this.grpOfficeUse.Size = new System.Drawing.Size(244, 100);
            this.grpOfficeUse.TabIndex = 1;
            this.grpOfficeUse.TabStop = false;
            this.grpOfficeUse.Text = "Office Use:";
            // 
            // lbProductType
            // 
            this.lbProductType.FormattingEnabled = true;
            this.lbProductType.Location = new System.Drawing.Point(233, 64);
            this.lbProductType.Name = "lbProductType";
            this.lbProductType.Size = new System.Drawing.Size(10, 17);
            this.lbProductType.TabIndex = 4;
            this.lbProductType.Visible = false;
            // 
            // cbProductType
            // 
            this.cbProductType.FormattingEnabled = true;
            this.cbProductType.Location = new System.Drawing.Point(80, 61);
            this.cbProductType.Name = "cbProductType";
            this.cbProductType.Size = new System.Drawing.Size(147, 21);
            this.cbProductType.TabIndex = 1;
            // 
            // frmProductDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 359);
            this.ControlBox = false;
            this.Controls.Add(this.grpOfficeUse);
            this.Controls.Add(this.grpProductDetails);
            this.Controls.Add(this.btnVariousFunctions);
            this.Controls.Add(this.btnCancel);
            this.MaximumSize = new System.Drawing.Size(623, 398);
            this.MinimumSize = new System.Drawing.Size(623, 398);
            this.Name = "frmProductDetailsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Details Form";
            this.Load += new System.EventHandler(this.FrmProductDetailsForm_Load);
            this.grpProductDetails.ResumeLayout(false);
            this.grpProductDetails.PerformLayout();
            this.grpOfficeUse.ResumeLayout(false);
            this.grpOfficeUse.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtYearlyPremium;
        private System.Windows.Forms.Label lblYearlyPremium;
        private System.Windows.Forms.TextBox txtProductID;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Button btnVariousFunctions;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox grpProductDetails;
        private System.Windows.Forms.GroupBox grpOfficeUse;
        private System.Windows.Forms.ComboBox cbProductType;
        private System.Windows.Forms.ListBox lbProductType;
    }
}