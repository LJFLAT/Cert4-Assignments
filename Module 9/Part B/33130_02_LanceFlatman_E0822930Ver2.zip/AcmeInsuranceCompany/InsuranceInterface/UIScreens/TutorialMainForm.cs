﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmTutorialMainForm : Form
    {
        string originalText;

        public frmTutorialMainForm()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void pbMenu_MouseHover(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
            rtbItemHelp.Text = "This area is the main menu. From here you can access the other parts of the program.\n" +
                "Select a menu item by clicking on the one required to open that section.";
        }

        private void pbMenu_MouseLeave(object sender, EventArgs e)
        {
            rtbItemHelp.Text = originalText;
        }

        private void BtnMaintenance_Click(object sender, EventArgs e)
        {
            frmTutorialSubFormMaint viewForm = new frmTutorialSubFormMaint();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDetails_Click(object sender, EventArgs e)
        {
            frmTutorialSubFormDetails viewForm = new frmTutorialSubFormDetails();
            viewForm.Show();
            this.Hide();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            frmTutorialSubFormSearch viewForm = new frmTutorialSubFormSearch();
            viewForm.Show();
            this.Hide();
        }

        private void pbExitApplication_MouseHover(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
            rtbItemHelp.Text = "The Exit Application button will exit the application and close any links to the database.";
        }

        private void PbExitApplication_MouseLeave(object sender, EventArgs e)
        {
            rtbItemHelp.Text = originalText;
        }

        private void FrmTutorialMainForm_Load(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
        }
    }
}
