﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmCategoryMaintenance : Form
    {
        public frmCategoryMaintenance()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void BtnDeleteSelectedCategory_Click(object sender, EventArgs e)
        {
            //check to see if a customer has been selected - otherwise advise user
            if (lvCategoriesList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Category to Delete.");
                DisplayCategories();
                return;
            }

            GlobalVariables.SelectedCategory = int.Parse(lvCategoriesList.SelectedItems[0].Text);

            //Code to check if the customer has sales records already
            string checkQuery = "sp_Categories_AllowDeleteCategory";
            SqlConnection deleteCheck = ConnectionManager.DatabaseConnection();


            // Start the TRANSACTION code from time of check - someone else might be interacting with the data.
            //similar code from Microsoft at https://docs.microsoft.com/en-us/dotnet/api/system.data.sqlclient.sqltransaction?view=netframework-4.8
            SqlTransaction transaction;

            try
            {
                //MS implementation displays the open and transaction commands outside the try/catch block
                //as you cannot use transaction.rollback in the catch area as it is seen as not being assigned if inside.
                deleteCheck.Open();
                SqlCommand cmd = deleteCheck.CreateCommand();
                transaction = deleteCheck.BeginTransaction();

                cmd.Connection = deleteCheck;
                cmd.Transaction = transaction;

                cmd.CommandText = checkQuery;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CategoryID", GlobalVariables.SelectedCategory);
                //similar reference to record count from https://blog.cloudboost.io/how-to-use-sql-output-parameters-in-stored-procedures-578e7c4ff188
                cmd.Parameters.Add("@RecordCount", SqlDbType.Int);
                cmd.Parameters["@RecordCount"].Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery();

                int recordCount = Convert.ToInt32(cmd.Parameters["@RecordCount"].Value);

                if (recordCount > 0)
                {
                    MessageBox.Show("Selected Category has been allocated to a customer.\n\nThis category cannot be deleted.",
                        "Delete Category - Invalid");
                    transaction.Rollback();

                    deleteCheck.Dispose();
                    deleteCheck.Close();

                    DisplayCategories();
                    return;
                }

                string confirmMessage = "Category: " + lvCategoriesList.SelectedItems[0].SubItems[1].Text 
                    + "\n\nDo you wish delete this Category?";

                DialogResult userResponse = MessageBox.Show(confirmMessage, "Delete Selected Category", 
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

                if (userResponse == DialogResult.Yes)
                {

                    string deleteQuery = "sp_Categories_DeleteCategory";
                    cmd.CommandText = deleteQuery;
                    //cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@CategoryID", GlobalVariables.SelectedCategory);

                    cmd.ExecuteNonQuery();
                    cmd.Transaction.Commit();
                    //finish TRANSACTION after database has been altered
                }
                else
                {
                    transaction.Rollback();
                }
                deleteCheck.Close(); //if open was successful, then close the connection.
            }
            catch (Exception ex)
            {
                //transaction.rollback() - only works when open() and transaction are outside the try/catch block.
                deleteCheck.Close();
                MessageBox.Show("Unsuccessful " + ex);
            }

            //Code to refresh the view of the Customer List
            DisplayCategories();
        }

        private void BtnAddCategory_Click(object sender, EventArgs e)
        {
            GlobalVariables.CategoryAdd = true;
            GlobalVariables.SelectedCategory = 0;

            frmCategoryDetailsForm viewForm = new frmCategoryDetailsForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDisplayUpdateCategory_Click(object sender, EventArgs e)
        {
            //Check if a customer has been selected from the list - otherwise advise the user
            //check to see if a customer has been selected - otherwise advise user
            if (lvCategoriesList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Category to Update.");
                DisplayCategories();
                return;
            }

            //Store the currently selected customer to GlobalVariable.selectedCustomer
            GlobalVariables.CategoryAdd = false;
            GlobalVariables.SelectedCategory = int.Parse(lvCategoriesList.SelectedItems[0].Text);

            frmCategoryDetailsForm viewForm = new frmCategoryDetailsForm();
            viewForm.Show();
            this.Hide();
        }
        private void FrmCategoryMaintenance_Load(object sender, EventArgs e)
        {
            GlobalVariables.CategoryAdd= true;
            DisplayCategories();
        }

        private void DisplayCategories()
        {
            lvCategoriesList.Items.Clear();
            int recordCount = 0;
            lblNoRecordsToShow.Visible = false;

            string selectQuery = "sp_Categories_GetCategories";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CategoryID", 0);

                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    Categories category = new Categories(int.Parse(rdr["CategoryID"].ToString()),
                        rdr["Category"].ToString());

                    ListViewItem lvi = new ListViewItem(category.CategoryID.ToString());
                    lvi.SubItems.Add(category.Category);
                    lvCategoriesList.Items.Add(lvi);

                    recordCount++;
                }
                if (rdr != null)
                {
                    rdr.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unsuccessful " + ex);
            }

            if (recordCount == 0)
            {
                lblNoRecordsToShow.Visible = true;
            }
            return;
        }
    }
}
