﻿namespace InsuranceInterface.UIScreens
{
    partial class frmTutorialMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTutorialMainForm));
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTutuorialMainMenu = new System.Windows.Forms.Label();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.pbMenu = new System.Windows.Forms.PictureBox();
            this.rtbItemHelp = new System.Windows.Forms.RichTextBox();
            this.btnMaintenance = new System.Windows.Forms.Button();
            this.btnDetails = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.pbExitApplication = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbExitApplication)).BeginInit();
            this.SuspendLayout();
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 560);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 0;
            this.btnReturnToMainMenu.Text = "Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.Enabled = false;
            this.btnMainMenu.Location = new System.Drawing.Point(128, 560);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(121, 41);
            this.btnMainMenu.TabIndex = 1;
            this.btnMainMenu.Text = "Main Menu Help:";
            this.btnMainMenu.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(817, 456);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // lblTutuorialMainMenu
            // 
            this.lblTutuorialMainMenu.AutoSize = true;
            this.lblTutuorialMainMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblTutuorialMainMenu.Location = new System.Drawing.Point(13, 3);
            this.lblTutuorialMainMenu.Name = "lblTutuorialMainMenu";
            this.lblTutuorialMainMenu.Size = new System.Drawing.Size(260, 31);
            this.lblTutuorialMainMenu.TabIndex = 21;
            this.lblTutuorialMainMenu.Text = "Main Menu - Tutorial";
            // 
            // richTextBox11
            // 
            this.richTextBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.richTextBox11.Location = new System.Drawing.Point(850, 37);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.ReadOnly = true;
            this.richTextBox11.Size = new System.Drawing.Size(291, 517);
            this.richTextBox11.TabIndex = 0;
            this.richTextBox11.Text = resources.GetString("richTextBox11.Text");
            // 
            // pbMenu
            // 
            this.pbMenu.BackColor = System.Drawing.Color.Red;
            this.pbMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbMenu.Image = ((System.Drawing.Image)(resources.GetObject("pbMenu.Image")));
            this.pbMenu.Location = new System.Drawing.Point(14, 38);
            this.pbMenu.Name = "pbMenu";
            this.pbMenu.Size = new System.Drawing.Size(192, 120);
            this.pbMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMenu.TabIndex = 22;
            this.pbMenu.TabStop = false;
            this.pbMenu.MouseLeave += new System.EventHandler(this.pbMenu_MouseLeave);
            this.pbMenu.MouseHover += new System.EventHandler(this.pbMenu_MouseHover);
            // 
            // rtbItemHelp
            // 
            this.rtbItemHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.rtbItemHelp.Location = new System.Drawing.Point(14, 502);
            this.rtbItemHelp.Name = "rtbItemHelp";
            this.rtbItemHelp.Size = new System.Drawing.Size(817, 51);
            this.rtbItemHelp.TabIndex = 23;
            this.rtbItemHelp.Text = "Hover your mouse over an item / area above to get information about it.";
            // 
            // btnMaintenance
            // 
            this.btnMaintenance.Location = new System.Drawing.Point(283, 560);
            this.btnMaintenance.Name = "btnMaintenance";
            this.btnMaintenance.Size = new System.Drawing.Size(121, 41);
            this.btnMaintenance.TabIndex = 24;
            this.btnMaintenance.Text = "Maintenance Help:";
            this.btnMaintenance.UseVisualStyleBackColor = true;
            this.btnMaintenance.Click += new System.EventHandler(this.BtnMaintenance_Click);
            // 
            // btnDetails
            // 
            this.btnDetails.Location = new System.Drawing.Point(437, 560);
            this.btnDetails.Name = "btnDetails";
            this.btnDetails.Size = new System.Drawing.Size(121, 41);
            this.btnDetails.TabIndex = 25;
            this.btnDetails.Text = "Details Help:";
            this.btnDetails.UseVisualStyleBackColor = true;
            this.btnDetails.Click += new System.EventHandler(this.BtnDetails_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(589, 560);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(121, 41);
            this.btnSearch.TabIndex = 26;
            this.btnSearch.Text = "Search Help:";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // pbExitApplication
            // 
            this.pbExitApplication.Image = ((System.Drawing.Image)(resources.GetObject("pbExitApplication.Image")));
            this.pbExitApplication.Location = new System.Drawing.Point(21, 457);
            this.pbExitApplication.Name = "pbExitApplication";
            this.pbExitApplication.Size = new System.Drawing.Size(78, 30);
            this.pbExitApplication.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbExitApplication.TabIndex = 27;
            this.pbExitApplication.TabStop = false;
            this.pbExitApplication.MouseLeave += new System.EventHandler(this.PbExitApplication_MouseLeave);
            this.pbExitApplication.MouseHover += new System.EventHandler(this.pbExitApplication_MouseHover);
            // 
            // frmTutorialMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.pbExitApplication);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnDetails);
            this.Controls.Add(this.btnMaintenance);
            this.Controls.Add(this.rtbItemHelp);
            this.Controls.Add(this.pbMenu);
            this.Controls.Add(this.richTextBox11);
            this.Controls.Add(this.lblTutuorialMainMenu);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.pictureBox1);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmTutorialMainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tutorial - Main Menu";
            this.Load += new System.EventHandler(this.FrmTutorialMainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbExitApplication)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTutuorialMainMenu;
        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.PictureBox pbMenu;
        private System.Windows.Forms.RichTextBox rtbItemHelp;
        private System.Windows.Forms.Button btnMaintenance;
        private System.Windows.Forms.Button btnDetails;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.PictureBox pbExitApplication;
    }
}