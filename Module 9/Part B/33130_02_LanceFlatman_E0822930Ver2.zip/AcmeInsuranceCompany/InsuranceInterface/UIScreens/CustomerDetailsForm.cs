﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using InsuranceInterface;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmCustomerDetailsForm : Form
    {
        private Customers customer = new Customers();

        public frmCustomerDetailsForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //before leaving the details screen - check to see if the information has changed - verify with user they wish to exit without saving?
            if(!GlobalVariables.CustomerAdd) //only check when information is being updated
            {
                if (CustomerChangedDetails())
                {
                    DialogResult dialogResult = MessageBox.Show("Information has changed. Are you sure you wish to exit?",
                        "Exit without saving", MessageBoxButtons.YesNo);
                    if(dialogResult == DialogResult.No)
                    {
                        return;
                    }
                }
            }
            GlobalVariables.CustomerAdd = true;
            frmCustomerMaintenance viewForm = new frmCustomerMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void BtnVariousFunctions_Click(object sender, EventArgs e)
        {
            if (!CheckDetails()) //check to see if the entered details are valid
            {
                return;
            }
            string confirmMessage = "Do you wish to update this customer?";
            string confirmTitle = "Update Customer";
            if (GlobalVariables.CustomerAdd)
            {
                confirmMessage = "Do you wish to add a new customer?";
                confirmTitle = "Add Customer";                    
            }
            DialogResult userResponse = MessageBox.Show(confirmMessage, confirmTitle, MessageBoxButtons.YesNo);

            if (userResponse == DialogResult.Yes)
            {
                //Code to add or update the customer
                AddUpdateCustomer();
            }
            else
            {
                return;
            }
            GlobalVariables.CustomerAdd = true;
            frmCustomerMaintenance viewForm = new frmCustomerMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void FrmCustomerDetailsForm_Load(object sender, EventArgs e)
        {
            //Code to populate the Category List Box using the stored proceedure
            string selectQuery;
            //selectQuery = "sp_Categories_GetCategories";  I tried using the stored procedure but the order was by Category name
            selectQuery = "SELECT * FROM Categories ORDER BY CategoryID";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                //cmd.CommandType = CommandType.StoredProcedure;  couldn't use the stored procedure as it was in wrong order
                conn.Open();

                //SqlParameter categoryId = cmd.Parameters.AddWithValue("@CategoryID", 0);

                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    lbCategory.Items.Add(rdr["CategoryID"].ToString());
                    cbCategory.Items.Add(rdr["Category"].ToString());
                }
                if (rdr != null)
                    rdr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unsuccessful " + ex);
            }

            //check if adding or updating customer
            if (GlobalVariables.CustomerAdd)
            {
                //load a clear data form
                btnVariousFunctions.Text = "Add Customer:";
            }
            else
            {
                //load the existing data into the form as a class object and into the form
                btnVariousFunctions.Text = "Update Customer:";
                LoadCustomerDetails();
            }
        }

        private void AddUpdateCustomer()
        {
            if (!GlobalVariables.CustomerAdd)
            {
                customer.CustomerID = int.Parse(txtCustomerID.Text);
            }
            customer.FirstName = txtFirstName.Text;
            customer.LastName = txtLastName.Text;
            customer.CategoryID = int.Parse(lbCategory.Items[cbCategory.SelectedIndex].ToString());
            customer.Address = txtAddress.Text;
            customer.Suburb = txtSuburb.Text;
            customer.State = cbState.Text;
            customer.Gender = cbGender.Text.Substring(0,1);
            customer.Postcode = int.Parse(txtPostcode.Text);
            customer.BirthDate = dtpBirthDate.Value;

            string databaseAction;
            if (GlobalVariables.CustomerAdd)
            {
                databaseAction = "sp_Customers_CreateCustomer ";
            }
            else
            {
                databaseAction = "sp_Customers_UpdateCustomer ";
            }

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            conn.Open();

            SqlCommand cmd = new SqlCommand(databaseAction, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            if (!GlobalVariables.CustomerAdd)
            {
                cmd.Parameters.AddWithValue("@CustomerID", customer.CustomerID);
            }
            cmd.Parameters.AddWithValue("@CategoryID", customer.CategoryID);
            cmd.Parameters.AddWithValue("@FirstName", customer.FirstName);
            cmd.Parameters.AddWithValue("@LastName", customer.LastName);
            cmd.Parameters.AddWithValue("@Address", customer.Address);
            cmd.Parameters.AddWithValue("@Suburb", customer.Suburb);
            cmd.Parameters.AddWithValue("@State", customer.State);
            cmd.Parameters.AddWithValue("@Postcode", customer.Postcode);
            cmd.Parameters.AddWithValue("@Gender", customer.Gender);
            cmd.Parameters.AddWithValue("@BirthDate", customer.BirthDate);
            if (GlobalVariables.CustomerAdd)
            {
                cmd.Parameters.AddWithValue("@NewCustomerID", SqlDbType.Int).Direction = ParameterDirection.Output;
            }
            cmd.Transaction = conn.BeginTransaction();
            cmd.ExecuteNonQuery();
            cmd.Transaction.Commit();

            conn.Close();
        }

        private bool CheckDetails()  //used to check the information is correctly entered / if the information has been updated
        {
            string errorMessages = "";
            errorMessages = GlobalVariables.CheckName("First name", txtFirstName.Text);
            errorMessages += GlobalVariables.CheckName("Last name", txtLastName.Text);
            errorMessages += GlobalVariables.CheckName("Suburb", txtSuburb.Text);
            errorMessages += customer.CheckPostcode(cbState.Text, txtPostcode.Text);
            errorMessages += GlobalVariables.FieldBlank("Address", txtAddress.Text);
            errorMessages += GlobalVariables.FieldBlank("Gender", cbGender.Text);
            errorMessages += GlobalVariables.FieldBlank("State", cbState.Text);
            errorMessages += GlobalVariables.FieldBlank("Category", cbCategory.Text);
            errorMessages += customer.CheckBirthDate(dtpBirthDate.Value);
            if (errorMessages.Length > 0)
            {
                MessageBox.Show("The following information is incorrect:\n\n" + errorMessages,
                    "Incorrect Customer Information");
                return false;
            }
            return true; //entered information is technically valid
        }

        private bool CustomerChangedDetails()
        {
            if(!customer.FirstName.Equals(txtFirstName.Text) || !customer.LastName.Equals(txtLastName.Text) ||
                !customer.Address.Equals(txtAddress.Text) || !customer.Suburb.Equals(txtSuburb.Text) ||
                !customer.State.Equals(cbState.Text) || !txtPostcode.Text.Equals(customer.Postcode.ToString()) ||
                !customer.BirthDate.Equals(dtpBirthDate.Value) || !customer.Category.Equals(cbCategory.SelectedItem.ToString()))
            {
                return true;
            }
            return false;
        }

        private void LoadCustomerDetails()
        {
            string selectQuery = "sp_Customers_GetCustomers";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter categoryId = cmd.Parameters.AddWithValue("@CustomerID", GlobalVariables.SelectedCustomer);

                rdr = cmd.ExecuteReader();
                rdr.Read();

                //populate customer instance for verifying changes
                customer.CustomerID = int.Parse(rdr["CustomerID"].ToString());
                customer.FirstName = rdr["FirstName"].ToString();
                customer.LastName= rdr["LastName"].ToString();
                customer.Gender = rdr["Gender"].ToString();
                customer.CategoryID = int.Parse(rdr["CategoryID"].ToString());
                customer.Category = cbCategory.Items[int.Parse(rdr["CategoryID"].ToString()) - 1].ToString();
                customer.Address = rdr["Address"].ToString();
                customer.Suburb = rdr["Suburb"].ToString();
                customer.State = rdr["State"].ToString();
                customer.Postcode = int.Parse(rdr["PostCode"].ToString());
                customer.BirthDate = DateTime.Parse(rdr["BirthDate"].ToString());

                //populate form
                txtCustomerID.Text = rdr["CustomerID"].ToString();
                txtFirstName.Text = rdr["FirstName"].ToString();
                txtLastName.Text = rdr["LastName"].ToString();
                if (rdr["Gender"].ToString() == "M")
                    cbGender.Text = "Male";
                else
                    cbGender.Text = "Female";
                cbCategory.SelectedIndex = int.Parse(rdr["CategoryID"].ToString()) - 1;
                txtAddress.Text = rdr["Address"].ToString();
                txtSuburb.Text = rdr["Suburb"].ToString();
                cbState.Text = rdr["State"].ToString();
                txtPostcode.Text = rdr["PostCode"].ToString();
                dtpBirthDate.Value = DateTime.Parse(rdr["BirthDate"].ToString());

                rdr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("unsuccessful " + ex);
            }
        }
    }
}
