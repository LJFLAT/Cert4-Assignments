﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmTutorialSubFormSearch : Form
    {
        string originalText;

        public frmTutorialSubFormSearch()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void BtnMainMenu_Click(object sender, EventArgs e)
        {
            frmTutorialMainForm viewForm = new frmTutorialMainForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnMaintenance_Click(object sender, EventArgs e)
        {
            frmTutorialSubFormMaint viewForm = new frmTutorialSubFormMaint();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDetails_Click(object sender, EventArgs e)
        {
            frmTutorialSubFormDetails viewForm = new frmTutorialSubFormDetails();
            viewForm.Show();
            this.Hide();
        }

        private void PbReturnToMainMenu_MouseHover(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
            rtbItemHelp.Text = "This button takes you back to the Main Menu. From there you can select another" +
                "section to work within.";
        }

        private void PbReturnToMainMenu_MouseLeave(object sender, EventArgs e)
        {
            rtbItemHelp.Text = originalText;
        }

        private void PbAction_MouseHover(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
            rtbItemHelp.Text = "These buttons are used to Add, Display / Update and Delete information for the section " +
                "you are in. For Update and Delete you will need to click on the information screen above.";
        }

        private void PbAction_MouseLeave(object sender, EventArgs e)
        {
            rtbItemHelp.Text = originalText;
        }

        private void PbSearch_MouseHover(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
            pbFiltered.Visible = true;
            pbSearch.Visible = false;
            rtbItemHelp.Text = "The search button opens the search window (the list will display based upon your choice) " +
                "and will change the buttons colour. To remove a filter, click the button again.";
        }

        private void PbSearch_MouseLeave(object sender, EventArgs e)
        {
            rtbItemHelp.Text = originalText;
            pbFiltered.Visible = false;
            pbSearch.Visible = true;
        }

        private void pbSearchWindow_MouseHover(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
            pbFiltered.Visible = true;
            pbSearch.Visible = false;
            rtbItemHelp.Text = "The search window allows you to enter information into the various fields to limit the displayed" +
                "list of items. This will also change the Search / Filter button to advise a filter has been set.";
        }

        private void pbSearchWindow_MouseLeave(object sender, EventArgs e)
        {
            rtbItemHelp.Text = originalText;
            pbFiltered.Visible = false;
            pbSearch.Visible = true;
        }

        private void FrmTutorialSubFormSearch_Load(object sender, EventArgs e)
        {
            originalText = rtbItemHelp.Text;
        }
    }
}
