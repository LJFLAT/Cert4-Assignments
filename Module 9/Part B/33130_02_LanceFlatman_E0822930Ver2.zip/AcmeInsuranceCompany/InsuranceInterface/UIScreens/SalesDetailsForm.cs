﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmSalesDetailForm : Form
    {
        Sales sale = new Sales();

        public frmSalesDetailForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //before leaving the details screen - check to see if the information has changed - verify with user they wish to exit without saving?            if (!GlobalVariables.SaleAdd) //only check when information is being updated
            {
                if (!SaleChangedDetails() && !GlobalVariables.SaleAdd)
                {
                    DialogResult dialogResult = MessageBox.Show("Information has changed. Are you sure you wish to exit?",
                        "Exit without saving", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.No)
                    {
                        return;
                    }
                }
            }

            //reset the global search variables
            GlobalVariables.CustomerFilterReset();
            GlobalVariables.ProductFilterReset();

            GlobalVariables.SaleAdd = true;
            frmSalesMaintenance viewForm = new frmSalesMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void BtnVariousFunctions_Click(object sender, EventArgs e)
        {
            if (!CheckFields()) //a check to see if the entered fields are valid
            {
                return;
            }

            //Code for confirmation of a new category
            string confirmMessage = "Do you wish to update this sale?";
            string confirmTitle = "Update Sale";
            if (GlobalVariables.SaleAdd)
            {
                confirmMessage = "Do you wish to add a new sale?";
                confirmTitle = "Add Sale";
            }
            DialogResult userResponse = MessageBox.Show(confirmMessage, confirmTitle, MessageBoxButtons.YesNo);

            if (userResponse == DialogResult.Yes)
            {
                //Code to add or update the category
                AddUpdateSale();
            }
            else
            {
                return;
            }

            //reset the global search variables
            GlobalVariables.CustomerFilterReset();
            GlobalVariables.ProductFilterReset();

            GlobalVariables.SaleAdd = true;
            frmSalesMaintenance viewForm = new frmSalesMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void FrmSalesDetailForm_Load(object sender, EventArgs e)
        {
            if (GlobalVariables.SaleAdd)
            {
                //load a clear data form
                btnVariousFunctions.Text = "Add Sale:";
            }
            else
            {
                //load the existing data into the form as a class object
                btnVariousFunctions.Text = "Update Sale:";
                LoadSaleDetails();
            }
            //check to see if there is a filter on the customer data
            if (GlobalVariables.CustSearchFilterSet)
            {
                btnSearchFilterCustomer.Text = "Press to clear Customer filter:";
                btnSearchFilterCustomer.BackColor = Color.LightSteelBlue;
            }
            //check to see if there is a filter on the product data
            if (GlobalVariables.ProdSearchFilterSet)
            {
                btnSearchFilterProducts.Text = "Press to clear Product filter:";
                btnSearchFilterProducts.BackColor = Color.LightSteelBlue;
            }
            DisplayCustomers();
            DisplayProducts();
        }

        private void BtnSearchFilterCustomer_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the customer data - pressing the button clears the filter and resets the colour of the button.
            if (GlobalVariables.CustSearchFilterSet)
            {
                btnSearchFilterCustomer.Text = "Search / Filter Customer:";
                btnSearchFilterCustomer.BackColor = SystemColors.ControlLight;
                //reset the filter variables
                GlobalVariables.CustomerFilterReset();
            }
            else
            {
                frmCustomersSearchForm viewForm = new frmCustomersSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.CustSearchFilterSet)
                {
                    btnSearchFilterCustomer.Text = "Press to clear Customer filter:";
                    btnSearchFilterCustomer.BackColor = Color.LightSteelBlue;
                }
            }
            DisplayCustomers();
        }

        private void BtnSearchFilterProducts_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the product data - pressing the button clears 
            //the filter and resets the colour of the button.
            if (GlobalVariables.ProdSearchFilterSet)
            {
                btnSearchFilterProducts.Text = "Search / Filter Product:";
                btnSearchFilterProducts.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.ProductFilterReset();
            }
            else
            {
                frmProductsSearchForm viewForm = new frmProductsSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.ProdSearchFilterSet)
                {
                    btnSearchFilterProducts.Text = "Press to clear Product filter:";
                    btnSearchFilterProducts.BackColor = Color.LightSteelBlue;
                }
            }
            DisplayProducts();
        }
        
        private bool SaleChangedDetails()
        {
            if (!sale.CustomerID.Equals(txtCustomerID.Text) || !sale.ProductID.Equals(txtProductID.Text) || 
                !sale.Payable.Equals(cbPayable.Text) || !sale.StartDate.Equals(dtpStartDate.Value))
            {
                return false;
            }
            return true;
        }

        private bool CheckFields()
        {
            string errorMessages = "";
            errorMessages += GlobalVariables.FieldBlank("Customer ID", txtCustomerID.Text);
            errorMessages += GlobalVariables.FieldBlank("Product ID", txtProductID.Text);
            errorMessages += GlobalVariables.FieldBlank("Payable", cbPayable.Text);
            errorMessages += sale.CheckStartDate(dtpStartDate.Value);

            if (errorMessages.Length > 0)
            {
                MessageBox.Show("The following information is incorrect:\n\n" + errorMessages,
                    "Incorrect Category Information");
                return false;
            }
            return true; //entered information is technically valid
        }

        private void LoadSaleDetails()
        {
            string selectQuery = "SELECT " + GlobalVariables.CustomerDatabaseFields() + ", "
                + GlobalVariables.ProductsDatabaseFields() + ", " + GlobalVariables.SalesDatabaseFields() + " ";
            selectQuery += "FROM Sales INNER JOIN Customers ON Customers.CustomerID = Sales.CustomerID ";
            selectQuery += "INNER JOIN Products ON Products.ProductID = Sales.ProductID ";
            selectQuery += "WHERE SaleID = '" + GlobalVariables.SelectedSale + "'";
            
            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.Text;

                rdr = cmd.ExecuteReader();
                rdr.Read();

                string paymentCycle = "";

                switch (rdr["Payable"].ToString())
                {
                    case "Y":
                        {
                            paymentCycle = "Yearly";
                        }
                        break;
                    case "M":
                        {
                            paymentCycle = "Monthly";
                        }
                        break;
                    case "F":
                        {
                            paymentCycle = "Fortnightly";
                        }
                        break;
                }

                DateTime policyStart;
                policyStart = DateTime.Parse(rdr["StartDate"].ToString());

                //populate product instance for verifying changes
                sale.SaleID = int.Parse(rdr["SaleID"].ToString());
                sale.ProductID = int.Parse(rdr["ProductID"].ToString());
                sale.CustomerID = int.Parse(rdr["CustomerID"].ToString());
                sale.Payable = paymentCycle;
                sale.StartDate = policyStart;


                //populate form
                txtSaleID.Text = rdr["SaleID"].ToString();
                txtCustomerID.Text = rdr["CustomerID"].ToString();
                txtLastFirstname.Text = (rdr["FirstName"].ToString() + " " + rdr["LastName"].ToString());
                txtProductID.Text = rdr["ProductID"].ToString();
                txtProductName.Text = rdr["ProductName"].ToString();
                cbPayable.Text = paymentCycle;
                dtpStartDate.Value = policyStart;

                rdr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("unsuccessful " + ex);
            }
        }

        private void AddUpdateSale()
        {
            if (!GlobalVariables.SaleAdd)
            {
                sale.SaleID= int.Parse(txtSaleID.Text);
            }
            string paymentCycle = cbPayable.Text.Substring(0, 1);
            sale.ProductID = int.Parse(txtProductID.Text);
            sale.CustomerID = int.Parse(txtCustomerID.Text);
            sale.Payable = paymentCycle;
            sale.StartDate = dtpStartDate.Value;

            string databaseAction;
            if (GlobalVariables.SaleAdd)
            {
                databaseAction = "sp_Sales_CreateSale ";
            }
            else
            {
                databaseAction = "sp_Sales_UpdateSale ";
            }

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            conn.Open();

            SqlCommand cmd = new SqlCommand(databaseAction, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            if (!GlobalVariables.SaleAdd)
            {
                cmd.Parameters.AddWithValue("@SaleID", sale.SaleID);
            }
            cmd.Parameters.AddWithValue("@ProductID", sale.ProductID); //storedProcedure doesn't change ProductID on update
            cmd.Parameters.AddWithValue("@CustomerID", sale.CustomerID); //storedProdcedure doesn't change CustomerID on update
            cmd.Parameters.AddWithValue("@Payable", sale.Payable);
            cmd.Parameters.AddWithValue("@StartDate", sale.StartDate);
            if (GlobalVariables.SaleAdd)
            {
                cmd.Parameters.AddWithValue("@NewSaleID", SqlDbType.Int).Direction = ParameterDirection.Output;
            }
            cmd.Transaction = conn.BeginTransaction();
            cmd.ExecuteNonQuery();
            cmd.Transaction.Commit();

            conn.Close();
        }

        private void DisplayCustomers()
        {
            lvCustomerList.Items.Clear();
            int recordCount = 0;
            lblNoCustomersToShow.Visible = false;

            string selectQuery;

            selectQuery = "SELECT " + GlobalVariables.CustomerDatabaseFields() + ", " + GlobalVariables.CategoryDatabaseFields() + " ";
            selectQuery += "FROM Customers INNER JOIN Categories ON Customers.CategoryID = Categories.CategoryID ";

            if (GlobalVariables.CustSearchFilterSet)
            {
                selectQuery += "WHERE " + GlobalVariables.CustFilter();
            }

            selectQuery += " ORDER BY LastName";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    DateTime birthDate;
                    birthDate = DateTime.Parse(rdr["BirthDate"].ToString());

                    Customers customer = new Customers(int.Parse(rdr["CustomerID"].ToString()), int.Parse(rdr["CategoryID"].ToString()),
                        rdr["Category"].ToString(), rdr["FirstName"].ToString(), rdr["LastName"].ToString(), rdr["Address"].ToString(),
                        rdr["Suburb"].ToString(), rdr["State"].ToString(), int.Parse(rdr["Postcode"].ToString()),
                        rdr["Gender"].ToString(), birthDate);

                    ListViewItem lvi = new ListViewItem(customer.CustomerID.ToString());
                    lvi.SubItems.Add(customer.Category);
                    lvi.SubItems.Add(customer.FirstName);
                    lvi.SubItems.Add(customer.LastName);
                    lvi.SubItems.Add(customer.Address);
                    lvi.SubItems.Add(customer.Suburb);
                    lvi.SubItems.Add(customer.State);
                    lvi.SubItems.Add(customer.Postcode.ToString());
                    lvi.SubItems.Add(customer.BirthDate.ToString("dd/MM/yyyy"));
                    lvCustomerList.Items.Add(lvi);

                    recordCount++;
                }
                if (rdr != null)
                {
                    rdr.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unsuccessful " + ex);
            }

            if (recordCount == 0)
            {
                lblNoCustomersToShow.Visible = true;
            }
            return;
        }

        private void DisplayProducts()
        {
            lvProductList.Items.Clear();
            int recordCount = 0;
            lblNoProductsToShow.Visible = false;

            string selectQuery = "SELECT " + GlobalVariables.ProductsDatabaseFields() + ", "
                + GlobalVariables.ProductTypesDatabaseFields() + " FROM Products " +
                "INNER JOIN ProductTypes ON Products.ProductTypeID = ProductTypes.ProductTypeID ";

            if (GlobalVariables.ProdSearchFilterSet)
            {
                selectQuery += "WHERE " + GlobalVariables.ProdFilter();
            }

            selectQuery += " ORDER BY ProductType, ProductName";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ProductID", 0);

                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    Products product = new Products(int.Parse(rdr["ProductID"].ToString()),
                        int.Parse(rdr["ProductTypeID"].ToString()), rdr["ProductType"].ToString(), rdr["ProductName"].ToString(),
                        decimal.Parse(rdr["YearlyPremium"].ToString()));

                    //calculate the montly and fortnightly payments and hold as a string
                    string monthlyPremium = Math.Round((product.YearlyPremium / 12), 2).ToString("C2");
                    string fortnightlyPremium = Math.Round((product.YearlyPremium / 26), 2).ToString("C2");

                    ListViewItem lvi = new ListViewItem(product.ProductID.ToString());
                    lvi.SubItems.Add(product.ProductType);
                    lvi.SubItems.Add(product.ProductName);
                    lvi.SubItems.Add(product.YearlyPremium.ToString("C2"));
                    lvi.SubItems.Add(monthlyPremium);
                    lvi.SubItems.Add(fortnightlyPremium);
                    lvProductList.Items.Add(lvi);

                    recordCount++;
                }
                if (rdr != null)
                {
                    rdr.Close();
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unsuccessful " + ex);
            }

            if (recordCount == 0)
            {
                lblNoProductsToShow.Visible = true;
            }
            return;
        }

        private void LvCustomerList_Click(object sender, EventArgs e)
        {
            if (GlobalVariables.SaleAdd)
            {
                txtCustomerID.Text = lvCustomerList.SelectedItems[0].Text;
                txtLastFirstname.Text = lvCustomerList.SelectedItems[0].SubItems[2].Text + " "
                    + lvCustomerList.SelectedItems[0].SubItems[3].Text;
            }
        }

        private void LvProductList_Click(object sender, EventArgs e)
        {
            if (GlobalVariables.SaleAdd)
            {
                txtProductID.Text = lvProductList.SelectedItems[0].Text;
                txtProductName.Text = lvProductList.SelectedItems[0].SubItems[2].Text;
            }
        }
    }
}
