﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmAboutForm : Form
    {
        public frmAboutForm()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void FrmAboutForm_Load(object sender, EventArgs e)
        {
            rtbAbout.Text =
                "This software is owned by \b Tiama Investments Pty Ltd t/as Dreams Vision Reality \b0 and licensed to " +
                "Acme Insurance Company.\nThe functions and procedures created are Copyright 2019\n\n" +
                "This program was developed using C# with Microsoft Visual Studio 2019 Community (MSVS).\n" +
                "MSVS is owned by Microsoft Corporation and licensed to it's user. Redistributatble portions of MSVS\n" +
                "can be provided to end users. Full details on the Microsoft website.\n" +
                " https://visualstudio.microsoft.com/license-terms/mlt031819/ ";
        }
    }
}
