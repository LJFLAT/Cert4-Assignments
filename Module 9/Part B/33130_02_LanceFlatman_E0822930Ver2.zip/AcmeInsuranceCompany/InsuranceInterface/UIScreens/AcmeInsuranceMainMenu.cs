﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using InsuranceInterface;
using System.Data.SqlClient;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmAcmeInsuranceMainMenu : Form
    {
        public frmAcmeInsuranceMainMenu()
        {
            InitializeComponent();
        }

        private void btnExitApplication_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Do you wish to exit the program?", "Exit Application", MessageBoxButtons.YesNo))
            {
                Application.Exit();
            }
        }

        private void categoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCategoryMaintenance viewForm = new frmCategoryMaintenance();
            viewForm.Show();
            this.Hide();
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCustomerMaintenance viewForm = new frmCustomerMaintenance();
            //delayOpen();
            viewForm.Show();
            this.Hide();
        }

        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProductMaintenance viewForm = new frmProductMaintenance();
            viewForm.Show();
            this.Hide();
        }

        private void productTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProductTypesMaintenance viewForm = new frmProductTypesMaintenance();
            viewForm.Show();
            this.Hide();
        }

        private void salesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSalesMaintenance viewForm = new frmSalesMaintenance();
            viewForm.Show();
            this.Hide();
        }

        private void tutorialsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTutorialMainForm viewForm = new frmTutorialMainForm();
            viewForm.Show();
            this.Hide();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAboutForm viewForm = new frmAboutForm();
            viewForm.Show();
            this.Hide();
        }

        private void delayOpen()  // a proceedure to delay the opening of the maintenance forms as it was crashing when opening - due to auto resize of columns
        {
            for(int i = 0;i<1000;i++)
            {
            }
        }

        private void FrmAcmeInsuranceMainMenu_Load(object sender, EventArgs e)
        {
            DisplaySummary();
        }

        private void DisplaySummary()
        {
            lvProductSummary.Items.Clear();
            int recordCount = 0;
            txtPremiumSummary.Visible = false;

            string selectQuery = "SELECT SUM(Products.YearlyPremium) AS SumOfPayable, Products.ProductName AS ProductName, " +
                "ProductTypes.ProductType AS ProductType " +
                ", COUNT(Sales.SaleID) AS NumberSalesByProduct " +
                "FROM Products LEFT OUTER JOIN Sales ON Products.ProductID = Sales.ProductID " +
                "INNER JOIN ProductTypes ON ProductTypes.ProductTypeID = Products.ProductTypeID " +
                " GROUP BY ProductTypes.ProductType, Products.ProductName " +
                "ORDER BY ProductTypes.ProductType";

        //The data was showing all the relevant items with sales. I wanted to show all products including 
        //those without sales included. I referred to
        //https://stackoverflow.com/questions/5380929/joining-empty-table-to-return-all-rows

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.Text;
                rdr = cmd.ExecuteReader();

                decimal sumOfPayable, totalOfPayable = 0;
                int numberSalesByProduct;
                string product, productType;

                while (rdr.Read())
                {
                    product = rdr["ProductName"].ToString();
                    productType = rdr["ProductType"].ToString();
                    numberSalesByProduct = int.Parse(rdr["NumberSalesByProduct"].ToString());
                    if (numberSalesByProduct == 0)
                        sumOfPayable = 0;
                    else
                    {
                        sumOfPayable = decimal.Parse(rdr["SumOfPayable"].ToString());
                        totalOfPayable += decimal.Parse(rdr["SumOfPayable"].ToString());
                    }

                    ListViewItem lvi = new ListViewItem(product);
                    lvi.SubItems.Add(productType);
                    lvi.SubItems.Add(numberSalesByProduct.ToString());
                    lvi.SubItems.Add(sumOfPayable.ToString("C2"));
                    lvProductSummary.Items.Add(lvi);

                    recordCount++;
                }
                if (rdr != null)
                {
                    rdr.Close();
                }
                conn.Close();
                //txtPremiumSummary.Text = totalOfPayable.ToString("C2");
                lblPremiumSummary.Text += " " + totalOfPayable.ToString("C2"); //Changed this to show total after the label
            }
            catch (Exception ex)
            {
                MessageBox.Show("The application cannot connect to the database.\n" +
                    "This will now exit.\n\n" +
                    "Unsuccessful " + ex);
                Application.Exit();
            }

            if (recordCount == 0)
            {
                //lblNoRecordsToShow.Visible = true; - was used in other sections. may include this later.
            }
            return;
        }
    }
}
