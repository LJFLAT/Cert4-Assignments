﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using InsuranceInterface.Business_Logic_Layer;
using InsuranceInterface.Data_Access_Layer;

namespace InsuranceInterface.UIScreens
{
    public partial class frmProductTypesDetailForm : Form
    {
        ProductTypes productType = new ProductTypes();

        public frmProductTypesDetailForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //before leaving the details screen - check to see if the information has changed - verify with user they wish to exit without saving?
            if (!GlobalVariables.ProductTypeAdd) //only check when information is being updated
            {
                if (!ProductTypeChangedDetails())
                {
                    DialogResult dialogResult = MessageBox.Show("Information has changed. Are you sure you wish to exit?",
                        "Exit without saving", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.No)
                    {
                        return;
                    }
                }
            }
            GlobalVariables.ProductTypeAdd = true;
            frmProductTypesMaintenance viewForm = new frmProductTypesMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void FrmProductTypesDetailForm_Load(object sender, EventArgs e)
        {
            if (GlobalVariables.ProductTypeAdd)
            {
                //load a clear data form
                btnVariousFunctions.Text = "Add Product Type:";
            }
            else
            {
                //load the existing data into the form as a class object
                btnVariousFunctions.Text = "Update Product Type:";
                LoadProductTypeDetails();
            }
        }

        private void BtnVariousFunctions_Click(object sender, EventArgs e)
        {
            if (!CheckFields()) //a check to see if the entered fields are valid
            {
                return;
            }
            
            //Code for confirmation of a new Product Type
            string confirmMessage = "Do you wish to update this product type?";
            string confirmTitle = "Update Product Type";
            if (GlobalVariables.ProductTypeAdd)
            {
                confirmMessage = "Do you wish to add a new product type?";
                confirmTitle = "Add Product Type";
            }
            DialogResult userResponse = MessageBox.Show(confirmMessage, confirmTitle, MessageBoxButtons.YesNo);

            if (userResponse == DialogResult.Yes)
            {
                //Code to add or update the product type
                AddUpdateProductType();
            }
            else
            {
                return;
            }

            GlobalVariables.ProductTypeAdd= true;
            frmProductTypesMaintenance viewForm = new frmProductTypesMaintenance();
            viewForm.Show();
            this.Close();
        }
        private void LoadProductTypeDetails()
        {
            string selectQuery = "sp_ProductTypes_GetProductType";

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            SqlDataReader rdr = null;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(selectQuery, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter categoryId = 
                    cmd.Parameters.AddWithValue("@ProductTypeID", GlobalVariables.SelectedProductType);

                rdr = cmd.ExecuteReader();
                rdr.Read();

                //populate category instance for verifying changes
                productType.ProductTypeID = int.Parse(rdr["ProductTypeID"].ToString());
                productType.ProductType = rdr["ProductType"].ToString();

                //populate form
                txtProductTypeID.Text = rdr["ProductTypeID"].ToString();
                txtProductType.Text = rdr["ProductType"].ToString();

                rdr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("unsuccessful " + ex);
            }
        }

        private void AddUpdateProductType()
        {
            if (!GlobalVariables.ProductTypeAdd)
            {
                productType.ProductTypeID= int.Parse(txtProductTypeID.Text);
            }
            productType.ProductType= txtProductType.Text;

            string databaseAction;
            if (GlobalVariables.ProductTypeAdd)
            {
                databaseAction = "sp_ProductTypes_CreateProductType";
            }
            else
            {
                databaseAction = "sp_ProductTypes_UpdateProductType";
            }

            SqlConnection conn = ConnectionManager.DatabaseConnection();
            conn.Open();

            SqlCommand cmd = new SqlCommand(databaseAction, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            if (!GlobalVariables.ProductTypeAdd)
            {
                cmd.Parameters.AddWithValue("@ProductTypeID", productType.ProductTypeID);
            }
            cmd.Parameters.AddWithValue("@ProductType", productType.ProductType);
            if (GlobalVariables.ProductTypeAdd)
            {
                cmd.Parameters.AddWithValue("@NewProductTypeID", SqlDbType.Int).Direction = ParameterDirection.Output;
            }
            cmd.Transaction = conn.BeginTransaction();
            cmd.ExecuteNonQuery();
            cmd.Transaction.Commit();

            conn.Close();
        }

        private bool ProductTypeChangedDetails()
        {
            if (!productType.ProductType.Equals(txtProductType.Text))
            {
                return false;
            }
            return true;
        }

        private bool CheckFields()
        {
            string errorMessages = "";
            errorMessages += GlobalVariables.FieldBlank("Product Type", txtProductType.Text);
            if (errorMessages.Length > 0)
            {
                MessageBox.Show("The following information is incorrect:\n\n" + errorMessages,
                    "Incorrect Product Type Information");
                return false;
            }
            return true; //entered information is technically valid
        }
    }
}