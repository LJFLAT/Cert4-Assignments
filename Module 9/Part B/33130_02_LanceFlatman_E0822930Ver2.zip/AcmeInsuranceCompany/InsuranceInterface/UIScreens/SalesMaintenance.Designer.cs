﻿namespace InsuranceInterface.UIScreens
{
    partial class frmSalesMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeleteSelectedSalesEntry = new System.Windows.Forms.Button();
            this.btnDisplayUpdateSales = new System.Windows.Forms.Button();
            this.btnAddSales = new System.Windows.Forms.Button();
            this.btnSearchFilterCustomer = new System.Windows.Forms.Button();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.btnSearchFilterProducts = new System.Windows.Forms.Button();
            this.lblNoRecordsToShow = new System.Windows.Forms.Label();
            this.lvSalesList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // btnDeleteSelectedSalesEntry
            // 
            this.btnDeleteSelectedSalesEntry.Location = new System.Drawing.Point(435, 563);
            this.btnDeleteSelectedSalesEntry.Name = "btnDeleteSelectedSalesEntry";
            this.btnDeleteSelectedSalesEntry.Size = new System.Drawing.Size(121, 41);
            this.btnDeleteSelectedSalesEntry.TabIndex = 4;
            this.btnDeleteSelectedSalesEntry.Text = "Delete Selected Sales Entry:";
            this.btnDeleteSelectedSalesEntry.UseVisualStyleBackColor = true;
            this.btnDeleteSelectedSalesEntry.Click += new System.EventHandler(this.BtnDeleteSelectedSalesEntry_Click);
            // 
            // btnDisplayUpdateSales
            // 
            this.btnDisplayUpdateSales.Location = new System.Drawing.Point(281, 563);
            this.btnDisplayUpdateSales.Name = "btnDisplayUpdateSales";
            this.btnDisplayUpdateSales.Size = new System.Drawing.Size(121, 41);
            this.btnDisplayUpdateSales.TabIndex = 3;
            this.btnDisplayUpdateSales.Text = "Display / Update Selected Sales:";
            this.btnDisplayUpdateSales.UseVisualStyleBackColor = true;
            this.btnDisplayUpdateSales.Click += new System.EventHandler(this.BtnDisplayUpdateSales_Click);
            // 
            // btnAddSales
            // 
            this.btnAddSales.Location = new System.Drawing.Point(127, 563);
            this.btnAddSales.Name = "btnAddSales";
            this.btnAddSales.Size = new System.Drawing.Size(121, 41);
            this.btnAddSales.TabIndex = 2;
            this.btnAddSales.Text = "Add Sales:";
            this.btnAddSales.UseVisualStyleBackColor = true;
            this.btnAddSales.Click += new System.EventHandler(this.BtnAddSales_Click);
            // 
            // btnSearchFilterCustomer
            // 
            this.btnSearchFilterCustomer.Location = new System.Drawing.Point(592, 564);
            this.btnSearchFilterCustomer.Name = "btnSearchFilterCustomer";
            this.btnSearchFilterCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterCustomer.TabIndex = 5;
            this.btnSearchFilterCustomer.Text = "Search / Filter Customer:";
            this.btnSearchFilterCustomer.UseVisualStyleBackColor = true;
            this.btnSearchFilterCustomer.Click += new System.EventHandler(this.BtnSearchFilterCustomer_Click);
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 563);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 1;
            this.btnReturnToMainMenu.Text = "Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // btnSearchFilterProducts
            // 
            this.btnSearchFilterProducts.Location = new System.Drawing.Point(748, 564);
            this.btnSearchFilterProducts.Name = "btnSearchFilterProducts";
            this.btnSearchFilterProducts.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterProducts.TabIndex = 6;
            this.btnSearchFilterProducts.Text = "Search / Filter Product:";
            this.btnSearchFilterProducts.UseVisualStyleBackColor = true;
            this.btnSearchFilterProducts.Click += new System.EventHandler(this.BtnSearchFilterProducts_Click);
            // 
            // lblNoRecordsToShow
            // 
            this.lblNoRecordsToShow.AutoSize = true;
            this.lblNoRecordsToShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lblNoRecordsToShow.Location = new System.Drawing.Point(189, 288);
            this.lblNoRecordsToShow.Name = "lblNoRecordsToShow";
            this.lblNoRecordsToShow.Size = new System.Drawing.Size(794, 31);
            this.lblNoRecordsToShow.TabIndex = 7;
            this.lblNoRecordsToShow.Text = "No sales to display - please try a different filter or add some data.";
            this.lblNoRecordsToShow.Visible = false;
            // 
            // lvSalesList
            // 
            this.lvSalesList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11});
            this.lvSalesList.FullRowSelect = true;
            this.lvSalesList.GridLines = true;
            this.lvSalesList.Location = new System.Drawing.Point(12, 8);
            this.lvSalesList.MultiSelect = false;
            this.lvSalesList.Name = "lvSalesList";
            this.lvSalesList.Size = new System.Drawing.Size(1128, 549);
            this.lvSalesList.TabIndex = 8;
            this.lvSalesList.UseCompatibleStateImageBehavior = false;
            this.lvSalesList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Sale ID";
            this.columnHeader1.Width = 50;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "First Name";
            this.columnHeader2.Width = 95;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Last Name";
            this.columnHeader3.Width = 150;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Category";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 80;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Product";
            this.columnHeader5.Width = 180;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Product Type";
            this.columnHeader6.Width = 160;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Payment Cycle";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 90;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Premium";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader8.Width = 80;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Start Date";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader9.Width = 90;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Suburb";
            this.columnHeader10.Width = 100;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "State";
            this.columnHeader11.Width = 40;
            // 
            // frmSalesMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.lblNoRecordsToShow);
            this.Controls.Add(this.btnDeleteSelectedSalesEntry);
            this.Controls.Add(this.btnDisplayUpdateSales);
            this.Controls.Add(this.btnAddSales);
            this.Controls.Add(this.btnSearchFilterProducts);
            this.Controls.Add(this.btnSearchFilterCustomer);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.lvSalesList);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmSalesMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales Maintenance";
            this.Load += new System.EventHandler(this.FrmSalesMaintenance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnDeleteSelectedSalesEntry;
        private System.Windows.Forms.Button btnDisplayUpdateSales;
        private System.Windows.Forms.Button btnAddSales;
        private System.Windows.Forms.Button btnSearchFilterCustomer;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.Button btnSearchFilterProducts;
        private System.Windows.Forms.Label lblNoRecordsToShow;
        private System.Windows.Forms.ListView lvSalesList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
    }
}