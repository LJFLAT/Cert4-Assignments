﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceInterface
{
    public static class GlobalVariables
    {
        //Customer related variables
        private static bool customerAdd = true;
        private static int selectedCustomer=0;
        private static bool custSearchFilterSet = false;
        private static string custSearchLastName = "";
        private static string custSearchCategory = "";
        private static string custSearchState = "";
        private static string custSearchPostcode = "";

        private static bool categoryAdd = true;
        private static int selectedCategory = 0;

        //product related variables
        private static bool productAdd = true;
        private static int selectedProduct = 0;
        private static bool prodSearchFilterSet = false;
        private static string prodSearchProductName = "";
        private static string prodSearchProductType = "";

        private static bool productTypeAdd = true;
        private static int selectedProductType = 0;

        //sales related variables
        private static bool saleAdd = true;
        private static int selectedSale = 0;

        //Customer and category variables
        public static bool CustomerAdd
        {
            get { return customerAdd; }
            set { customerAdd = value; }
        }

        public static int SelectedCustomer
        {
            get { return selectedCustomer; }
            set { selectedCustomer = value; }
        }

        public static bool CustSearchFilterSet
        {
            get { return custSearchFilterSet; }
            set { custSearchFilterSet = value; }
        }                                     

        public static string CustSearchLastName
        {
            set { custSearchLastName = value; }
        }

        public static string CustSearchCategory
        {
            set { custSearchCategory = value; }
        }

        public static string CustSearchState
        {
            set { custSearchState = value; }
        }

        public static string CustSearchPostcode
        {
            set { custSearchPostcode = value; }
        }
        public static bool CategoryAdd
        {
            get { return categoryAdd; }
            set { categoryAdd = value; }
        }

        public static int SelectedCategory
        {
            get { return selectedCategory; }
            set { selectedCategory = value; }
        }        
        
        // product, productType, sale variables
        public static bool ProductAdd
        {
            get{ return productAdd; }
            set{ productAdd = value; }
        }

        public static int SelectedProduct
        {
            get { return selectedProduct; }
            set { selectedProduct = value; }
        }

        public static bool ProdSearchFilterSet
        {
            get { return prodSearchFilterSet; }
            set { prodSearchFilterSet = value; }
        }

        public static string ProdSearchProductName
        {
            set { prodSearchProductName = value; }
        }

        public static string ProdSearchProductType
        {
            set { prodSearchProductType = value; }
        }

        public static bool ProductTypeAdd
        {
            get { return productTypeAdd; }
            set { productTypeAdd = value; }
        }

        public static int SelectedProductType
        {
            get { return selectedProductType; }
            set { selectedProductType = value; }
        }

        public static bool SaleAdd
        {
            get { return saleAdd; }
            set { saleAdd = value; }
        }

        public static int SelectedSale
        {
            get { return selectedSale; }
            set { selectedSale = value; }
        }

        //Various Search Filter Section
        public static void CustomerFilterReset()
        {
            CustSearchFilterSet = false;
            CustSearchLastName = "";
            CustSearchCategory = "";
            CustSearchPostcode = "";
            CustSearchState = "";
        }

        public static void ProductFilterReset()
        {
            ProdSearchFilterSet = false;
            ProdSearchProductName = "";
            ProdSearchProductType = "";
        }

        //database filters for search functions
        public static string CustFilter()
        {
            string filterHoldValue = "";

            if (custSearchLastName.Length > 0)
            {
                filterHoldValue = "LastName LIKE ('%" + custSearchLastName + "%') ";
            }

            if (custSearchCategory.Length > 0)
            {
                filterHoldValue = concatFunc(filterHoldValue);
                filterHoldValue += "Category LIKE ('%" + custSearchCategory + "%') ";
            }

            if (custSearchState.Length > 0)
            {
                filterHoldValue = concatFunc(filterHoldValue);
                filterHoldValue += "State LIKE ('%" + custSearchState + "%') ";
            }

            if(custSearchPostcode.Length>0)
            {
                filterHoldValue = concatFunc(filterHoldValue);
                filterHoldValue += "Postcode LIKE ('%" + custSearchPostcode.ToString()+"%') ";
            }

            return filterHoldValue;
        }

        public static string ProdFilter()
        {
            string filterHoldValue = "";

            if (prodSearchProductName.Length > 0)
            {
                filterHoldValue = "ProductName LIKE ('%" + prodSearchProductName + "%') ";
            }
            if (prodSearchProductType.Length > 0)
            {
                filterHoldValue = concatFunc(filterHoldValue);
                filterHoldValue = "ProductType LIKE ('%" + prodSearchProductType + "%') ";
            }
            return filterHoldValue;
        }

        private static string concatFunc(string testValue)
        {
            if (testValue.Length > 0)
            {
                return testValue + "AND ";
            }
            else
            {
                return testValue;
            }
        }

        //Database fields used for database linking
        public static string CustomerDatabaseFields()
        {
            string customerDatabaseFields = "Customers.CustomerID, Customers.CategoryID, Customers.FirstName, Customers.LastName, Customers. Address, ";
            customerDatabaseFields += "Customers.Suburb, Customers.State, Customers.Postcode, Customers.Gender, Customers.BirthDate ";
            return customerDatabaseFields;
        }

        public static string CategoryDatabaseFields()
        {
            string categoryDatabaseFields = "Categories.CategoryID, Categories.Category ";
            return categoryDatabaseFields;
        }

        public static string ProductsDatabaseFields()
        {
            string productDatabaseFields = "Products.ProductID, Products.ProductTypeID, Products.ProductName, " +
                "Products.YearlyPremium ";
            return productDatabaseFields;
        }

        public static string ProductTypesDatabaseFields()
        {
            string productTypesDatabaseFields = "ProductTypes.ProductTypeID, ProductTypes.ProductType ";
            return productTypesDatabaseFields;
        }

        public static string SalesDatabaseFields()
        {
            string salesDatabaseFields = "Sales.SaleID, Sales.CustomerID, Sales.ProductID, Sales.Payable, Sales.StartDate ";
            return salesDatabaseFields;
        }

        //various tests for entered data
        public static string CheckName(string item, string name)
        {
            string errorMessage = "";
            errorMessage = GlobalVariables.FieldBlank(item, name);
            if (name.Any(char.IsDigit)) //found this online https://stackoverflow.com/questions/18251875/in-c-how-to-check-whether-a-string-contains-an-integer
            {
                errorMessage = item + " contains a number.\n"; //Concatenate this to the correct item being checked
            }
            return errorMessage;
        }

        public static string FieldBlank(string item, string name)
        {
            string errorMessage = "";
            if (name.Length == 0)
            {
                errorMessage = item + " is blank. Please enter information into this field.\n";
            }
            return errorMessage;
        }
    }   
}
