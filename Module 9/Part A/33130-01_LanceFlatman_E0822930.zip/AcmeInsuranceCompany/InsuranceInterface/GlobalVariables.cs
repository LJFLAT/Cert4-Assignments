﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceInterface
{
    static class GlobalVariables
    {
        //Customer related variables
        public static bool customerAdd = true;
        public static int selectedCustomer = 0;
        public static bool custSearchFilterSet = false;
        public static string custSearchLastName = "";
        public static string custSearchCategory = "";
        public static string custSearchState = "";
        public static string custSearchPostcode = "";

        public static bool categoryAdd = true;
        public static int selectedCategory = 0;

        //product related variables
        public static bool productAdd = true;
        public static int selectedProduct = 0;
        public static bool prodSearchFilterSet = false;
        public static string prodSearchProductName = "";
        public static string prodSearchProductType = "";

        public static bool productTypeAdd = true;
        public static int selectedProductType = 0;

        //sales related variables
        public static bool saleAdd = true;
        public static int selectedSale = 0;
    }
}
