﻿namespace InsuranceInterface.UIScreens
{
    partial class frmSalesDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVariousFunctions = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblSaleID = new System.Windows.Forms.Label();
            this.txtSaleID = new System.Windows.Forms.TextBox();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.dgvCustomerList = new System.Windows.Forms.DataGridView();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Suburb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.State = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Postcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvProductList = new System.Windows.Forms.DataGridView();
            this.ProductID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YearlyPremium = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.lblProductID = new System.Windows.Forms.Label();
            this.txtLastFirstname = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtPayable = new System.Windows.Forms.TextBox();
            this.lblPayable = new System.Windows.Forms.Label();
            this.lblStatrDate = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.btnSearchFilterCustomer = new System.Windows.Forms.Button();
            this.btnSearchFilterProducts = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnVariousFunctions
            // 
            this.btnVariousFunctions.Location = new System.Drawing.Point(127, 560);
            this.btnVariousFunctions.Name = "btnVariousFunctions";
            this.btnVariousFunctions.Size = new System.Drawing.Size(121, 41);
            this.btnVariousFunctions.TabIndex = 10;
            this.btnVariousFunctions.Text = "Add Sale:";
            this.btnVariousFunctions.UseVisualStyleBackColor = true;
            this.btnVariousFunctions.Click += new System.EventHandler(this.BtnVariousFunctions_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancel.Location = new System.Drawing.Point(12, 560);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(82, 41);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "&Cancel:";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // lblSaleID
            // 
            this.lblSaleID.AutoSize = true;
            this.lblSaleID.Location = new System.Drawing.Point(12, 9);
            this.lblSaleID.Name = "lblSaleID";
            this.lblSaleID.Size = new System.Drawing.Size(45, 13);
            this.lblSaleID.TabIndex = 7;
            this.lblSaleID.Text = "Sale ID:";
            // 
            // txtSaleID
            // 
            this.txtSaleID.Location = new System.Drawing.Point(79, 6);
            this.txtSaleID.Name = "txtSaleID";
            this.txtSaleID.ReadOnly = true;
            this.txtSaleID.Size = new System.Drawing.Size(100, 20);
            this.txtSaleID.TabIndex = 0;
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.Location = new System.Drawing.Point(79, 36);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.ReadOnly = true;
            this.txtCustomerID.Size = new System.Drawing.Size(100, 20);
            this.txtCustomerID.TabIndex = 1;
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(12, 39);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(68, 13);
            this.lblCustomerID.TabIndex = 9;
            this.lblCustomerID.Text = "Customer ID:";
            // 
            // dgvCustomerList
            // 
            this.dgvCustomerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomerList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CustomerID,
            this.Category,
            this.LastName,
            this.FirstName,
            this.Suburb,
            this.State,
            this.Postcode});
            this.dgvCustomerList.Location = new System.Drawing.Point(15, 65);
            this.dgvCustomerList.MultiSelect = false;
            this.dgvCustomerList.Name = "dgvCustomerList";
            this.dgvCustomerList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvCustomerList.Size = new System.Drawing.Size(1126, 207);
            this.dgvCustomerList.TabIndex = 3;
            // 
            // CustomerID
            // 
            this.CustomerID.HeaderText = "Customer ID:";
            this.CustomerID.Name = "CustomerID";
            // 
            // Category
            // 
            this.Category.HeaderText = "Category:";
            this.Category.Name = "Category";
            this.Category.Width = 160;
            // 
            // LastName
            // 
            this.LastName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.LastName.FillWeight = 50F;
            this.LastName.HeaderText = "Last Name:";
            this.LastName.Name = "LastName";
            // 
            // FirstName
            // 
            this.FirstName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FirstName.FillWeight = 50F;
            this.FirstName.HeaderText = "First Name:";
            this.FirstName.Name = "FirstName";
            // 
            // Suburb
            // 
            this.Suburb.HeaderText = "Suburb:";
            this.Suburb.Name = "Suburb";
            this.Suburb.Width = 180;
            // 
            // State
            // 
            this.State.HeaderText = "State:";
            this.State.Name = "State";
            this.State.Width = 60;
            // 
            // Postcode
            // 
            this.Postcode.HeaderText = "Postcode:";
            this.Postcode.Name = "Postcode";
            this.Postcode.Width = 80;
            // 
            // dgvProductList
            // 
            this.dgvProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductID,
            this.ProductName,
            this.ProductType,
            this.YearlyPremium});
            this.dgvProductList.Location = new System.Drawing.Point(15, 314);
            this.dgvProductList.MultiSelect = false;
            this.dgvProductList.Name = "dgvProductList";
            this.dgvProductList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvProductList.Size = new System.Drawing.Size(1126, 207);
            this.dgvProductList.TabIndex = 6;
            // 
            // ProductID
            // 
            this.ProductID.HeaderText = "Product ID:";
            this.ProductID.Name = "ProductID";
            // 
            // ProductName
            // 
            this.ProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProductName.HeaderText = "Product Name:";
            this.ProductName.Name = "ProductName";
            // 
            // ProductType
            // 
            this.ProductType.HeaderText = "Product Type:";
            this.ProductType.Name = "ProductType";
            this.ProductType.Width = 150;
            // 
            // YearlyPremium
            // 
            this.YearlyPremium.HeaderText = "Yearly Premium:";
            this.YearlyPremium.Name = "YearlyPremium";
            // 
            // txtProductID
            // 
            this.txtProductID.Location = new System.Drawing.Point(79, 284);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.ReadOnly = true;
            this.txtProductID.Size = new System.Drawing.Size(100, 20);
            this.txtProductID.TabIndex = 4;
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.Location = new System.Drawing.Point(12, 287);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(61, 13);
            this.lblProductID.TabIndex = 12;
            this.lblProductID.Text = "Product ID:";
            // 
            // txtLastFirstname
            // 
            this.txtLastFirstname.Location = new System.Drawing.Point(185, 36);
            this.txtLastFirstname.Name = "txtLastFirstname";
            this.txtLastFirstname.Size = new System.Drawing.Size(371, 20);
            this.txtLastFirstname.TabIndex = 2;
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(185, 284);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(371, 20);
            this.txtProductName.TabIndex = 5;
            // 
            // txtPayable
            // 
            this.txtPayable.Location = new System.Drawing.Point(66, 531);
            this.txtPayable.Name = "txtPayable";
            this.txtPayable.Size = new System.Drawing.Size(100, 20);
            this.txtPayable.TabIndex = 7;
            // 
            // lblPayable
            // 
            this.lblPayable.AutoSize = true;
            this.lblPayable.Location = new System.Drawing.Point(12, 534);
            this.lblPayable.Name = "lblPayable";
            this.lblPayable.Size = new System.Drawing.Size(48, 13);
            this.lblPayable.TabIndex = 14;
            this.lblPayable.Text = "Payable:";
            // 
            // lblStatrDate
            // 
            this.lblStatrDate.AutoSize = true;
            this.lblStatrDate.Location = new System.Drawing.Point(292, 538);
            this.lblStatrDate.Name = "lblStatrDate";
            this.lblStatrDate.Size = new System.Drawing.Size(58, 13);
            this.lblStatrDate.TabIndex = 14;
            this.lblStatrDate.Text = "Start Date:";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(356, 531);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(200, 20);
            this.dtpStartDate.TabIndex = 8;
            // 
            // btnSearchFilterCustomer
            // 
            this.btnSearchFilterCustomer.Location = new System.Drawing.Point(280, 560);
            this.btnSearchFilterCustomer.Name = "btnSearchFilterCustomer";
            this.btnSearchFilterCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterCustomer.TabIndex = 11;
            this.btnSearchFilterCustomer.Text = "Search / Filter Customer:";
            this.btnSearchFilterCustomer.UseVisualStyleBackColor = true;
            this.btnSearchFilterCustomer.Click += new System.EventHandler(this.BtnSearchFilterCustomer_Click);
            // 
            // btnSearchFilterProducts
            // 
            this.btnSearchFilterProducts.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnSearchFilterProducts.Location = new System.Drawing.Point(435, 560);
            this.btnSearchFilterProducts.Name = "btnSearchFilterProducts";
            this.btnSearchFilterProducts.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterProducts.TabIndex = 12;
            this.btnSearchFilterProducts.Text = "Search / Filter Product:";
            this.btnSearchFilterProducts.UseVisualStyleBackColor = false;
            this.btnSearchFilterProducts.Click += new System.EventHandler(this.BtnSearchFilterProducts_Click);
            // 
            // frmSalesDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.lblStatrDate);
            this.Controls.Add(this.txtPayable);
            this.Controls.Add(this.lblPayable);
            this.Controls.Add(this.txtProductID);
            this.Controls.Add(this.lblProductID);
            this.Controls.Add(this.dgvProductList);
            this.Controls.Add(this.dgvCustomerList);
            this.Controls.Add(this.txtProductName);
            this.Controls.Add(this.txtLastFirstname);
            this.Controls.Add(this.txtCustomerID);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.txtSaleID);
            this.Controls.Add(this.lblSaleID);
            this.Controls.Add(this.btnSearchFilterProducts);
            this.Controls.Add(this.btnSearchFilterCustomer);
            this.Controls.Add(this.btnVariousFunctions);
            this.Controls.Add(this.btnCancel);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmSalesDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales Detail Form";
            this.Load += new System.EventHandler(this.FrmSalesDetailForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVariousFunctions;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblSaleID;
        private System.Windows.Forms.TextBox txtSaleID;
        private System.Windows.Forms.TextBox txtCustomerID;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.DataGridView dgvCustomerList;
        private System.Windows.Forms.DataGridView dgvProductList;
        private System.Windows.Forms.TextBox txtProductID;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.TextBox txtLastFirstname;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.TextBox txtPayable;
        private System.Windows.Forms.Label lblPayable;
        private System.Windows.Forms.Label lblStatrDate;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.Button btnSearchFilterCustomer;
        private System.Windows.Forms.Button btnSearchFilterProducts;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Category;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastName;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Suburb;
        private System.Windows.Forms.DataGridViewTextBoxColumn State;
        private System.Windows.Forms.DataGridViewTextBoxColumn Postcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn YearlyPremium;
    }
}