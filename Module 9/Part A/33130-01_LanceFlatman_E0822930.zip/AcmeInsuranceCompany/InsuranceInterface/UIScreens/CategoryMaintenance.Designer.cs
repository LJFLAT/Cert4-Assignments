﻿namespace InsuranceInterface.UIScreens
{
    partial class frmCategoryMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvCategoryMaintenance = new System.Windows.Forms.DataGridView();
            this.CategoryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.btnDeleteSelectedCategory = new System.Windows.Forms.Button();
            this.btnDisplayUpdateCategory = new System.Windows.Forms.Button();
            this.btnAddCategory = new System.Windows.Forms.Button();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategoryMaintenance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvCategoryMaintenance
            // 
            this.dgvCategoryMaintenance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCategoryMaintenance.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CategoryID,
            this.Category});
            this.dgvCategoryMaintenance.Location = new System.Drawing.Point(12, 8);
            this.dgvCategoryMaintenance.Name = "dgvCategoryMaintenance";
            this.dgvCategoryMaintenance.Size = new System.Drawing.Size(1128, 549);
            this.dgvCategoryMaintenance.TabIndex = 0;
            // 
            // CategoryID
            // 
            this.CategoryID.FillWeight = 5F;
            this.CategoryID.HeaderText = "Category ID:";
            this.CategoryID.Name = "CategoryID";
            // 
            // Category
            // 
            this.Category.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Category.FillWeight = 95F;
            this.Category.HeaderText = "Category:";
            this.Category.Name = "Category";
            // 
            // btnDeleteSelectedCategory
            // 
            this.btnDeleteSelectedCategory.Location = new System.Drawing.Point(435, 563);
            this.btnDeleteSelectedCategory.Name = "btnDeleteSelectedCategory";
            this.btnDeleteSelectedCategory.Size = new System.Drawing.Size(121, 41);
            this.btnDeleteSelectedCategory.TabIndex = 4;
            this.btnDeleteSelectedCategory.Text = "Delete Selected Category:";
            this.btnDeleteSelectedCategory.UseVisualStyleBackColor = true;
            this.btnDeleteSelectedCategory.Click += new System.EventHandler(this.BtnDeleteSelectedCategory_Click);
            // 
            // btnDisplayUpdateCategory
            // 
            this.btnDisplayUpdateCategory.Location = new System.Drawing.Point(281, 563);
            this.btnDisplayUpdateCategory.Name = "btnDisplayUpdateCategory";
            this.btnDisplayUpdateCategory.Size = new System.Drawing.Size(121, 41);
            this.btnDisplayUpdateCategory.TabIndex = 3;
            this.btnDisplayUpdateCategory.Text = "Display / Update Selected Category:";
            this.btnDisplayUpdateCategory.UseVisualStyleBackColor = true;
            this.btnDisplayUpdateCategory.Click += new System.EventHandler(this.BtnDisplayUpdateCategory_Click);
            // 
            // btnAddCategory
            // 
            this.btnAddCategory.Location = new System.Drawing.Point(127, 563);
            this.btnAddCategory.Name = "btnAddCategory";
            this.btnAddCategory.Size = new System.Drawing.Size(121, 41);
            this.btnAddCategory.TabIndex = 2;
            this.btnAddCategory.Text = "Add Category:";
            this.btnAddCategory.UseVisualStyleBackColor = true;
            this.btnAddCategory.Click += new System.EventHandler(this.BtnAddCategory_Click);
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 563);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 1;
            this.btnReturnToMainMenu.Text = "&Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // frmCategoryMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.btnDeleteSelectedCategory);
            this.Controls.Add(this.btnDisplayUpdateCategory);
            this.Controls.Add(this.btnAddCategory);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.dgvCategoryMaintenance);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmCategoryMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Category Maintenance:";
            ((System.ComponentModel.ISupportInitialize)(this.dgvCategoryMaintenance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.DataGridView dgvCategoryMaintenance;
        private System.Windows.Forms.Button btnDeleteSelectedCategory;
        private System.Windows.Forms.Button btnDisplayUpdateCategory;
        private System.Windows.Forms.Button btnAddCategory;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.DataGridViewTextBoxColumn CategoryID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Category;
    }
}