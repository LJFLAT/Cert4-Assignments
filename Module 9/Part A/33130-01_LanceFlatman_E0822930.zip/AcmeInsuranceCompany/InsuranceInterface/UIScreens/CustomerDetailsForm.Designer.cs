﻿namespace InsuranceInterface.UIScreens
{
    partial class frmCustomerDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblBirthDate = new System.Windows.Forms.Label();
            this.grpOfficeUse = new System.Windows.Forms.GroupBox();
            this.grpPersonalDetails = new System.Windows.Forms.GroupBox();
            this.cbGender = new System.Windows.Forms.ComboBox();
            this.dtpBirthDate = new System.Windows.Forms.DateTimePicker();
            this.lblState = new System.Windows.Forms.Label();
            this.txtPostcode = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.cbState = new System.Windows.Forms.ComboBox();
            this.grpAddressDetails = new System.Windows.Forms.GroupBox();
            this.lblSuburb = new System.Windows.Forms.Label();
            this.txtSuburb = new System.Windows.Forms.TextBox();
            this.btnVariousFunctions = new System.Windows.Forms.Button();
            this.grpOfficeUse.SuspendLayout();
            this.grpPersonalDetails.SuspendLayout();
            this.grpAddressDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancel.Location = new System.Drawing.Point(12, 306);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(82, 41);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "&Cancel:";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(6, 21);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(68, 13);
            this.lblCustomerID.TabIndex = 7;
            this.lblCustomerID.Text = "Customer ID:";
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.Location = new System.Drawing.Point(80, 18);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.ReadOnly = true;
            this.txtCustomerID.Size = new System.Drawing.Size(147, 20);
            this.txtCustomerID.TabIndex = 2;
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(6, 58);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(52, 13);
            this.lblCategory.TabIndex = 9;
            this.lblCategory.Text = "Category:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(70, 18);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(234, 20);
            this.txtFirstName.TabIndex = 0;
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(6, 21);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 11;
            this.lblFirstName.Text = "First Name:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(70, 55);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(234, 20);
            this.txtLastName.TabIndex = 1;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(5, 58);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 13;
            this.lblLastName.Text = "Last Name:";
            // 
            // cbCategory
            // 
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Location = new System.Drawing.Point(80, 55);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(147, 21);
            this.cbCategory.TabIndex = 3;
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(6, 95);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(45, 13);
            this.lblGender.TabIndex = 22;
            this.lblGender.Text = "Gender:";
            // 
            // lblBirthDate
            // 
            this.lblBirthDate.AutoSize = true;
            this.lblBirthDate.Location = new System.Drawing.Point(6, 132);
            this.lblBirthDate.Name = "lblBirthDate";
            this.lblBirthDate.Size = new System.Drawing.Size(57, 13);
            this.lblBirthDate.TabIndex = 24;
            this.lblBirthDate.Text = "Birth Date:";
            // 
            // grpOfficeUse
            // 
            this.grpOfficeUse.Controls.Add(this.txtCustomerID);
            this.grpOfficeUse.Controls.Add(this.lblCustomerID);
            this.grpOfficeUse.Controls.Add(this.lblCategory);
            this.grpOfficeUse.Controls.Add(this.cbCategory);
            this.grpOfficeUse.Location = new System.Drawing.Point(351, 12);
            this.grpOfficeUse.Name = "grpOfficeUse";
            this.grpOfficeUse.Size = new System.Drawing.Size(244, 94);
            this.grpOfficeUse.TabIndex = 2;
            this.grpOfficeUse.TabStop = false;
            this.grpOfficeUse.Text = "Office Use:";
            // 
            // grpPersonalDetails
            // 
            this.grpPersonalDetails.Controls.Add(this.cbGender);
            this.grpPersonalDetails.Controls.Add(this.txtFirstName);
            this.grpPersonalDetails.Controls.Add(this.dtpBirthDate);
            this.grpPersonalDetails.Controls.Add(this.lblFirstName);
            this.grpPersonalDetails.Controls.Add(this.lblGender);
            this.grpPersonalDetails.Controls.Add(this.lblLastName);
            this.grpPersonalDetails.Controls.Add(this.lblBirthDate);
            this.grpPersonalDetails.Controls.Add(this.txtLastName);
            this.grpPersonalDetails.Location = new System.Drawing.Point(12, 12);
            this.grpPersonalDetails.Name = "grpPersonalDetails";
            this.grpPersonalDetails.Size = new System.Drawing.Size(319, 162);
            this.grpPersonalDetails.TabIndex = 0;
            this.grpPersonalDetails.TabStop = false;
            this.grpPersonalDetails.Text = "Personal Details:";
            // 
            // cbGender
            // 
            this.cbGender.FormattingEnabled = true;
            this.cbGender.Location = new System.Drawing.Point(70, 92);
            this.cbGender.Name = "cbGender";
            this.cbGender.Size = new System.Drawing.Size(100, 21);
            this.cbGender.TabIndex = 2;
            // 
            // dtpBirthDate
            // 
            this.dtpBirthDate.Location = new System.Drawing.Point(70, 127);
            this.dtpBirthDate.Name = "dtpBirthDate";
            this.dtpBirthDate.Size = new System.Drawing.Size(234, 20);
            this.dtpBirthDate.TabIndex = 3;
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(7, 86);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(35, 13);
            this.lblState.TabIndex = 17;
            this.lblState.Text = "State:";
            // 
            // txtPostcode
            // 
            this.txtPostcode.Location = new System.Drawing.Point(228, 84);
            this.txtPostcode.Name = "txtPostcode";
            this.txtPostcode.Size = new System.Drawing.Size(78, 20);
            this.txtPostcode.TabIndex = 7;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(72, 19);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(234, 20);
            this.txtAddress.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(167, 87);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Postcode:";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(6, 22);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(48, 13);
            this.lblAddress.TabIndex = 15;
            this.lblAddress.Text = "Address:";
            // 
            // cbState
            // 
            this.cbState.FormattingEnabled = true;
            this.cbState.Items.AddRange(new object[] {
            "WA",
            "ACT",
            "NSW",
            "VIC",
            "QLD",
            "SA",
            "TAS",
            "NT"});
            this.cbState.Location = new System.Drawing.Point(72, 84);
            this.cbState.Name = "cbState";
            this.cbState.Size = new System.Drawing.Size(77, 21);
            this.cbState.TabIndex = 6;
            this.cbState.Text = "WA";
            // 
            // grpAddressDetails
            // 
            this.grpAddressDetails.Controls.Add(this.cbState);
            this.grpAddressDetails.Controls.Add(this.lblSuburb);
            this.grpAddressDetails.Controls.Add(this.lblAddress);
            this.grpAddressDetails.Controls.Add(this.label7);
            this.grpAddressDetails.Controls.Add(this.txtSuburb);
            this.grpAddressDetails.Controls.Add(this.txtAddress);
            this.grpAddressDetails.Controls.Add(this.txtPostcode);
            this.grpAddressDetails.Controls.Add(this.lblState);
            this.grpAddressDetails.Location = new System.Drawing.Point(12, 180);
            this.grpAddressDetails.Name = "grpAddressDetails";
            this.grpAddressDetails.Size = new System.Drawing.Size(319, 119);
            this.grpAddressDetails.TabIndex = 1;
            this.grpAddressDetails.TabStop = false;
            this.grpAddressDetails.Text = "Address Details";
            // 
            // lblSuburb
            // 
            this.lblSuburb.AutoSize = true;
            this.lblSuburb.Location = new System.Drawing.Point(6, 54);
            this.lblSuburb.Name = "lblSuburb";
            this.lblSuburb.Size = new System.Drawing.Size(44, 13);
            this.lblSuburb.TabIndex = 15;
            this.lblSuburb.Text = "Suburb:";
            // 
            // txtSuburb
            // 
            this.txtSuburb.Location = new System.Drawing.Point(72, 51);
            this.txtSuburb.Name = "txtSuburb";
            this.txtSuburb.Size = new System.Drawing.Size(234, 20);
            this.txtSuburb.TabIndex = 5;
            // 
            // btnVariousFunctions
            // 
            this.btnVariousFunctions.Location = new System.Drawing.Point(127, 306);
            this.btnVariousFunctions.Name = "btnVariousFunctions";
            this.btnVariousFunctions.Size = new System.Drawing.Size(121, 41);
            this.btnVariousFunctions.TabIndex = 3;
            this.btnVariousFunctions.Text = "Add Customer:";
            this.btnVariousFunctions.UseVisualStyleBackColor = true;
            this.btnVariousFunctions.Click += new System.EventHandler(this.BtnVariousFunctions_Click);
            // 
            // frmCustomerDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 359);
            this.Controls.Add(this.btnVariousFunctions);
            this.Controls.Add(this.grpAddressDetails);
            this.Controls.Add(this.grpPersonalDetails);
            this.Controls.Add(this.grpOfficeUse);
            this.Controls.Add(this.btnCancel);
            this.MaximumSize = new System.Drawing.Size(623, 398);
            this.MinimumSize = new System.Drawing.Size(623, 398);
            this.Name = "frmCustomerDetailsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Details Form";
            this.Load += new System.EventHandler(this.FrmCustomerDetailsForm_Load);
            this.grpOfficeUse.ResumeLayout(false);
            this.grpOfficeUse.PerformLayout();
            this.grpPersonalDetails.ResumeLayout(false);
            this.grpPersonalDetails.PerformLayout();
            this.grpAddressDetails.ResumeLayout(false);
            this.grpAddressDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.TextBox txtCustomerID;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.ComboBox cbCategory;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblBirthDate;
        private System.Windows.Forms.GroupBox grpOfficeUse;
        private System.Windows.Forms.GroupBox grpPersonalDetails;
        private System.Windows.Forms.ComboBox cbGender;
        private System.Windows.Forms.DateTimePicker dtpBirthDate;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.TextBox txtPostcode;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.ComboBox cbState;
        private System.Windows.Forms.GroupBox grpAddressDetails;
        private System.Windows.Forms.Button btnVariousFunctions;
        private System.Windows.Forms.Label lblSuburb;
        private System.Windows.Forms.TextBox txtSuburb;
    }
}