﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmProductMaintenance : Form
    {
        public frmProductMaintenance()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            //Clear and reset the filters
            if (GlobalVariables.prodSearchFilterSet)
            {
                //reset the filter variables
                GlobalVariables.prodSearchFilterSet = false;
                GlobalVariables.prodSearchProductName = "";
                GlobalVariables.prodSearchProductType = "";

                //code to reset the filter on the data link

            }
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void BtnSearchFilterProducts_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the product data - pressing the button clears 
            //the filter and resets the colour of the button.
            if (GlobalVariables.prodSearchFilterSet)
            {
                btnSearchFilterProducts.Text = "Search / Filter Product:";
                btnSearchFilterProducts.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.prodSearchFilterSet = false;
                GlobalVariables.prodSearchProductName = "";
                GlobalVariables.prodSearchProductType = "";

                //code to reset the filter on the data link

            }
            else
            {
                frmProductsSearchForm viewForm = new frmProductsSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.prodSearchFilterSet)
                {
                    btnSearchFilterProducts.Text = "Press to clear Product filter:";
                    btnSearchFilterProducts.BackColor = Color.LightSteelBlue;

                    //code to filter the products being displayed

                }
            }
        }

        private void BtnDelectSelectedProduct_Click(object sender, EventArgs e)
        {
            //check to see if a product has been selected - otherwise advise user
            if (MessageBox.Show("Do you wish to continue?", "Delete Selected Product", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                //Code to delete the selected product

            }
            else
            {
                return;
            }
        }

        private void BtnAddProducts_Click(object sender, EventArgs e)
        {
            GlobalVariables.productAdd = true;
            frmProductDetailsForm viewForm = new frmProductDetailsForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDisplayUpdateSelectedProduct_Click(object sender, EventArgs e)
        {
            //Check if a product has been selected from the list - otherwise advise the user
            //Store the currently selected product to GlobalVariable.selectedProduct

            frmProductDetailsForm viewForm = new frmProductDetailsForm();
            GlobalVariables.productAdd = false;
            viewForm.Show();
            this.Hide();
        }
    }
}
