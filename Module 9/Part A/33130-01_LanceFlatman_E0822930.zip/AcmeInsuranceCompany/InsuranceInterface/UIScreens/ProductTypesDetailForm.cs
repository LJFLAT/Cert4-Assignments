﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmProductTypesDetailForm : Form
    {
        public frmProductTypesDetailForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {               
            //before leaving the details screen - check to see if the information has changed - verify with user they wish to exit without saving?
            GlobalVariables.productTypeAdd = true;
            frmProductTypesMaintenance viewForm = new frmProductTypesMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void FrmProductTypesDetailForm_Load(object sender, EventArgs e)
        {
            if (GlobalVariables.productTypeAdd)
            {
                //load a clear data form

                btnVariousFunctions.Text = "Add Product Type:";
            }
            else
            {
                //load the existing data into the form as a class object
                //when exiting the form - check to see if the data has changed. Do operations based upon this

                btnVariousFunctions.Text = "Update Product Type:";
            }
        }

        private void BtnVariousFunctions_Click(object sender, EventArgs e)
        {
            DialogResult userResponse = new DialogResult();
            if (GlobalVariables.productTypeAdd)
            {
                //Code for confirmation of a new Product Type
                userResponse = MessageBox.Show("Do you wish to add a new product type?", "Add Product Type", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
                if (userResponse == DialogResult.Yes)
                {
                    //Code to add a new product type
                }
                else
                {
                    return;
                }
            }
            else
            {
                //Code to see if details have been changed and if so confirm with user
                // if not stay on form (return)
                userResponse = MessageBox.Show("Do you wish to update this product type?", "Update Product Type", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
                if (userResponse == DialogResult.Yes)
                {
                    //Code to update the product type
                }
                else
                {
                    return;
                }
            }
            GlobalVariables.productTypeAdd= true;
            frmProductTypesMaintenance viewForm = new frmProductTypesMaintenance();
            viewForm.Show();
            this.Close();
        }
    }
}
