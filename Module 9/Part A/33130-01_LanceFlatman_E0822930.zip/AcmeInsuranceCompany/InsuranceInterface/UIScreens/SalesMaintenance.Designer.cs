﻿namespace InsuranceInterface.UIScreens
{
    partial class frmSalesMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvSalesMaintenance = new System.Windows.Forms.DataGridView();
            this.SaleID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Payable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDeleteSelectedSalesEntry = new System.Windows.Forms.Button();
            this.btnDisplayUpdateSales = new System.Windows.Forms.Button();
            this.btnAddSales = new System.Windows.Forms.Button();
            this.btnSearchFilterCustomer = new System.Windows.Forms.Button();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.btnSearchFilterProducts = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalesMaintenance)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvSalesMaintenance
            // 
            this.dgvSalesMaintenance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSalesMaintenance.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SaleID,
            this.CustomerName,
            this.ProductName,
            this.Payable,
            this.StartDate});
            this.dgvSalesMaintenance.Location = new System.Drawing.Point(12, 8);
            this.dgvSalesMaintenance.Name = "dgvSalesMaintenance";
            this.dgvSalesMaintenance.Size = new System.Drawing.Size(1128, 549);
            this.dgvSalesMaintenance.TabIndex = 0;
            // 
            // SaleID
            // 
            this.SaleID.FillWeight = 120F;
            this.SaleID.HeaderText = "Sale ID:";
            this.SaleID.Name = "SaleID";
            // 
            // CustomerName
            // 
            this.CustomerName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CustomerName.HeaderText = "Customer Name:";
            this.CustomerName.Name = "CustomerName";
            // 
            // ProductName
            // 
            this.ProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProductName.FillWeight = 95F;
            this.ProductName.HeaderText = "Product Name:";
            this.ProductName.Name = "ProductName";
            // 
            // Payable
            // 
            this.Payable.HeaderText = "Payable:";
            this.Payable.Name = "Payable";
            // 
            // StartDate
            // 
            this.StartDate.HeaderText = "Start Date:";
            this.StartDate.Name = "StartDate";
            this.StartDate.Width = 120;
            // 
            // btnDeleteSelectedSalesEntry
            // 
            this.btnDeleteSelectedSalesEntry.Location = new System.Drawing.Point(435, 563);
            this.btnDeleteSelectedSalesEntry.Name = "btnDeleteSelectedSalesEntry";
            this.btnDeleteSelectedSalesEntry.Size = new System.Drawing.Size(121, 41);
            this.btnDeleteSelectedSalesEntry.TabIndex = 4;
            this.btnDeleteSelectedSalesEntry.Text = "Delete Selected Sales Entry:";
            this.btnDeleteSelectedSalesEntry.UseVisualStyleBackColor = true;
            this.btnDeleteSelectedSalesEntry.Click += new System.EventHandler(this.BtnDeleteSelectedSalesEntry_Click);
            // 
            // btnDisplayUpdateSales
            // 
            this.btnDisplayUpdateSales.Location = new System.Drawing.Point(281, 563);
            this.btnDisplayUpdateSales.Name = "btnDisplayUpdateSales";
            this.btnDisplayUpdateSales.Size = new System.Drawing.Size(121, 41);
            this.btnDisplayUpdateSales.TabIndex = 3;
            this.btnDisplayUpdateSales.Text = "Display / Update Selected Sales:";
            this.btnDisplayUpdateSales.UseVisualStyleBackColor = true;
            this.btnDisplayUpdateSales.Click += new System.EventHandler(this.BtnDisplayUpdateSales_Click);
            // 
            // btnAddSales
            // 
            this.btnAddSales.Location = new System.Drawing.Point(127, 563);
            this.btnAddSales.Name = "btnAddSales";
            this.btnAddSales.Size = new System.Drawing.Size(121, 41);
            this.btnAddSales.TabIndex = 2;
            this.btnAddSales.Text = "Add Sales:";
            this.btnAddSales.UseVisualStyleBackColor = true;
            this.btnAddSales.Click += new System.EventHandler(this.BtnAddSales_Click);
            // 
            // btnSearchFilterCustomer
            // 
            this.btnSearchFilterCustomer.Location = new System.Drawing.Point(592, 564);
            this.btnSearchFilterCustomer.Name = "btnSearchFilterCustomer";
            this.btnSearchFilterCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterCustomer.TabIndex = 5;
            this.btnSearchFilterCustomer.Text = "Search / Filter Customer:";
            this.btnSearchFilterCustomer.UseVisualStyleBackColor = true;
            this.btnSearchFilterCustomer.Click += new System.EventHandler(this.BtnSearchFilterCustomer_Click);
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 563);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 1;
            this.btnReturnToMainMenu.Text = "Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // btnSearchFilterProducts
            // 
            this.btnSearchFilterProducts.Location = new System.Drawing.Point(748, 564);
            this.btnSearchFilterProducts.Name = "btnSearchFilterProducts";
            this.btnSearchFilterProducts.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterProducts.TabIndex = 6;
            this.btnSearchFilterProducts.Text = "Search / Filter Product:";
            this.btnSearchFilterProducts.UseVisualStyleBackColor = true;
            this.btnSearchFilterProducts.Click += new System.EventHandler(this.BtnSearchFilterProducts_Click);
            // 
            // frmSalesMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.btnDeleteSelectedSalesEntry);
            this.Controls.Add(this.btnDisplayUpdateSales);
            this.Controls.Add(this.btnAddSales);
            this.Controls.Add(this.btnSearchFilterProducts);
            this.Controls.Add(this.btnSearchFilterCustomer);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.dgvSalesMaintenance);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmSalesMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales Maintenance";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSalesMaintenance)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvSalesMaintenance;
        private System.Windows.Forms.Button btnDeleteSelectedSalesEntry;
        private System.Windows.Forms.Button btnDisplayUpdateSales;
        private System.Windows.Forms.Button btnAddSales;
        private System.Windows.Forms.Button btnSearchFilterCustomer;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.Button btnSearchFilterProducts;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaleID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Payable;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDate;
    }
}