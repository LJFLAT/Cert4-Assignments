﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmSalesMaintenance : Form
    {
        public frmSalesMaintenance()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            //Clear and reset the filters
            if (GlobalVariables.custSearchFilterSet)
            {
                //reset the filter variables
                GlobalVariables.custSearchFilterSet = false;
                GlobalVariables.custSearchLastName = "";
                GlobalVariables.custSearchPostcode = "";
                GlobalVariables.custSearchCategory = "";
                GlobalVariables.custSearchState = "";

                //code to reset the filter on the data link
            }

            if (GlobalVariables.prodSearchFilterSet)
            {
                //reset the filter variables
                GlobalVariables.prodSearchFilterSet = false;
                GlobalVariables.prodSearchProductName = "";
                GlobalVariables.prodSearchProductType = "";

                //code to reset the filter on the data link

            }

            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            GlobalVariables.saleAdd = true;
            this.Hide();
        }

        private void BtnSearchFilterCustomer_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the customer data - pressing the button clears the filter and resets the colour of the button.
            if (GlobalVariables.custSearchFilterSet)
            {
                btnSearchFilterCustomer.Text = "Search / Filter Customer:";
                btnSearchFilterCustomer.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.custSearchFilterSet = false;
                GlobalVariables.custSearchLastName = "";
                GlobalVariables.custSearchPostcode = "";
                GlobalVariables.custSearchCategory = "";
                GlobalVariables.custSearchState = "";

                //code to reset the filter on the data link
            }
            else
            {
                frmCustomersSearchForm viewForm = new frmCustomersSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.custSearchFilterSet)
                {
                    btnSearchFilterCustomer.Text = "Press to clear Customer filter:";
                    btnSearchFilterCustomer.BackColor = Color.LightSteelBlue;

                    //code to filter the customer being displayed

                }
            }
        }

        private void BtnSearchFilterProducts_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the product data - pressing the button clears 
            //the filter and resets the colour of the button.
            if (GlobalVariables.prodSearchFilterSet)
            {
                btnSearchFilterProducts.Text = "Search / Filter Product:";
                btnSearchFilterProducts.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.prodSearchFilterSet = false;
                GlobalVariables.prodSearchProductName = "";
                GlobalVariables.prodSearchProductType = "";

                //code to reset the filter on the data link

            }
            else
            {
                frmProductsSearchForm viewForm = new frmProductsSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.prodSearchFilterSet)
                {
                    btnSearchFilterProducts.Text = "Press to clear Product filter:";
                    btnSearchFilterProducts.BackColor = Color.LightSteelBlue;

                    //code to filter the products being displayed

                }
            }
        }

        private void BtnAddSales_Click(object sender, EventArgs e)
        {
            GlobalVariables.saleAdd = true;
            frmSalesDetailForm viewForm = new frmSalesDetailForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDisplayUpdateSales_Click(object sender, EventArgs e)
        {
            //Check if a sale has been selected from the list - otherwise advise the user
            //Store the currently selected customer to GlobalVariable.selectedSale
            GlobalVariables.saleAdd = false;
            frmSalesDetailForm viewForm = new frmSalesDetailForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDeleteSelectedSalesEntry_Click(object sender, EventArgs e)
        {
            //check to see if a customer has been selected - otherwise advise user
            if (MessageBox.Show("Do you wish to continue?", "Delete Selected Sale", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                //Code to delete the selected sale

            }
            else
            {
                return;
            }
        }
    }
}
