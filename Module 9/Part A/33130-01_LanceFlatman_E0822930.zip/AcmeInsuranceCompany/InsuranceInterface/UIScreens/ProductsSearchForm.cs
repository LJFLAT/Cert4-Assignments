﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmProductsSearchForm : Form
    {
        public frmProductsSearchForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnVariousFunctions_Click(object sender, EventArgs e)
        {
            //code to set the search / filter variables in the GlobalVariable Class
            GlobalVariables.prodSearchFilterSet = false;
            GlobalVariables.prodSearchProductName = "";
            GlobalVariables.prodSearchProductType = "";

            if (txtProductName.TextLength > 0)
            {
                GlobalVariables.prodSearchProductName = txtProductName.Text;
                GlobalVariables.prodSearchFilterSet = true;
            }
            if (txtProductType.TextLength > 0)
            {
                GlobalVariables.prodSearchProductType = txtProductType.Text;
                GlobalVariables.prodSearchFilterSet = true;
            }
            this.Close();
        }
    }
}
