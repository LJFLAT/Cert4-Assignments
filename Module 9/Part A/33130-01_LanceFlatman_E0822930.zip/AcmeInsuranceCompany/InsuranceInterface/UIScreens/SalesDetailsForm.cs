﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmSalesDetailForm : Form
    {
        public frmSalesDetailForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //Clear and reset the filters
            if (GlobalVariables.custSearchFilterSet)
            {
                //reset the filter variables
                GlobalVariables.custSearchFilterSet = false;
                GlobalVariables.custSearchLastName = "";
                GlobalVariables.custSearchPostcode = "";
                GlobalVariables.custSearchCategory = "";
                GlobalVariables.custSearchState = "";

                //code to reset the filter on the data link
            }

            if (GlobalVariables.prodSearchFilterSet)
            {
                //reset the filter variables
                GlobalVariables.prodSearchFilterSet = false;
                GlobalVariables.prodSearchProductName = "";
                GlobalVariables.prodSearchProductType = "";

                //code to reset the filter on the data link

            }

            //before leaving the details screen - check to see if the information has changed - verify with user they wish to exit without saving?
            GlobalVariables.saleAdd = true;
            frmSalesMaintenance viewForm = new frmSalesMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void BtnVariousFunctions_Click(object sender, EventArgs e)
        {
            DialogResult userResponse = new DialogResult();
            if (GlobalVariables.saleAdd)
            {
                //Code for confirmation of a new customer
                userResponse = MessageBox.Show("Do you wish to add a new sale?", "Add Sale", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
                if (userResponse == DialogResult.Yes)
                {
                    //Code to add a new customer
                }
                else
                {
                    return;
                }
            }
            else
            {
                //Code to see if details have been changed and if so confirm with user
                // if not stay on form (return)
                userResponse = MessageBox.Show("Do you wish to update this sale?", "Update Sale", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
                if (userResponse == DialogResult.Yes)
                {
                    //Code to update the customer
                }
                else
                {
                    return;
                }
            }

            //Clear and reset the filters
            if (GlobalVariables.custSearchFilterSet)
            {
                //reset the filter variables
                GlobalVariables.custSearchFilterSet = false;
                GlobalVariables.custSearchLastName = "";
                GlobalVariables.custSearchPostcode = "";
                GlobalVariables.custSearchCategory = "";
                GlobalVariables.custSearchState = "";

                //code to reset the filter on the data link
            }

            if (GlobalVariables.prodSearchFilterSet)
            {
                //reset the filter variables
                GlobalVariables.prodSearchFilterSet = false;
                GlobalVariables.prodSearchProductName = "";
                GlobalVariables.prodSearchProductType = "";

                //code to reset the filter on the data link

            }

            GlobalVariables.saleAdd = true;
            frmSalesMaintenance viewForm = new frmSalesMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void FrmSalesDetailForm_Load(object sender, EventArgs e)
        {
            if (GlobalVariables.saleAdd)
            {
                //load a clear data form

                btnVariousFunctions.Text = "Add Sale:";
            }
            else
            {
                //load the existing data into the form as a class object
                //when exiting the form - check to see if the data has changed. Do operations based upon this

                btnVariousFunctions.Text = "Update Sale:";
            }
            
            //check to see if there is a filter on the customer data
            if (GlobalVariables.custSearchFilterSet)
            {
                btnSearchFilterCustomer.Text = "Press to clear Customer filter:";
                btnSearchFilterCustomer.BackColor = Color.LightSteelBlue;

                //code to filter the customers being displayed

            }

            //check to see if there is a filter on the product data
            if (GlobalVariables.prodSearchFilterSet)
            {
                btnSearchFilterProducts.Text = "Press to clear Product filter:";
                btnSearchFilterProducts.BackColor = Color.LightSteelBlue;

                //code to filter the products being displayed

            }
        }

        private void BtnSearchFilterCustomer_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the customer data - pressing the button clears the filter and resets the colour of the button.
            if (GlobalVariables.custSearchFilterSet)
            {
                btnSearchFilterCustomer.Text = "Search / Filter Customer:";
                btnSearchFilterCustomer.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.custSearchFilterSet = false;
                GlobalVariables.custSearchLastName = "";
                GlobalVariables.custSearchPostcode = "";
                GlobalVariables.custSearchCategory = "";
                GlobalVariables.custSearchState = "";

                //code to reset the filter on the data link
            }
            else
            {
                frmCustomersSearchForm viewForm = new frmCustomersSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.custSearchFilterSet)
                {
                    btnSearchFilterCustomer.Text = "Press to clear Customer filter:";
                    btnSearchFilterCustomer.BackColor = Color.LightSteelBlue;

                    //code to filter the customer being displayed

                }
            }
        }

        private void BtnSearchFilterProducts_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the product data - pressing the button clears 
            //the filter and resets the colour of the button.
            if (GlobalVariables.prodSearchFilterSet)
            {
                btnSearchFilterProducts.Text = "Search / Filter Product:";
                btnSearchFilterProducts.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.prodSearchFilterSet = false;
                GlobalVariables.prodSearchProductName = "";
                GlobalVariables.prodSearchProductType = "";

                //code to reset the filter on the data link

            }
            else
            {
                frmProductsSearchForm viewForm = new frmProductsSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.prodSearchFilterSet)
                {
                    btnSearchFilterProducts.Text = "Press to clear Product filter:";
                    btnSearchFilterProducts.BackColor = Color.LightSteelBlue;

                    //code to filter the products being displayed

                }
            }
        }
    }
}
