﻿namespace InsuranceInterface.UIScreens
{
    partial class frmTutorialForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTutorialForm));
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.btnNextPage = new System.Windows.Forms.Button();
            this.btnPrviousPage = new System.Windows.Forms.Button();
            this.btnSearchFilterTopics = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 560);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 0;
            this.btnReturnToMainMenu.Text = "Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // btnNextPage
            // 
            this.btnNextPage.Location = new System.Drawing.Point(436, 560);
            this.btnNextPage.Name = "btnNextPage";
            this.btnNextPage.Size = new System.Drawing.Size(121, 41);
            this.btnNextPage.TabIndex = 3;
            this.btnNextPage.Text = "Next Page:";
            this.btnNextPage.UseVisualStyleBackColor = true;
            // 
            // btnPrviousPage
            // 
            this.btnPrviousPage.Location = new System.Drawing.Point(282, 560);
            this.btnPrviousPage.Name = "btnPrviousPage";
            this.btnPrviousPage.Size = new System.Drawing.Size(121, 41);
            this.btnPrviousPage.TabIndex = 2;
            this.btnPrviousPage.Text = "Previous Page:";
            this.btnPrviousPage.UseVisualStyleBackColor = true;
            // 
            // btnSearchFilterTopics
            // 
            this.btnSearchFilterTopics.Location = new System.Drawing.Point(128, 560);
            this.btnSearchFilterTopics.Name = "btnSearchFilterTopics";
            this.btnSearchFilterTopics.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterTopics.TabIndex = 1;
            this.btnSearchFilterTopics.Text = "Search / Filter Topics:";
            this.btnSearchFilterTopics.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(593, 329);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(13, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(429, 31);
            this.label1.TabIndex = 21;
            this.label1.Text = "Section 3.1 - Product Maintenance";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel1.Controls.Add(this.richTextBox10, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox9, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox8, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox7, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox6, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.richTextBox4, 0, 3);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(13, 372);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(587, 182);
            this.tableLayoutPanel1.TabIndex = 22;
            // 
            // richTextBox10
            // 
            this.richTextBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox10.Font = new System.Drawing.Font("Arial Narrow", 8F);
            this.richTextBox10.Location = new System.Drawing.Point(0, 144);
            this.richTextBox10.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.ReadOnly = true;
            this.richTextBox10.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox10.Size = new System.Drawing.Size(146, 38);
            this.richTextBox10.TabIndex = 8;
            this.richTextBox10.Text = "Delete Selected Product";
            // 
            // richTextBox9
            // 
            this.richTextBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox9.Font = new System.Drawing.Font("Arial Narrow", 7.5F);
            this.richTextBox9.Location = new System.Drawing.Point(146, 144);
            this.richTextBox9.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.ReadOnly = true;
            this.richTextBox9.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox9.Size = new System.Drawing.Size(441, 38);
            this.richTextBox9.TabIndex = 9;
            this.richTextBox9.Text = "Select a Product and click this button to delete the selected item. The user is r" +
    "equired to confirm their choice.";
            // 
            // richTextBox8
            // 
            this.richTextBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox8.Font = new System.Drawing.Font("Arial Narrow", 7.5F);
            this.richTextBox8.Location = new System.Drawing.Point(146, 108);
            this.richTextBox8.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.ReadOnly = true;
            this.richTextBox8.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox8.Size = new System.Drawing.Size(441, 36);
            this.richTextBox8.TabIndex = 7;
            this.richTextBox8.Text = "Select a Product and press this button to display or edit the selected products d" +
    "etails in full.";
            // 
            // richTextBox7
            // 
            this.richTextBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox7.Font = new System.Drawing.Font("Arial Narrow", 7.5F);
            this.richTextBox7.Location = new System.Drawing.Point(146, 72);
            this.richTextBox7.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.ReadOnly = true;
            this.richTextBox7.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox7.Size = new System.Drawing.Size(441, 36);
            this.richTextBox7.TabIndex = 5;
            this.richTextBox7.Text = "This button is used to add new products to the records.";
            // 
            // richTextBox6
            // 
            this.richTextBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox6.Font = new System.Drawing.Font("Arial Narrow", 7.5F);
            this.richTextBox6.Location = new System.Drawing.Point(146, 36);
            this.richTextBox6.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.ReadOnly = true;
            this.richTextBox6.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox6.Size = new System.Drawing.Size(441, 36);
            this.richTextBox6.TabIndex = 3;
            this.richTextBox6.Text = "The user is able can reduce the number of items displayed by entering search deta" +
    "ils on a separate screen.";
            // 
            // richTextBox5
            // 
            this.richTextBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox5.Font = new System.Drawing.Font("Arial Narrow", 7.5F);
            this.richTextBox5.Location = new System.Drawing.Point(146, 0);
            this.richTextBox5.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.ReadOnly = true;
            this.richTextBox5.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox5.Size = new System.Drawing.Size(441, 36);
            this.richTextBox5.TabIndex = 1;
            this.richTextBox5.Text = "This button takes the user back to the first screen where you can then choose oth" +
    "er menu options.";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.richTextBox1.Font = new System.Drawing.Font("Arial Narrow", 8F);
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox1.Size = new System.Drawing.Size(146, 36);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "Return to Main Menu";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox2.Font = new System.Drawing.Font("Arial Narrow", 8F);
            this.richTextBox2.Location = new System.Drawing.Point(0, 36);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox2.Size = new System.Drawing.Size(146, 36);
            this.richTextBox2.TabIndex = 2;
            this.richTextBox2.Text = "Select / Filter Products";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox3.Font = new System.Drawing.Font("Arial Narrow", 8F);
            this.richTextBox3.Location = new System.Drawing.Point(0, 72);
            this.richTextBox3.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.ReadOnly = true;
            this.richTextBox3.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox3.Size = new System.Drawing.Size(146, 36);
            this.richTextBox3.TabIndex = 4;
            this.richTextBox3.Text = "Add Product";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox4.Font = new System.Drawing.Font("Arial Narrow", 8F);
            this.richTextBox4.Location = new System.Drawing.Point(0, 108);
            this.richTextBox4.Margin = new System.Windows.Forms.Padding(0);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.ReadOnly = true;
            this.richTextBox4.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.richTextBox4.Size = new System.Drawing.Size(146, 36);
            this.richTextBox4.TabIndex = 6;
            this.richTextBox4.Text = "Display / Update Product";
            // 
            // richTextBox11
            // 
            this.richTextBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.richTextBox11.Location = new System.Drawing.Point(613, 37);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.ReadOnly = true;
            this.richTextBox11.Size = new System.Drawing.Size(528, 517);
            this.richTextBox11.TabIndex = 0;
            this.richTextBox11.Text = resources.GetString("richTextBox11.Text");
            // 
            // frmTutorialForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.richTextBox11);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnNextPage);
            this.Controls.Add(this.btnPrviousPage);
            this.Controls.Add(this.btnSearchFilterTopics);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmTutorialForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tutorial Form";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.Button btnNextPage;
        private System.Windows.Forms.Button btnPrviousPage;
        private System.Windows.Forms.Button btnSearchFilterTopics;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox11;
    }
}