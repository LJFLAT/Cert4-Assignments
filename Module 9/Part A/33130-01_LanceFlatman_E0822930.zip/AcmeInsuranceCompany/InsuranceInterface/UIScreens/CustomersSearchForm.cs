﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmCustomersSearchForm : Form
    {
        public frmCustomersSearchForm()
        {
            InitializeComponent();
        }

        private void BtnSetCustomerSearchCriteria_Click(object sender, EventArgs e)
        {
            //code to set the search / filter variables in the GlobalVariable Class
            GlobalVariables.custSearchFilterSet = false;
            GlobalVariables.custSearchLastName = "";
            GlobalVariables.custSearchCategory = "";
            GlobalVariables.custSearchPostcode = "";
            GlobalVariables.custSearchState = "";


            if (txtLastName.TextLength > 0)
            {
                GlobalVariables.custSearchLastName = txtLastName.Text;
                GlobalVariables.custSearchFilterSet = true;
            }
            if (txtCategory.TextLength > 0)
            {
                GlobalVariables.custSearchCategory = txtCategory.Text;
                GlobalVariables.custSearchFilterSet = true;
            }
            if (cbState.Text.Length > 0)
            {
                GlobalVariables.custSearchCategory = cbState.Text;
                GlobalVariables.custSearchFilterSet = true;
            }
            if (txtPostcode.TextLength > 0)
            {
                GlobalVariables.custSearchPostcode= txtPostcode.Text;
                GlobalVariables.custSearchFilterSet = true;
            }
            this.Close();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
