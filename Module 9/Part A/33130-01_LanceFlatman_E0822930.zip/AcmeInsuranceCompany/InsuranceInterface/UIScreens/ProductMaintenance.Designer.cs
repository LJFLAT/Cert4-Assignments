﻿namespace InsuranceInterface.UIScreens
{
    partial class frmProductMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvProductMaintenance = new System.Windows.Forms.DataGridView();
            this.ProductID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YearlyPremium = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDelectSelectedProduct = new System.Windows.Forms.Button();
            this.btnDisplayUpdateSelectedProduct = new System.Windows.Forms.Button();
            this.btnAddProducts = new System.Windows.Forms.Button();
            this.btnSearchFilterProducts = new System.Windows.Forms.Button();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductMaintenance)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvProductMaintenance
            // 
            this.dgvProductMaintenance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductMaintenance.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductID,
            this.ProductType,
            this.ProductName,
            this.YearlyPremium});
            this.dgvProductMaintenance.Location = new System.Drawing.Point(12, 8);
            this.dgvProductMaintenance.Name = "dgvProductMaintenance";
            this.dgvProductMaintenance.Size = new System.Drawing.Size(1128, 549);
            this.dgvProductMaintenance.TabIndex = 0;
            // 
            // ProductID
            // 
            this.ProductID.HeaderText = "Product ID:";
            this.ProductID.Name = "ProductID";
            this.ProductID.Width = 95;
            // 
            // ProductType
            // 
            this.ProductType.HeaderText = "Product Type:";
            this.ProductType.Name = "ProductType";
            this.ProductType.Width = 200;
            // 
            // ProductName
            // 
            this.ProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProductName.HeaderText = "Product Name:";
            this.ProductName.Name = "ProductName";
            // 
            // YearlyPremium
            // 
            this.YearlyPremium.HeaderText = "Yearly Premium:";
            this.YearlyPremium.Name = "YearlyPremium";
            this.YearlyPremium.Width = 120;
            // 
            // btnDelectSelectedProduct
            // 
            this.btnDelectSelectedProduct.Location = new System.Drawing.Point(435, 563);
            this.btnDelectSelectedProduct.Name = "btnDelectSelectedProduct";
            this.btnDelectSelectedProduct.Size = new System.Drawing.Size(121, 41);
            this.btnDelectSelectedProduct.TabIndex = 4;
            this.btnDelectSelectedProduct.Text = "Delete Selected Product:";
            this.btnDelectSelectedProduct.UseVisualStyleBackColor = true;
            this.btnDelectSelectedProduct.Click += new System.EventHandler(this.BtnDelectSelectedProduct_Click);
            // 
            // btnDisplayUpdateSelectedProduct
            // 
            this.btnDisplayUpdateSelectedProduct.Location = new System.Drawing.Point(281, 563);
            this.btnDisplayUpdateSelectedProduct.Name = "btnDisplayUpdateSelectedProduct";
            this.btnDisplayUpdateSelectedProduct.Size = new System.Drawing.Size(121, 41);
            this.btnDisplayUpdateSelectedProduct.TabIndex = 3;
            this.btnDisplayUpdateSelectedProduct.Text = "Display / Update Selected Product:";
            this.btnDisplayUpdateSelectedProduct.UseVisualStyleBackColor = true;
            this.btnDisplayUpdateSelectedProduct.Click += new System.EventHandler(this.BtnDisplayUpdateSelectedProduct_Click);
            // 
            // btnAddProducts
            // 
            this.btnAddProducts.Location = new System.Drawing.Point(127, 563);
            this.btnAddProducts.Name = "btnAddProducts";
            this.btnAddProducts.Size = new System.Drawing.Size(121, 41);
            this.btnAddProducts.TabIndex = 2;
            this.btnAddProducts.Text = "Add Product:";
            this.btnAddProducts.UseVisualStyleBackColor = true;
            this.btnAddProducts.Click += new System.EventHandler(this.BtnAddProducts_Click);
            // 
            // btnSearchFilterProducts
            // 
            this.btnSearchFilterProducts.Location = new System.Drawing.Point(592, 564);
            this.btnSearchFilterProducts.Name = "btnSearchFilterProducts";
            this.btnSearchFilterProducts.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterProducts.TabIndex = 5;
            this.btnSearchFilterProducts.Text = "Search / Filter Products:";
            this.btnSearchFilterProducts.UseVisualStyleBackColor = true;
            this.btnSearchFilterProducts.Click += new System.EventHandler(this.BtnSearchFilterProducts_Click);
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 563);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 1;
            this.btnReturnToMainMenu.Text = "&Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // frmProductMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.btnDelectSelectedProduct);
            this.Controls.Add(this.btnDisplayUpdateSelectedProduct);
            this.Controls.Add(this.btnAddProducts);
            this.Controls.Add(this.btnSearchFilterProducts);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.dgvProductMaintenance);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmProductMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Maintenance";
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductMaintenance)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvProductMaintenance;
        private System.Windows.Forms.Button btnDelectSelectedProduct;
        private System.Windows.Forms.Button btnDisplayUpdateSelectedProduct;
        private System.Windows.Forms.Button btnAddProducts;
        private System.Windows.Forms.Button btnSearchFilterProducts;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn YearlyPremium;
    }
}