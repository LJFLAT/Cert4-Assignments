﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmProductDetailsForm : Form
    {
        public frmProductDetailsForm()
        {
            InitializeComponent();
        }

        private void BtnSetCustomerSearchCriteria_Click(object sender, EventArgs e)
        {
            DialogResult userResponse = new DialogResult();
            if (GlobalVariables.productAdd)
            {
                //Code for confirmation of a new product
                userResponse = MessageBox.Show("Do you wish to add a new product?", "Add Product", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
                if (userResponse == DialogResult.Yes)
                {
                    //Code to add a new product
                }
                else
                {
                    return;
                }
            }
            else
            {
                //Code to see if details have been changed and if so confirm with user
                // if not stay on form (return)
                userResponse = MessageBox.Show("Do you wish to update this product?", "Update Product", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
                if (userResponse == DialogResult.Yes)
                {
                    //Code to update the product
                }
                else
                {
                    return;
                }
            }
            GlobalVariables.productAdd = true;
            frmProductMaintenance viewForm = new frmProductMaintenance();
            viewForm.Show();
            this.Close();
        }

        private void FrmProductDetailsForm_Load(object sender, EventArgs e)
        {
            if (GlobalVariables.productAdd)
            {
                //load a clear data form

                btnVariousFunctions.Text = "Add Product:";
            }
            else
            {
                //load the existing data into the form as a class object
                //when exiting the form - check to see if the data has changed. Do operations based upon this

                btnVariousFunctions.Text = "Update Product:";
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //before leaving the details screen - check to see if the information has changed - verify with user they wish to exit without saving?
            GlobalVariables.productAdd = true;
            frmProductMaintenance viewForm = new frmProductMaintenance();
            viewForm.Show();
            this.Close();
        }
    }
}
