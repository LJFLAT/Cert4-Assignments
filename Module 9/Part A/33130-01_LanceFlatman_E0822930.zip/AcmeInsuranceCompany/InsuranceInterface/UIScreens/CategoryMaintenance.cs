﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmCategoryMaintenance : Form
    {
        public frmCategoryMaintenance()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }

        private void BtnDeleteSelectedCategory_Click(object sender, EventArgs e)
        {
            //check to see if a category has been selected - otherwise advise user
            if(MessageBox.Show("Do you wish to continue?", "Delete Selected Category", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2)==DialogResult.Yes)
            {
                //Code to delete the selected category

            }
            else
            {
                return;
            }
        }

        private void BtnAddCategory_Click(object sender, EventArgs e)
        {
            GlobalVariables.categoryAdd = true;
            frmCategoryDetailsForm viewForm = new frmCategoryDetailsForm();
            viewForm.Show();
            this.Hide();
        }

        private void BtnDisplayUpdateCategory_Click(object sender, EventArgs e)
        {
            //Check if a customer has been selected from the list - otherwise advise the user
            //Store the currently selected customer to GlobalVariable.selectedCustomer
            GlobalVariables.categoryAdd = false;
            frmCategoryDetailsForm viewForm = new frmCategoryDetailsForm();
            viewForm.Show();
            this.Hide();
        }
    }
}
