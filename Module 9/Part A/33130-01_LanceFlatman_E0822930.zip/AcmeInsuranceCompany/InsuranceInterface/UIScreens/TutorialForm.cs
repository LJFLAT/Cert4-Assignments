﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmTutorialForm : Form
    {
        public frmTutorialForm()
        {
            InitializeComponent();
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Hide();
        }
    }
}
