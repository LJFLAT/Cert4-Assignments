﻿namespace InsuranceInterface.UIScreens
{
    partial class frmProductTypesDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVariousFunctions = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtProductType = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblProductType = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnVariousFunctions
            // 
            this.btnVariousFunctions.Location = new System.Drawing.Point(127, 130);
            this.btnVariousFunctions.Name = "btnVariousFunctions";
            this.btnVariousFunctions.Size = new System.Drawing.Size(121, 41);
            this.btnVariousFunctions.TabIndex = 3;
            this.btnVariousFunctions.Text = "Add Product Type:";
            this.btnVariousFunctions.UseVisualStyleBackColor = true;
            this.btnVariousFunctions.Click += new System.EventHandler(this.BtnVariousFunctions_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancel.Location = new System.Drawing.Point(12, 130);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(82, 41);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "&Cancel:";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // txtProductType
            // 
            this.txtProductType.Location = new System.Drawing.Point(103, 75);
            this.txtProductType.Name = "txtProductType";
            this.txtProductType.Size = new System.Drawing.Size(379, 20);
            this.txtProductType.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(103, 29);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(117, 20);
            this.textBox1.TabIndex = 0;
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(9, 32);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(88, 13);
            this.lblProduct.TabIndex = 27;
            this.lblProduct.Text = "Product Type ID:";
            // 
            // lblProductType
            // 
            this.lblProductType.AutoSize = true;
            this.lblProductType.Location = new System.Drawing.Point(9, 78);
            this.lblProductType.Name = "lblProductType";
            this.lblProductType.Size = new System.Drawing.Size(74, 13);
            this.lblProductType.TabIndex = 28;
            this.lblProductType.Text = "Product Type:";
            // 
            // frmProductTypesDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 183);
            this.ControlBox = false;
            this.Controls.Add(this.txtProductType);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblProduct);
            this.Controls.Add(this.lblProductType);
            this.Controls.Add(this.btnVariousFunctions);
            this.Controls.Add(this.btnCancel);
            this.MaximumSize = new System.Drawing.Size(513, 222);
            this.MinimumSize = new System.Drawing.Size(513, 222);
            this.Name = "frmProductTypesDetailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Types Detail Form";
            this.Load += new System.EventHandler(this.FrmProductTypesDetailForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnVariousFunctions;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtProductType;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblProductType;
    }
}