﻿namespace InsuranceInterface.UIScreens
{
    partial class frmCategoryDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVariousFunctions = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtCategoryID = new System.Windows.Forms.TextBox();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.txtCategory = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnVariousFunctions
            // 
            this.btnVariousFunctions.Location = new System.Drawing.Point(127, 130);
            this.btnVariousFunctions.Name = "btnVariousFunctions";
            this.btnVariousFunctions.Size = new System.Drawing.Size(121, 41);
            this.btnVariousFunctions.TabIndex = 3;
            this.btnVariousFunctions.Text = "Add Category:";
            this.btnVariousFunctions.UseVisualStyleBackColor = true;
            this.btnVariousFunctions.Click += new System.EventHandler(this.BtnVariousFunctions_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCancel.Location = new System.Drawing.Point(12, 130);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(82, 41);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "&Cancel:";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // txtCategoryID
            // 
            this.txtCategoryID.Location = new System.Drawing.Point(106, 29);
            this.txtCategoryID.Name = "txtCategoryID";
            this.txtCategoryID.ReadOnly = true;
            this.txtCategoryID.Size = new System.Drawing.Size(106, 20);
            this.txtCategoryID.TabIndex = 0;
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(12, 32);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(66, 13);
            this.lblCustomerID.TabIndex = 12;
            this.lblCustomerID.Text = "Category ID:";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(12, 78);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(52, 13);
            this.lblCategory.TabIndex = 13;
            this.lblCategory.Text = "Category:";
            // 
            // txtCategory
            // 
            this.txtCategory.Location = new System.Drawing.Point(106, 75);
            this.txtCategory.Name = "txtCategory";
            this.txtCategory.Size = new System.Drawing.Size(379, 20);
            this.txtCategory.TabIndex = 1;
            // 
            // frmCategoryDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 183);
            this.ControlBox = false;
            this.Controls.Add(this.txtCategory);
            this.Controls.Add(this.txtCategoryID);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.btnVariousFunctions);
            this.Controls.Add(this.btnCancel);
            this.MaximumSize = new System.Drawing.Size(513, 222);
            this.MinimumSize = new System.Drawing.Size(513, 222);
            this.Name = "frmCategoryDetailsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Category Details Form";
            this.Load += new System.EventHandler(this.FrmCategoryDetailsForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVariousFunctions;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtCategoryID;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.TextBox txtCategory;
    }
}