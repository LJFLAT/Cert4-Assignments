﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using InsuranceInterface;

namespace InsuranceInterface.UIScreens
{
    public partial class frmAcmeInsuranceMainMenu : Form
    {
        public frmAcmeInsuranceMainMenu()
        {
            InitializeComponent();
        }

        private void btnExitApplication_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Do you wish to exit the program?", "Exit Application", MessageBoxButtons.YesNo))
            {
                Application.Exit();
            }
        }

        private void categoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCategoryMaintenance viewForm = new frmCategoryMaintenance();
            viewForm.Show();
            this.Hide();
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCustomerMaintenance viewForm = new frmCustomerMaintenance();
            delayOpen();
            viewForm.Show();
            this.Hide();
        }

        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProductMaintenance viewForm = new frmProductMaintenance();
            viewForm.Show();
            this.Hide();
        }

        private void productTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProductTypesMaintenance viewForm = new frmProductTypesMaintenance();
            viewForm.Show();
            this.Hide();
        }

        private void salesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSalesMaintenance viewForm = new frmSalesMaintenance();
            viewForm.Show();
            this.Hide();
        }

        private void tutorialsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTutorialForm viewForm = new frmTutorialForm();
            viewForm.Show();
            this.Hide();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAboutForm viewForm = new frmAboutForm();
            viewForm.Show();
            this.Hide();
        }

        private void delayOpen()  // a proceedure to delay the opening of the maintenance forms as it was crashing when opening - due to auto resize of columns
        {
            for(int i = 0;i<1000;i++)
            {
            }
        }
    }
}
