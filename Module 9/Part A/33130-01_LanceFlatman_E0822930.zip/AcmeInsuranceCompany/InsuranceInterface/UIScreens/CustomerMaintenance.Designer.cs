﻿namespace InsuranceInterface.UIScreens
{
    partial class frmCustomerMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bindingSourceCustomer = new System.Windows.Forms.BindingSource(this.components);
            this.acmeDataSet = new InsuranceInterface.AcmeDataSet();
            this.customersTableAdapter = new InsuranceInterface.AcmeDataSetTableAdapters.CustomersTableAdapter();
            this.btnReturnToMainMenu = new System.Windows.Forms.Button();
            this.dgvCustomerMaintenance = new System.Windows.Forms.DataGridView();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Suburb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.State = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Postcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSearchFilterCustomer = new System.Windows.Forms.Button();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.btnDisplayUpdateCustomer = new System.Windows.Forms.Button();
            this.btnDeleteSelectedCustomer = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.acmeDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerMaintenance)).BeginInit();
            this.SuspendLayout();
            // 
            // bindingSourceCustomer
            // 
            this.bindingSourceCustomer.DataMember = "Customers";
            this.bindingSourceCustomer.DataSource = this.acmeDataSet;
            // 
            // acmeDataSet
            // 
            this.acmeDataSet.DataSetName = "AcmeDataSet";
            this.acmeDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // btnReturnToMainMenu
            // 
            this.btnReturnToMainMenu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnReturnToMainMenu.Location = new System.Drawing.Point(12, 564);
            this.btnReturnToMainMenu.Name = "btnReturnToMainMenu";
            this.btnReturnToMainMenu.Size = new System.Drawing.Size(82, 41);
            this.btnReturnToMainMenu.TabIndex = 1;
            this.btnReturnToMainMenu.Text = "&Return to Main Menu:";
            this.btnReturnToMainMenu.UseVisualStyleBackColor = false;
            this.btnReturnToMainMenu.Click += new System.EventHandler(this.BtnReturnToMainMenu_Click);
            // 
            // dgvCustomerMaintenance
            // 
            this.dgvCustomerMaintenance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomerMaintenance.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CustomerID,
            this.Category,
            this.FirstName,
            this.LastName,
            this.Address,
            this.Suburb,
            this.State,
            this.Postcode});
            this.dgvCustomerMaintenance.Location = new System.Drawing.Point(12, 8);
            this.dgvCustomerMaintenance.Name = "dgvCustomerMaintenance";
            this.dgvCustomerMaintenance.Size = new System.Drawing.Size(1128, 549);
            this.dgvCustomerMaintenance.TabIndex = 0;
            // 
            // CustomerID
            // 
            this.CustomerID.HeaderText = "Customer ID:";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.Width = 95;
            // 
            // Category
            // 
            this.Category.HeaderText = "Category:";
            this.Category.Name = "Category";
            this.Category.Width = 140;
            // 
            // FirstName
            // 
            this.FirstName.HeaderText = "First Name:";
            this.FirstName.Name = "FirstName";
            this.FirstName.Width = 160;
            // 
            // LastName
            // 
            this.LastName.HeaderText = "Last Name:";
            this.LastName.Name = "LastName";
            this.LastName.Width = 180;
            // 
            // Address
            // 
            this.Address.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Address.HeaderText = "Address:";
            this.Address.Name = "Address";
            // 
            // Suburb
            // 
            this.Suburb.HeaderText = "Suburb:";
            this.Suburb.Name = "Suburb";
            this.Suburb.Width = 170;
            // 
            // State
            // 
            this.State.HeaderText = "State:";
            this.State.Name = "State";
            this.State.Width = 65;
            // 
            // Postcode
            // 
            this.Postcode.HeaderText = "Postcode:";
            this.Postcode.Name = "Postcode";
            this.Postcode.Width = 70;
            // 
            // btnSearchFilterCustomer
            // 
            this.btnSearchFilterCustomer.BackColor = System.Drawing.SystemColors.Control;
            this.btnSearchFilterCustomer.Location = new System.Drawing.Point(592, 564);
            this.btnSearchFilterCustomer.Name = "btnSearchFilterCustomer";
            this.btnSearchFilterCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnSearchFilterCustomer.TabIndex = 5;
            this.btnSearchFilterCustomer.Text = "Search / Filter Customer:";
            this.btnSearchFilterCustomer.UseVisualStyleBackColor = false;
            this.btnSearchFilterCustomer.Click += new System.EventHandler(this.BtnSearchFilterCustomer_Click);
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.Location = new System.Drawing.Point(127, 563);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnAddCustomer.TabIndex = 2;
            this.btnAddCustomer.Text = "Add Customer:";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.BtnAddCustomer_Click);
            // 
            // btnDisplayUpdateCustomer
            // 
            this.btnDisplayUpdateCustomer.Location = new System.Drawing.Point(281, 564);
            this.btnDisplayUpdateCustomer.Name = "btnDisplayUpdateCustomer";
            this.btnDisplayUpdateCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnDisplayUpdateCustomer.TabIndex = 3;
            this.btnDisplayUpdateCustomer.Text = "Display / Update Selected Customer:";
            this.btnDisplayUpdateCustomer.UseVisualStyleBackColor = true;
            this.btnDisplayUpdateCustomer.Click += new System.EventHandler(this.BtnDisplayUpdateCustomer_Click);
            // 
            // btnDeleteSelectedCustomer
            // 
            this.btnDeleteSelectedCustomer.Location = new System.Drawing.Point(435, 563);
            this.btnDeleteSelectedCustomer.Name = "btnDeleteSelectedCustomer";
            this.btnDeleteSelectedCustomer.Size = new System.Drawing.Size(121, 41);
            this.btnDeleteSelectedCustomer.TabIndex = 4;
            this.btnDeleteSelectedCustomer.Text = "Delete Selected Customer:";
            this.btnDeleteSelectedCustomer.UseVisualStyleBackColor = true;
            this.btnDeleteSelectedCustomer.Click += new System.EventHandler(this.BtnDeleteSelectedCustomer_Click);
            // 
            // frmCustomerMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 613);
            this.ControlBox = false;
            this.Controls.Add(this.btnDeleteSelectedCustomer);
            this.Controls.Add(this.btnDisplayUpdateCustomer);
            this.Controls.Add(this.btnAddCustomer);
            this.Controls.Add(this.btnSearchFilterCustomer);
            this.Controls.Add(this.btnReturnToMainMenu);
            this.Controls.Add(this.dgvCustomerMaintenance);
            this.MaximumSize = new System.Drawing.Size(1169, 652);
            this.MinimumSize = new System.Drawing.Size(1169, 652);
            this.Name = "frmCustomerMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Maintenance";
            this.Load += new System.EventHandler(this.frmCustomerMaintenance_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.acmeDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerMaintenance)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource bindingSourceCustomer;
        private AcmeDataSet acmeDataSet;
        private AcmeDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private System.Windows.Forms.Button btnReturnToMainMenu;
        private System.Windows.Forms.DataGridView dgvCustomerMaintenance;
        private System.Windows.Forms.Button btnSearchFilterCustomer;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.Button btnDisplayUpdateCustomer;
        private System.Windows.Forms.Button btnDeleteSelectedCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Category;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirstName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Suburb;
        private System.Windows.Forms.DataGridViewTextBoxColumn State;
        private System.Windows.Forms.DataGridViewTextBoxColumn Postcode;
    }
}