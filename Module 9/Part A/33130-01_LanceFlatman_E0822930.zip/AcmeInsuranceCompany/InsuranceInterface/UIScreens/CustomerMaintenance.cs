﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InsuranceInterface.UIScreens
{
    public partial class frmCustomerMaintenance : Form
    {
        public frmCustomerMaintenance()
        {
            InitializeComponent();
            GlobalVariables.customerAdd = true;
        }

        private void frmCustomerMaintenance_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'acmeDataSet.Customers' table. You can move, or remove it, as needed.
            //this.customersTableAdapter.Fill(this.acmeDataSet.Customers);
            
            //if(GlobalVariables.custSearchFilterSet)
            //{
            //    btnSearchFilterCustomer.Text = "Press to clear filter:";
            //    btnSearchFilterCustomer.BackColor = Color.LightSteelBlue;
            //}
            //else
            //{
            //    btnSearchFilterCustomer.Text = "Search / Filter Customer:";
            //    btnSearchFilterCustomer.BackColor = SystemColors.ControlLight;
            //}
        }

        private void BtnReturnToMainMenu_Click(object sender, EventArgs e)
        {
            //Clear and reset the filters
            if (GlobalVariables.custSearchFilterSet)
            {
                //reset the filter variables
                GlobalVariables.custSearchFilterSet = false;
                GlobalVariables.custSearchLastName = "";
                GlobalVariables.custSearchPostcode = "";
                GlobalVariables.custSearchCategory = "";
                GlobalVariables.custSearchState = "";

                //code to reset the filter on the data link
            }
            frmAcmeInsuranceMainMenu mainForm = new frmAcmeInsuranceMainMenu();
            mainForm.Show();
            this.Close();
        }

        private void BtnAddCustomer_Click(object sender, EventArgs e)
        {
            GlobalVariables.customerAdd = true;
            frmCustomerDetailsForm viewForm = new frmCustomerDetailsForm();
            viewForm.Show();
            this.Hide();
        }
        private void BtnDisplayUpdateCustomer_Click(object sender, EventArgs e)
        {
            //Check if a customer has been selected from the list - otherwise advise the user
            //Store the currently selected customer to GlobalVariable.selectedCustomer
            frmCustomerDetailsForm viewForm = new frmCustomerDetailsForm();
            GlobalVariables.customerAdd = false;
            viewForm.Show();
            this.Hide();
        }
        private void BtnDeleteSelectedCustomer_Click(object sender, EventArgs e)
        {
            //check to see if a customer has been selected - otherwise advise user
            if(MessageBox.Show("Do you wish to continue?", "Delete Selected Customer", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2)==DialogResult.Yes)
            {
                //Code to delete the selected customer

            }
            else
            {
                return;
            }
        }

        private void BtnSearchFilterCustomer_Click(object sender, EventArgs e)
        {
            //check to see if there is a filter on the customer data - pressing the button clears the filter and resets the colour of the button.
            if (GlobalVariables.custSearchFilterSet)
            {
                btnSearchFilterCustomer.Text = "Search / Filter Customer:";
                btnSearchFilterCustomer.BackColor = SystemColors.ControlLight;

                //reset the filter variables
                GlobalVariables.custSearchFilterSet = false;
                GlobalVariables.custSearchLastName = "";
                GlobalVariables.custSearchPostcode = "";
                GlobalVariables.custSearchCategory = "";
                GlobalVariables.custSearchState = "";

                //code to reset the filter on the data link
            }
            else
            {
                frmCustomersSearchForm viewForm = new frmCustomersSearchForm();
                viewForm.ShowDialog();

                if (GlobalVariables.custSearchFilterSet)
                {
                    btnSearchFilterCustomer.Text = "Press to clear Customer filter:";
                    btnSearchFilterCustomer.BackColor = Color.LightSteelBlue;

                    //code to filter the customer being displayed

                }
            }
        }
    }
}
