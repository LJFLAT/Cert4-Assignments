﻿namespace TaxCalculator
{
    partial class TaxCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.txtDisplayEmployeeData = new System.Windows.Forms.TextBox();
            this.btnCreateEmployee = new System.Windows.Forms.Button();
            this.btnCalculateEmployeeTax = new System.Windows.Forms.Button();
            this.btnCreateContactor = new System.Windows.Forms.Button();
            this.btnCalculateContractorTax = new System.Windows.Forms.Button();
            this.txtEmployeeID = new System.Windows.Forms.TextBox();
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblSurname = new System.Windows.Forms.Label();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.lblGender = new System.Windows.Forms.Label();
            this.txtGender = new System.Windows.Forms.TextBox();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblHourlyRate = new System.Windows.Forms.Label();
            this.txtHourlyRate = new System.Windows.Forms.TextBox();
            this.cboDepartment = new System.Windows.Forms.ComboBox();
            this.lblHoursWorked = new System.Windows.Forms.Label();
            this.txtHoursWorked = new System.Windows.Forms.TextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.rtbLicenseInfo = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "TXT Files|*.txt";
            this.openFileDialog1.InitialDirectory = "..";
            // 
            // txtDisplayEmployeeData
            // 
            this.txtDisplayEmployeeData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtDisplayEmployeeData.Location = new System.Drawing.Point(28, 286);
            this.txtDisplayEmployeeData.Multiline = true;
            this.txtDisplayEmployeeData.Name = "txtDisplayEmployeeData";
            this.txtDisplayEmployeeData.ReadOnly = true;
            this.txtDisplayEmployeeData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDisplayEmployeeData.Size = new System.Drawing.Size(477, 295);
            this.txtDisplayEmployeeData.TabIndex = 0;
            this.txtDisplayEmployeeData.TabStop = false;
            // 
            // btnCreateEmployee
            // 
            this.btnCreateEmployee.Location = new System.Drawing.Point(346, 10);
            this.btnCreateEmployee.Name = "btnCreateEmployee";
            this.btnCreateEmployee.Size = new System.Drawing.Size(159, 23);
            this.btnCreateEmployee.TabIndex = 24;
            this.btnCreateEmployee.Text = "Create Employee";
            this.btnCreateEmployee.UseVisualStyleBackColor = true;
            this.btnCreateEmployee.Click += new System.EventHandler(this.btnCreateEmployee_Click);
            // 
            // btnCalculateEmployeeTax
            // 
            this.btnCalculateEmployeeTax.Enabled = false;
            this.btnCalculateEmployeeTax.Location = new System.Drawing.Point(346, 43);
            this.btnCalculateEmployeeTax.Name = "btnCalculateEmployeeTax";
            this.btnCalculateEmployeeTax.Size = new System.Drawing.Size(159, 23);
            this.btnCalculateEmployeeTax.TabIndex = 25;
            this.btnCalculateEmployeeTax.Text = "Calculate Employee Tax";
            this.btnCalculateEmployeeTax.UseVisualStyleBackColor = true;
            this.btnCalculateEmployeeTax.Click += new System.EventHandler(this.btnCalculateEmployeeTax_Click);
            // 
            // btnCreateContactor
            // 
            this.btnCreateContactor.Location = new System.Drawing.Point(346, 76);
            this.btnCreateContactor.Name = "btnCreateContactor";
            this.btnCreateContactor.Size = new System.Drawing.Size(159, 23);
            this.btnCreateContactor.TabIndex = 26;
            this.btnCreateContactor.Text = "Create Contractor";
            this.btnCreateContactor.UseVisualStyleBackColor = true;
            this.btnCreateContactor.Click += new System.EventHandler(this.btnCreateContactor_Click);
            // 
            // btnCalculateContractorTax
            // 
            this.btnCalculateContractorTax.Enabled = false;
            this.btnCalculateContractorTax.Location = new System.Drawing.Point(346, 109);
            this.btnCalculateContractorTax.Name = "btnCalculateContractorTax";
            this.btnCalculateContractorTax.Size = new System.Drawing.Size(159, 23);
            this.btnCalculateContractorTax.TabIndex = 27;
            this.btnCalculateContractorTax.Text = "Calculate Contractor Tax";
            this.btnCalculateContractorTax.UseVisualStyleBackColor = true;
            this.btnCalculateContractorTax.Click += new System.EventHandler(this.btnCalculateContractorTax_Click);
            // 
            // txtEmployeeID
            // 
            this.txtEmployeeID.Location = new System.Drawing.Point(110, 12);
            this.txtEmployeeID.Name = "txtEmployeeID";
            this.txtEmployeeID.Size = new System.Drawing.Size(217, 20);
            this.txtEmployeeID.TabIndex = 6;
            this.txtEmployeeID.TextChanged += new System.EventHandler(this.txtEmployeeID_TextChanged);
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Location = new System.Drawing.Point(34, 15);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.Size = new System.Drawing.Size(70, 13);
            this.lblEmployeeID.TabIndex = 7;
            this.lblEmployeeID.Text = "Employee ID:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(44, 48);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 9;
            this.lblFirstName.Text = "First Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(110, 45);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(217, 20);
            this.txtFirstName.TabIndex = 8;
            // 
            // lblSurname
            // 
            this.lblSurname.AutoSize = true;
            this.lblSurname.Location = new System.Drawing.Point(52, 81);
            this.lblSurname.Name = "lblSurname";
            this.lblSurname.Size = new System.Drawing.Size(52, 13);
            this.lblSurname.TabIndex = 11;
            this.lblSurname.Text = "Surname:";
            // 
            // txtSurname
            // 
            this.txtSurname.Location = new System.Drawing.Point(110, 78);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(217, 20);
            this.txtSurname.TabIndex = 10;
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(62, 114);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(42, 13);
            this.lblGender.TabIndex = 13;
            this.lblGender.Text = "Gender";
            // 
            // txtGender
            // 
            this.txtGender.Location = new System.Drawing.Point(110, 111);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(217, 20);
            this.txtGender.TabIndex = 12;
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Location = new System.Drawing.Point(39, 147);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(65, 13);
            this.lblDepartment.TabIndex = 15;
            this.lblDepartment.Text = "Department:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(69, 180);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.TabIndex = 17;
            this.lblEmail.Text = "Email:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(110, 177);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(217, 20);
            this.txtEmail.TabIndex = 16;
            // 
            // lblHourlyRate
            // 
            this.lblHourlyRate.AutoSize = true;
            this.lblHourlyRate.Location = new System.Drawing.Point(41, 213);
            this.lblHourlyRate.Name = "lblHourlyRate";
            this.lblHourlyRate.Size = new System.Drawing.Size(66, 13);
            this.lblHourlyRate.TabIndex = 19;
            this.lblHourlyRate.Text = "Hourly Rate:";
            // 
            // txtHourlyRate
            // 
            this.txtHourlyRate.Location = new System.Drawing.Point(110, 210);
            this.txtHourlyRate.Name = "txtHourlyRate";
            this.txtHourlyRate.Size = new System.Drawing.Size(217, 20);
            this.txtHourlyRate.TabIndex = 18;
            // 
            // cboDepartment
            // 
            this.cboDepartment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDepartment.FormattingEnabled = true;
            this.cboDepartment.Items.AddRange(new object[] {
            "Accounts",
            "Customer Service",
            "IT",
            "Administration"});
            this.cboDepartment.Location = new System.Drawing.Point(110, 144);
            this.cboDepartment.Name = "cboDepartment";
            this.cboDepartment.Size = new System.Drawing.Size(217, 21);
            this.cboDepartment.TabIndex = 14;
            // 
            // lblHoursWorked
            // 
            this.lblHoursWorked.AutoSize = true;
            this.lblHoursWorked.Location = new System.Drawing.Point(25, 248);
            this.lblHoursWorked.Name = "lblHoursWorked";
            this.lblHoursWorked.Size = new System.Drawing.Size(79, 13);
            this.lblHoursWorked.TabIndex = 22;
            this.lblHoursWorked.Text = "Hours Worked:";
            this.lblHoursWorked.Visible = false;
            // 
            // txtHoursWorked
            // 
            this.txtHoursWorked.Location = new System.Drawing.Point(110, 245);
            this.txtHoursWorked.Name = "txtHoursWorked";
            this.txtHoursWorked.Size = new System.Drawing.Size(217, 20);
            this.txtHoursWorked.TabIndex = 20;
            this.txtHoursWorked.Visible = false;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "PDF Files|*.pdf|All Files|*.*";
            // 
            // rtbLicenseInfo
            // 
            this.rtbLicenseInfo.Location = new System.Drawing.Point(346, 144);
            this.rtbLicenseInfo.Name = "rtbLicenseInfo";
            this.rtbLicenseInfo.ReadOnly = true;
            this.rtbLicenseInfo.Size = new System.Drawing.Size(159, 121);
            this.rtbLicenseInfo.TabIndex = 28;
            this.rtbLicenseInfo.Text = "This program uses iTextSharp available from: \nhttps://www.nuget.org/packages/iTex" +
    "tSharp/\nOwners: https://itextpdf.com/\nLicense info:\nhttp://www.gnu.org/licenses/" +
    "agpl.html";
            // 
            // TaxCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 595);
            this.Controls.Add(this.rtbLicenseInfo);
            this.Controls.Add(this.lblHoursWorked);
            this.Controls.Add(this.txtHoursWorked);
            this.Controls.Add(this.cboDepartment);
            this.Controls.Add(this.lblHourlyRate);
            this.Controls.Add(this.txtHourlyRate);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblDepartment);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.txtGender);
            this.Controls.Add(this.lblSurname);
            this.Controls.Add(this.txtSurname);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.lblEmployeeID);
            this.Controls.Add(this.txtEmployeeID);
            this.Controls.Add(this.btnCalculateContractorTax);
            this.Controls.Add(this.btnCreateContactor);
            this.Controls.Add(this.btnCalculateEmployeeTax);
            this.Controls.Add(this.btnCreateEmployee);
            this.Controls.Add(this.txtDisplayEmployeeData);
            this.Name = "TaxCalculator";
            this.Text = "TaxCalculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox txtDisplayEmployeeData;
        private System.Windows.Forms.Button btnCreateEmployee;
        private System.Windows.Forms.Button btnCalculateEmployeeTax;
        private System.Windows.Forms.Button btnCreateContactor;
        private System.Windows.Forms.Button btnCalculateContractorTax;
        private System.Windows.Forms.TextBox txtEmployeeID;
        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblSurname;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.TextBox txtGender;
        private System.Windows.Forms.Label lblDepartment;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblHourlyRate;
        private System.Windows.Forms.TextBox txtHourlyRate;
        private System.Windows.Forms.ComboBox cboDepartment;
        private System.Windows.Forms.Label lblHoursWorked;
        private System.Windows.Forms.TextBox txtHoursWorked;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.RichTextBox rtbLicenseInfo;
    }
}

