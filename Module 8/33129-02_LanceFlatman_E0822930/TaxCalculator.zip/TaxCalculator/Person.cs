﻿using System;

namespace TaxCalculator
{
    class Person
    {
        private string firstName;
        private string surname;
        private string gender;

        public Person()
        {
        }

        public Person(string firstName, string surname, string gender)
        {
            this.firstName = firstName;
            this.surname = surname;
            this.gender = gender;
        }

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public string CheckFirstName(string firstName)
        {
            if (firstName == "")
                return "First Name needs to be filled out.\n\r";
            return "";
        }
            
        public string CheckSurname(string surname)
        {
            if (surname == "")
                return "Surname needs to be filled out.\n\r";
            return "";
        }

        public string CheckGender(string gender)
        {
            if (!string.Equals(gender.Trim(), "male", StringComparison.CurrentCultureIgnoreCase) && !string.Equals(gender.Trim(), "female", StringComparison.CurrentCultureIgnoreCase))
                return "Employee Gender requires 'Male or Female'\n\r";
            return "";
        }
    }

    class Employee : Person
    {
        private string employeeID;
        private string department;
        private string email;
        private double hourlyRate;
        private double tax;

        public Employee()
        {
        }

        public Employee(string firstName, string surname, string gender, string employeeID, string department, string email, double hourlyRate)
            : base(firstName, surname, gender)
        {
            this.employeeID = employeeID;
            this.department = department;
            this.email = email;
            this.hourlyRate = hourlyRate;
        }

        public string EmployeeID
        {
            get { return employeeID; }
            set { employeeID = value; }
        }
            
        public string Department
        {
            get { return department; }
            set { department = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public double HourlyRate
        {
            get { return hourlyRate; }
            set { hourlyRate = value; }
        }

        public double Tax
        {
            get { return tax; }
            set { tax = value; }
        }

        public string CheckEmployeeID(string employeeID)
        {
            int checkEmployeeIDNumber = 0;
            try
            {
                if (employeeID.Length == 0 || employeeID.Length > 5)
                    return "EmployeeID needs to start with a 'E', and be within 1001-9999 range\n\r";
                if (employeeID.Substring(0, 1) != "E")
                    return "Employee ID needs to start with 'E' and be greater than 1001-9999\n\r";
                checkEmployeeIDNumber = Convert.ToInt16(employeeID.Substring(1, 4));
                if (checkEmployeeIDNumber < 1001 || checkEmployeeIDNumber > 9999)
                    return "EmployeeID needs to be between 1001 and 9999\n\r";
            }
            catch
            {
                return "EmployeeID needs to start with a 'E', and be within 1001-9999 range\n\r";
            }

            return "";
        }

        public string CheckEmail(string email)
        {
            //https://docs.microsoft.com/en-us/dotnet/api/system.string.contains?view=netframework-4.7.2
            if(!(email.Contains("@") && (email.Contains(".com") || email.Contains(".net"))))
                return "Email needs to contain a '@' and either '.com' or '.net'\n\r";
            return "";

        }

        public string CheckHourlyRate(string hourlyRate)
        {
            if (hourlyRate.Length == 0)
                return "Hourly Rate needs to be entered.\n\r";

            try
            {
                if (Convert.ToDouble(hourlyRate) > 100)
                    return "Hourly Rate is greater than $100.\n\r";
                //Additional code to override could be provided here - outside of the scope of this assignment.
            }
            catch
            {
                return "Hourly Rate needs to be a decimal.\n\r"+Environment.NewLine;
            }
            return "";
        }

        public string CheckDepartment(int department)
        {
            if (department < 0)
                return "Department requires a selection from the list.\n\r";
            return "";
        }

        public string DepartmentEnum(int department)
        {
            try
            {
                switch (department)
                {
                    case 0:
                        return "Accounts";
                    case 1:
                        return "Customer Service";
                    case 2:
                        return "IT";
                    case 3:
                        return "Administration";
                }
            }

            catch (Exception)
            {
                return "Invalid";
            }

            return "";
        }

        public void ResetEmployeeData()
        {
            this.EmployeeID = "";
            this.FirstName = "";
            this.Surname = "";
            this.Gender = "";
            this.Department = "";
            this.Email = "";
            this.HourlyRate = 0;
        }
    }

    class Contractor : Employee
    {
        private double hoursWorked;

        public Contractor()
        {
        }

        public Contractor(string firstName, string surname, string gender, string employeeID, string department, string email, double hourlyRate, double hoursWorked) 
            : base(firstName, surname, gender, employeeID, department, email, hourlyRate)
        {
            this.HourlyRate = hourlyRate;
        }

        public double HoursWorked
        {
            get { return hoursWorked; }
            set { hoursWorked= value; }
        }

        public new string CheckEmployeeID(string employeeID)
        {
            int checkEmployeeIDNumber = 0;

            try
            {
                if (employeeID.Length == 0 || employeeID.Length > 5)
                    return "EmployeeID needs to start with a 'C', and be within 1001-9999 range\n\r";
                if (employeeID.Substring(0, 1) != "C")
                    return "Employee ID needs to start with 'C' and be greater than 1001-9999\n\r";
                checkEmployeeIDNumber = Convert.ToInt16(employeeID.Substring(1, 4));
                if (checkEmployeeIDNumber < 1001 || checkEmployeeIDNumber > 9999)
                    return "EmployeeID needs to be between 1001 and 9999\n\r";
            }
            catch
            {
                return "EmployeeID needs to start with a 'C', and be within 1001-9999 range\n\r";
            }
            return "";
        }

        public string CheckHoursWorked(string hoursWorked)
        {
            if (hoursWorked.Length == 0)
                return "Hours Worked needs to be filled out.\n\r";

            try
            {
                if (Convert.ToDouble(hoursWorked) > 80)
                    return "Hours Worked is greater than 80.\n\r";
                //Additional code to override could be provided here - outside of the scope of this assignment.
            }
            catch
            {
                return "Hours Worked needs to be a decimal.\n\r";
            }
            return "";
        }
    }
}
