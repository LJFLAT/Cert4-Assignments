﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Image = iTextSharp.text.Image;

namespace TaxCalculator
{
    public partial class TaxCalculator : Form
    {
        private List<int> taxRateLevels = new List<int>();
        private List<double> taxRateRates = new List<double>();
        double CONTRACTOR_TAX_RATE = 0.2;

        public TaxCalculator()
        {
            //Copyright(c) 1998 - 2018 iText Group NV http://itextpdf.com/ GNU Affero General Public License http://www.gnu.org/licenses/agpl.html

            InitializeComponent();
        }


        Employee employee1 = new Employee();
        Contractor contractor1 = new Contractor();

        private void Form1_Load(object sender, EventArgs e)
        {
            //create the 2 lists which hold the Rates.txt information


            if (RatesTableExists())
            {
                //a function to setup the tax rate table for checking against income. Returns false if issues.
                if (!SetupTaxTables(taxRateLevels, taxRateRates)) //https://stackoverflow.com/questions/13993371/how-to-pass-list-as-parameter-in-function
                {
                    //the below is shown when the RATES.TXT file is incorrect - eg taxable levels do not increase in value or unbalanced number of entries.
                    MessageBox.Show("The RATES.TXT file is not valid.\nPlease try re-install this file.\nProgram will end.");
                    Close();
                }
                //This section was where I tested the taxAmount calculator

                //txtDisplayEmployeeData.Text += "Income: $750"+Environment.NewLine;
                //txtDisplayEmployeeData.Text += "Tax: " + TaxAmount(750, taxRateLevels, taxRateRates).ToString("N2")+Environment.NewLine;
                //txtDisplayEmployeeData.Text += "Income: $1700" + Environment.NewLine;
                //txtDisplayEmployeeData.Text += "Tax: " + TaxAmount(1700, taxRateLevels, taxRateRates).ToString("N2") + Environment.NewLine;
                //txtDisplayEmployeeData.Text += "Income: 3000" + Environment.NewLine;
                //txtDisplayEmployeeData.Text += "Tax: " + TaxAmount(3000, taxRateLevels, taxRateRates).ToString("N2") + Environment.NewLine;
                //txtDisplayEmployeeData.Text += "Income: $4500" + Environment.NewLine;
                //txtDisplayEmployeeData.Text += "Tax: " + TaxAmount(4500, taxRateLevels, taxRateRates).ToString("N2") + Environment.NewLine;
            }
            else
            {
                Close();
            }
        }

        private bool RatesTableExists()
        {
            //check to see if the RATES.TXT file exists in the correct directory.
            try
            {
                if (File.Exists("..\\..\\Rates.txt"))
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("The file is not in the same directory as the program.\nCopy RATES.TXT to TaxCalculator directory.\nProgram will close.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("The file not found.\nCopy RATES.TXT to TaxCalculator directory.\nProgram will close.");
            }
            return false;
        }

        private bool SetupTaxTables(List<int> taxRateLevels, List<double> taxRateRates)
        {
            string readTaxFileContents = "";
            readTaxFileContents = File.ReadAllText("..\\..\\Rates.txt");
            //the below splits the read RATES.TXT file into an array for processing - it skips blank entries (created by new line and return special characters).
            string[] split = readTaxFileContents.Split(new char[] { ',', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

            //check to see if there are equal number of values by using modulus operator to see if there is a remainder - if false exit and advise user
            if ((double)split.Length % 2 != 0)
            {
                return false;
            }
            for (int x = 0; x < split.Length / 2; x++) //load the RATES.TXT into the passed Lists with checks
            {
                //test to see the order of RATES.TXT is increasing - otherwise exit program.
                if (x + 1 == split.Length / 2 || Convert.ToInt16(split[x]) < Convert.ToInt16(split[x + 1]))
                {
                    taxRateLevels.Add(Convert.ToInt16(split[x]));
                    taxRateRates.Add(Convert.ToDouble(split[x + (split.Length / 2)]));
                }
                else
                {
                    return false;
                }
            }
            return true;
        }

        private double TaxAmount(int weeklyEarnings, List<int> taxRateLevels, List<double> taxRateRates) //assume calculation on dollars only no cents as per tax dept standard
        {
            //this calculator assumes any values over the highest tax level rate will be taxed at the highest marginal rate e.g. $4000 = 30%
            double taxAmount = 0.00;
            int remaining = weeklyEarnings;

            //calculate each level of the tax table
            for (int i = taxRateLevels.Count - 1; i >= 0; i--)
            {
                if (i > 0)
                {
                    if (remaining > taxRateLevels[i - 1])
                    {
                        taxAmount += taxRateRates[i] * (remaining - taxRateLevels[i - 1]);
                        remaining = taxRateLevels[i - 1];
                    }
                }
                else
                {
                    taxAmount += remaining * taxRateRates[i];
                }
            }
            return Math.Round(taxAmount, 2); //https://stackoverflow.com/questions/31064086/rounding-to-2-decimal-places-c-sharp
        }

        private void btnCreateEmployee_Click(object sender, EventArgs e)
        {
            string inputErrorMessages = null;

            //TaxCalculator form data checks
            inputErrorMessages += employee1.CheckEmployeeID(txtEmployeeID.Text);
            inputErrorMessages += employee1.CheckFirstName(txtFirstName.Text);
            inputErrorMessages += employee1.CheckSurname(txtSurname.Text);
            inputErrorMessages += employee1.CheckGender(txtGender.Text);
            inputErrorMessages += employee1.CheckDepartment(cboDepartment.SelectedIndex);
            inputErrorMessages += employee1.CheckEmail(txtEmail.Text);
            inputErrorMessages += employee1.CheckHourlyRate(txtHourlyRate.Text);

            // Checks to see if there were input errors
            if (string.Equals(inputErrorMessages, ""))
            {
                //Turn access off for the other buttons until the EmployeeTax has been printed - switch them back on once printed
                btnCreateEmployee.Enabled = false;
                btnCalculateEmployeeTax.Enabled = true;

                employee1.EmployeeID = txtEmployeeID.Text;
                employee1.FirstName = txtFirstName.Text;
                employee1.Surname = txtSurname.Text;
                employee1.Gender = txtGender.Text;
                employee1.Department = employee1.DepartmentEnum(cboDepartment.SelectedIndex);
                employee1.Email = txtEmail.Text;
                employee1.HourlyRate = Convert.ToDouble(txtHourlyRate.Text);

                TurnOffDataEntry();

                //display results to ensure this has copied correctly
                DisplayEmployeeDetails(employee1);
                //Ultimately there would be one proceedure this links to for both employee1 and contactor1 objects - I cannot find a solution at present.
            }
            else
            {
                MessageBox.Show(inputErrorMessages + Environment.NewLine + "Please re-enter the information");
            }
        }

        private void btnCreateContactor_Click(object sender, EventArgs e)
        {
            string inputErrorMessages = null;

            //TaxCalculator form data checks
            inputErrorMessages += contractor1.CheckEmployeeID(txtEmployeeID.Text);
            inputErrorMessages += contractor1.CheckFirstName(txtFirstName.Text);
            inputErrorMessages += contractor1.CheckSurname(txtSurname.Text);
            inputErrorMessages += contractor1.CheckGender(txtGender.Text);
            inputErrorMessages += contractor1.CheckDepartment(cboDepartment.SelectedIndex);
            inputErrorMessages += contractor1.CheckEmail(txtEmail.Text);
            inputErrorMessages += contractor1.CheckHourlyRate(txtHourlyRate.Text);
            inputErrorMessages += contractor1.CheckHoursWorked(txtHoursWorked.Text);

            //Check to see if the EmployeeID starts with "E" and is greater than 1000
            if (string.Equals(inputErrorMessages, ""))
            {
                //Turn access off for the other buttons until the EmployeeTax has been printed - switch them back on once printed
                btnCreateContactor.Enabled = false;
                btnCalculateContractorTax.Enabled = true;

                TurnOffDataEntry();

                contractor1.EmployeeID = txtEmployeeID.Text;
                contractor1.FirstName = txtFirstName.Text;
                contractor1.Surname = txtSurname.Text;
                contractor1.Gender = txtGender.Text;
                contractor1.Department = contractor1.DepartmentEnum(cboDepartment.SelectedIndex);
                contractor1.Email = txtEmail.Text;
                contractor1.HourlyRate = Convert.ToDouble(txtHourlyRate.Text);
                contractor1.HoursWorked = Convert.ToDouble(txtHoursWorked.Text);

                //display results to ensure this has copied correctly
                DisplayContractorDetails(contractor1);
                //Ultimately there would be one proceedure this links to for both employee1 and contactor1 objects - I cannot find a solution at present.
            }
            else
            {
                MessageBox.Show(inputErrorMessages + Environment.NewLine + "Please re-enter the information");
            }

        }

        private void DisplayEmployeeDetails(Employee person1)
        {
            txtDisplayEmployeeData.Text += "Employee ID: " + person1.EmployeeID + Environment.NewLine;
            txtDisplayEmployeeData.Text += "First Name: " + person1.FirstName + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Surname: " + person1.Surname + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Gender: " + person1.Gender + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Department: " + person1.Department + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Email: " + person1.Email + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Hourly Rate: " + person1.HourlyRate + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Hours Worked: 40" + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Gross Income: " + person1.HourlyRate * 40 + Environment.NewLine; }

        private void DisplayContractorDetails(Contractor person1)
        {
            txtDisplayEmployeeData.Text += "Employee ID: " + person1.EmployeeID + Environment.NewLine;
            txtDisplayEmployeeData.Text += "First Name: " + person1.FirstName + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Surname: " + person1.Surname + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Gender: " + person1.Gender + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Department: " + person1.Department + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Email: " + person1.Email + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Hourly Rate: " + person1.HourlyRate + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Hours Worked: " + person1.HoursWorked + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Gross Income: " + (person1.HourlyRate * person1.HoursWorked) + Environment.NewLine;
        }

        private void btnCalculateEmployeeTax_Click(object sender, EventArgs e)
        {
            //using the Tax
            employee1.Tax = TaxAmount(Convert.ToInt16(employee1.HourlyRate * 40), taxRateLevels, taxRateRates);

            txtDisplayEmployeeData.Text += "Tax Payable: " + employee1.Tax + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Net Income: " + (employee1.HourlyRate * 40 - employee1.Tax) + Environment.NewLine;

            txtDisplayEmployeeData.Text += Environment.NewLine + "Information will clear once Employee ID is entered.";

            //print the information to a PDF document
            //
            // Place code here - allow user to select location - default naming with user override
            // this should be EmployeeID-Date or Date-EmployeeID to keep in consecutive order by either employee or date of income.
            //
            PrintEmployeeTaxResults(employee1);

            //ensure all the buttons are turned back on
            ResetButtons();

            //clear employee1 ready to accept data
            employee1.ResetEmployeeData();

            //clear the form ready for the next input
            ClearForm();
        }

        private void btnCalculateContractorTax_Click(object sender, EventArgs e)
        {
            //using the Tax
            contractor1.Tax = Convert.ToInt16(contractor1.HourlyRate * contractor1.HoursWorked) * CONTRACTOR_TAX_RATE;

            txtDisplayEmployeeData.Text += "Tax Payable: " + contractor1.Tax + Environment.NewLine;
            txtDisplayEmployeeData.Text += "Net Income: " + ((contractor1.HourlyRate * contractor1.HoursWorked) - contractor1.Tax) + Environment.NewLine;

            txtDisplayEmployeeData.Text += Environment.NewLine + "Information will clear once Employee ID is entered.";

            //print the information to a PDF document
            //
            // Place code here - allow user to select location - default naming with user override
            // this should be EmployeeID-Date or Date-EmployeeID to keep in consecutive order by either employee or date of income.
            //
            PrintContractorTaxResults(contractor1);

            //ensure all the buttons are turned back on
            ResetButtons();

            //clear employee1 ready to accept data
            contractor1.ResetEmployeeData();

            //clear the form ready for the next input
            ClearForm();
        }

        // The PDF printing information was learnt from reading through the below website: -
        // https://www.mikesdotnetting.com/article/87/itextsharp-working-with-images
        // With additional knowledge this could be split into a separate Class and not duplicating the Procedures.
        private void PrintEmployeeTaxResults(Employee person1)
        {
            Document printDoc = new Document();
            
            DateTime today = DateTime.Today;
            string fileDate = "";
            fileDate += "-" + today.ToString("yyyyMMdd");

            saveFileDialog1.Title = "Save " + person1.FirstName + " " + person1.Surname + "'s Data to which location?";
            saveFileDialog1.FileName = person1.EmployeeID + fileDate + ".pdf";
            saveFileDialog1.ShowDialog();
            string filePath = saveFileDialog1.FileName;

            PdfWriter.GetInstance(printDoc, new FileStream(saveFileDialog1.FileName, FileMode.Create));

            printDoc.Open();

            if (File.Exists("..\\..\\AcmeCoyote.jpg"))
            {
                Image jpg = Image.GetInstance("..\\..\\AcmeCoyote.jpg");
                jpg.ScaleToFit(150f, 150f);
                jpg.Alignment = Element.ALIGN_CENTER;
                printDoc.Add(jpg);
            }

            Paragraph companyTitle = new Paragraph("The Acme Insurance Company\n\r");
            companyTitle.Alignment = Image.ALIGN_CENTER;
            printDoc.Add(new Paragraph(companyTitle));

            printDoc.Add(new Paragraph("Employee ID: " + person1.EmployeeID));
            printDoc.Add(new Paragraph("Name: " + person1.Surname +", "+person1.FirstName));
            printDoc.Add(new Paragraph("Department: " + person1.Department));
            printDoc.Add(new Paragraph("Hourly Rate: $" + Math.Round(person1.HourlyRate,2).ToString("N2")));
            printDoc.Add(new Paragraph("Hours Worked: 40")); //hourly information added as a checking mechanism.
            printDoc.Add(new Paragraph("Gross: $" + Math.Round((person1.HourlyRate*40),2).ToString("N2")));
            printDoc.Add(new Paragraph("Tax: $" + Math.Round(person1.Tax, 2).ToString("N2")));
            printDoc.Add(new Paragraph("Net: $" + Math.Round(((person1.HourlyRate * 40) - person1.Tax),2).ToString("N2"))); //additional line to advise net pay also.
            printDoc.Close();
        }

        private void PrintContractorTaxResults(Contractor person1)
        {
            Document printDoc = new Document();

            DateTime today = DateTime.Today;
            string fileDate = "";
            fileDate += "-" + today.ToString("yyyyMMdd");

            saveFileDialog1.Title = "Save " + person1.FirstName + " " + person1.Surname + "'s Data to which location?";
            saveFileDialog1.FileName = person1.EmployeeID + fileDate + ".pdf";
            saveFileDialog1.ShowDialog();
            string filePath = saveFileDialog1.FileName;

            PdfWriter.GetInstance(printDoc, new FileStream(saveFileDialog1.FileName, FileMode.Create));

            printDoc.Open();

            if (File.Exists("..\\..\\AcmeCoyote.jpg")) //this will show the Acme Logo if it is placed into the correct directory.
            {
                Image jpg = Image.GetInstance("..\\..\\AcmeCoyote.jpg");
                jpg.ScaleToFit(150f, 150f);
                jpg.Alignment = Element.ALIGN_CENTER;
                printDoc.Add(jpg);
            }

            Paragraph companyTitle = new Paragraph("The Acme Insurance Company\n\r");
            companyTitle.Alignment = Image.ALIGN_CENTER;
            printDoc.Add(new Paragraph(companyTitle));

            printDoc.Add(new Paragraph("Employee ID: " + person1.EmployeeID));
            printDoc.Add(new Paragraph("Name: " + person1.Surname + ", " + person1.FirstName));
            printDoc.Add(new Paragraph("Department: " + person1.Department));
            printDoc.Add(new Paragraph("Hourly Rate: $" + Math.Round((person1.HourlyRate),2).ToString("N2")));
            printDoc.Add(new Paragraph("Hours Worked: " + person1.HoursWorked)); //hourly information added as a checking mechanism.
            printDoc.Add(new Paragraph("Gross: $" + Math.Round((person1.HourlyRate * person1.HoursWorked),2).ToString("N2")));
            printDoc.Add(new Paragraph("Tax: $" + Math.Round(person1.Tax,2).ToString("N2")));
            printDoc.Add(new Paragraph("Net: $" + Math.Round(((person1.HourlyRate * person1.HoursWorked) - person1.Tax),2).ToString("N2"))); //additional line to advise net pay also.
            printDoc.Close();
        }

        //private void txtEmployeeID_Leave(object sender, EventArgs e)
        //{
        //    if (txtEmployeeID.Text.Length > 0 && txtEmployeeID.Text.Substring(0, 1) == "C")
        //    {
        //        lblHoursWorked.Visible = true;
        //        txtHoursWorked.Visible = true;
        //    }
        //    else
        //    {
        //        lblHoursWorked.Visible = false;
        //        txtHoursWorked.Visible = false;
        //    }
        //}

        // I have used the TextChanged option as this is superior in this case to the Leave option above.
        // Using the TextChanged option this will allow for switching off the buttons while entering the information
        // Leave option works as per above - this can be uncommented and tested - but must also be uncommented in the TaxCalculator.cs [Design] code

        private void txtEmployeeID_TextChanged(object sender, EventArgs e)
        {
            if (txtEmployeeID.Text.Length > 0)
            {
                txtDisplayEmployeeData.Text = ""; //clears the previously displayed data.

                if (txtEmployeeID.Text.Substring(0, 1) == "C")
                {
                    HoursWorkedVisible(true);

                    btnCreateEmployee.Enabled = false;
                    btnCreateContactor.Enabled = true;
                }
                else if (txtEmployeeID.Text.Substring(0, 1) == "E")
                {
                    HoursWorkedVisible(false);

                    btnCreateEmployee.Enabled = true;
                    btnCreateContactor.Enabled = false;
                }
                else
                {
                    HoursWorkedVisible(false);
                    ResetButtons();
                }
            }

        }

        private void HoursWorkedVisible(bool onOff)
        {
            lblHoursWorked.Visible = onOff;
            txtHoursWorked.Visible = onOff;
        }

        private void ClearForm()
        {
            txtEmployeeID.Text = "";
            txtFirstName.Text = "";
            txtSurname.Text = "";
            txtGender.Text = "";
            cboDepartment.Text = "";
            cboDepartment.SelectedIndex = -1;
            txtEmail.Text = "";
            txtHourlyRate.Text = "";
            txtHoursWorked.Text = "";

            txtEmployeeID.Enabled = true;
            txtFirstName.Enabled = true;
            txtSurname.Enabled = true;
            txtGender.Enabled = true;
            cboDepartment.Enabled = true;
            txtEmail.Enabled = true;
            txtHourlyRate.Enabled = true;
            txtHoursWorked.Enabled = true;
        }

        private void TurnOffDataEntry()
        {
            txtEmployeeID.Enabled = false;
            txtFirstName.Enabled = false;
            txtSurname.Enabled = false;
            txtGender.Enabled = false;
            cboDepartment.Enabled = false;
            txtEmail.Enabled = false;
            txtHourlyRate.Enabled = false;
            txtHoursWorked.Enabled = false;
        }

        private void ResetButtons()
        {
            btnCalculateEmployeeTax.Enabled = false;
            btnCreateEmployee.Enabled = true;
            btnCalculateContractorTax.Enabled = false;
            btnCreateContactor.Enabled = true;
        }
    }
}
