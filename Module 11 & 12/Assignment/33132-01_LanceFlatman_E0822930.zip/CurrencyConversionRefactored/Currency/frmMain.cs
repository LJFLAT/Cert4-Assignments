﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CurrencyConversion;

namespace Currency
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            try
            {
                //re-factored the text box to a combo-box with accepted currency codes
                //eliminated possibility of incorrect entry
                ConvertCur currency = new ConvertCur();

                //Check if currency has been selected prior to calculation 
                //and a minimum value of 1 has been entered for conversion - if false on either will not convert
                if(cbCurrencyCode.Text.Length > 0 && txtAmount.TextLength > 0 && int.Parse(txtAmount.Text) > 0)
                {
                    string result = currency.convert(cbCurrencyCode.Text, txtAmount.Text);
                    lblConvertedAmount.Text = "In Australian Dollars: " + result;
                }

            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "ERROR",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
                ClearFields();
            }
            catch (ArithmeticException ex)
            {
                MessageBox.Show(ex.Message, "ERROR",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
                ClearFields();
            }
        }

        private void ClearFields()
        {
            txtAmount.Text = "";
        }
    }
}
