﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CurrencyConversion;

namespace CurrencyTestClass
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Test_CurrencyCodeMixedCase() //requirement 1.1 / 2.2
        {
            //code = "Usd", Amount = 1, expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "Usd";
            string amount = "1";
            string result = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Test_CurrencyCodeLowercase() //requirement 1.2 / 2.2
        {
            //code = "usd", Amount = 1, expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "usd";
            string amount = "1";
            string result = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Test_CurrencyCodeNotListed() //requirement 1.3 / 2.2
        {
            //code = "CHF", Amount = 1, expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "CHF";
            string amount = "1";
            string result = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_AmountNonIntegerCharacterEnteredSpace() //requirement 1.4 / 2.1
        {
            //code = "USD", Amount = " ", expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "USD";
            string amount = " ";
            string result = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_AmountNonIntegerCharacterEnteredVarious() //requirement 1.4 / 2.1
        {
            //code = "USD", Amount = "xyz", expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "USD";
            string amount = "xyz";
            string result = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_AmountNotAWholeNumber() //requirement 1.5 / 2.1
        {
            //code = "USD", Amount = 2.3, expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "USD";
            string amount = "2.3";
            string result = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_AmountExceedsMaximumIntValue() //requirement 1.6 / 2.1
        {
            //code = "USD", Amount = 2147483648, expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "USD";
            string amount = "2147483648";
            string result = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Test_CurrencyCodeAmountBlank() //requirement 1.7
        {
            //code = "", Amount = "", expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "";
            string amount = "";
            string result = currency.convert(code, amount);
        }


        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Test_AmountBlank() //requirement 1.7 /2.1
        {
            //code = "USD", Amount = "", expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "USD";
            string amount = "";
            string result = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException))]
        public void Test_CurrencyCodeBlank() //requirement 1.7 / 2.2
        {
            //code = "", Amount = "1", expected result = Exception
            ConvertCur currency = new ConvertCur();
            string code = "";
            string amount = "1";
            string result = currency.convert(code, amount);
        }

        [TestMethod]
        public void Test_ValidInputs() //requirement 2.1 / 2.2
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "USD", amount = 10, expected result = "12.35"
            code = "USD";
            amount = "10";
            actualResult = currency.convert(code, amount);
            expectedResult = "12.35";
            Assert.AreEqual(actualResult, expectedResult);

            //code = "EUR", amount = 10, expected result = "17.44"
            code = "EUR";
            amount = "10";
            actualResult = currency.convert(code, amount);
            expectedResult = "17.44";
            Assert.AreEqual(actualResult, expectedResult);

            //code = "USD", amount = 10, expected result = "15.09"
            code = "YEN";
            amount = "10";
            actualResult = currency.convert(code, amount);
            expectedResult = "15.09";
            Assert.AreEqual(actualResult, expectedResult);

            //maximum amount - code = "USD", amount = 2147483647, expected result = "2665241954.29"
            code = "USD";
            amount = "2147483647";
            actualResult = currency.convert(code, amount);  // Also requirement 3.3
            expectedResult = "2665241954.29";
            Assert.AreEqual(actualResult, expectedResult);
        }

        [TestMethod]
        public void Test_EuroValidAmounts() //requirement 2.1 / 3.3
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "EUR", amount = 5, expected result = "8.72"
            code = "EUR";
            amount = "5";
            actualResult = currency.convert(code, amount);
            expectedResult = "8.72";
            Assert.AreEqual(actualResult, expectedResult);

            //code = "EUR", amount = 20, expected result = "34.89"
            code = "EUR";
            amount = "20";
            actualResult = currency.convert(code, amount);
            expectedResult = "34.89";
            Assert.AreEqual(actualResult, expectedResult);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_EuroInvalidAmounts4() //requirement 2.1 / 3.3
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "EUR", amount = 4, expected result = Exception
            code = "EUR";
            amount = "4"; //Outside multiple of 5 range
            actualResult = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_EuroInvalidAmounts6() //requirement 2.1 / 3.3
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "EUR", amount = 6, expected result = Exception
            code = "EUR";
            amount = "6"; //Outside multiple of 5 range
            actualResult = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_EuroInvalidAmounts9() //requirement 2.1 / 3.3
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "EUR", amount = 9, expected result = Exception
            code = "EUR";
            amount = "9"; //Outside multiple of 5 range
            actualResult = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_EuroInvalidAmounts11() //requirement 2.1 / 3.3
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "EUR", amount = 11, expected result = Exception
            code = "EUR";
            amount = "11"; //Outside multiple of 5 range
            actualResult = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_EuroInvalidAmounts19() //requirement 2.1 / 3.3
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "EUR", amount = 19, expected result = Exception
            code = "EUR";
            amount = "19"; //Outside multiple of 5 range
            actualResult = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_EuroInvalidAmounts21() //requirement 2.1 / 3.3
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "EUR", amount = 21, expected result = Exception
            code = "EUR";
            amount = "21"; //Outside multiple of 5 range
            actualResult = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_AmountLessThan1() //requirement 1.5 / 2.1 / 3.1
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "USD", amount = 10, expected result = "12.35"
            code = "USD";
            amount = "0.5";
            actualResult = currency.convert(code, amount);
        }

        [TestMethod]
        [ExpectedException(typeof(ArithmeticException))]
        public void Test_AmountLessThan0() //requirement 1.5 / 2.1 / 3.1
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "USD", amount = 10, expected result = "12.35"
            code = "USD";
            amount = "-1";
            actualResult = currency.convert(code, amount);
        }

        [TestMethod]
        public void Test_CalculateCorrectFees() //requirement 2.1 / 2.2 / 4.1 or 4.2
        {
            ConvertCur currency = new ConvertCur();
            string code, amount, actualResult, expectedResult;

            //code = "USD"
            code = "USD";
            //amount = 793, expected result = "979.20"
            amount = "793";
            actualResult = currency.convert(code, amount);
            expectedResult = "979.20";
            Assert.AreEqual(actualResult, expectedResult);

            //amount = 794, expected result = "985.43"
            amount = "794";
            actualResult = currency.convert(code, amount);
            expectedResult = "985.43";
            Assert.AreEqual(actualResult, expectedResult);

            //code = "USD"
            code = "EUR";
            //amount = 560, expected result = "976.86"
            amount = "560";
            actualResult = currency.convert(code, amount);
            expectedResult = "976.86";
            Assert.AreEqual(actualResult, expectedResult);

            //amount = 565, expected result = "990.61"
            amount = "565";
            actualResult = currency.convert(code, amount);
            expectedResult = "990.61";
            Assert.AreEqual(actualResult, expectedResult);

            //code = "USD"
            code = "YEN";
            //amount = 649, expected result = "979.47"
            amount = "649";
            actualResult = currency.convert(code, amount);
            expectedResult = "979.47";
            Assert.AreEqual(actualResult, expectedResult);

            //amount = 650, expected result = "985.98" - by calculator
            //(Calculator generates 985.98 (Being 650 * 1.54 (1001) * 0.98 (2% discount - 20.02))
            //program generates 985.99 - slight rounding error
            amount = "650";
            actualResult = currency.convert(code, amount);
            expectedResult = "985.99";
            Assert.AreEqual(actualResult, expectedResult);
        }
    }
}
