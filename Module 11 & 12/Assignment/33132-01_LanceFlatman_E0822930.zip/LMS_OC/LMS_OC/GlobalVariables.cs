﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LMS_OC
{
    public static class GlobalVariables
    {
        //Book search variables
        private static string bookTitle = "", authorName = "";

        public static string BookTitle
        {
            get { return bookTitle; }
            set { bookTitle = value; }
        }
        public static string AuthorName
        {
            get { return authorName; }
            set { authorName = value; }
        }

        //Student search variables
        private static string studentLastName = "", studentSuburb = "", studentPostCode = "";

        // Search should be student ID - if they have a card etc

        public static string StudentLastName
        {
            get { return studentLastName; }
            set { studentLastName = value; }
        }
        public static string StudentSuburb
        {
            get { return studentSuburb; }
            set { studentSuburb = value; }
        }
        public static string StudentPostCode
        {
            get { return studentPostCode; }
            set { studentPostCode = value; }
        }

        //Librarian search variables
        private static string librarianFirstName = "", librarianLastName = "";

        public static string LibrarianFirstName
        {
            get { return librarianFirstName; }
            set { librarianFirstName = value; }
        }
        public static string LibrarianLastName
        {
            get { return librarianLastName; }
            set { librarianLastName = value; }
        }

        //Methods for checking if search variables have values set
        public static bool BookFilterSet()
        {
            if(BookTitle.Length == 0 && AuthorName.Length == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool StudentFilterSet()
        {
            if (StudentLastName.Length == 0 && StudentPostCode.Length == 0 && StudentSuburb.Length == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool LibrarianFilterSet()
        {
            if (LibrarianFirstName.Length == 0 && LibrarianLastName.Length == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        //Methods to clear the relevant filters
        public static void ClearBookFilter()
        {
            BookTitle = "";
            AuthorName = "";
        }
        public static void ClearStudentFilter()
        {
            StudentLastName = "";
            StudentPostCode = "";
            StudentSuburb = "";
        }
        public static void ClearLibrarianFilter()
        {
            LibrarianFirstName = "";
            LibrarianLastName = "";
        }

        public static bool TestFilterIsValid(string testString)
        {
            //check for reduced potential SQLinjection
            return testString.All(ch => Char.IsLetterOrDigit(ch)); //goes through each character and compares for AlphaNumeric
        }
    }
}
