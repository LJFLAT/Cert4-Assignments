﻿CREATE TABLE [dbo].[BookAdjustments] (
    [bookAdjustmentID]  INT            NOT NULL,
    [bookID]            INT            NOT NULL,
    [quantityAdjustet]  INT            NOT NULL,
    [costPerUnit]       MONEY          NOT NULL,
    [adjustmentComment] NVARCHAR (100) NOT NULL,
    [librarianID]       INT            NOT NULL,
    PRIMARY KEY CLUSTERED ([bookAdjustmentID] ASC)
);

