﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.IO;
using System.Data;
using System.Windows.Forms;

//Class designed by OpenColleges Copyright 2013 (Based upon earliest record in the original database)
namespace LMS_OC.DataAccessLayer
{
    class ConnectionManager
    {
        public static  SqlConnection DBConnection()
        {
           
            SqlConnection connection = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = |DataDirectory|\LMSDB.mdf; Integrated Security = True; Connect Timeout = 30");
            return connection;
        }
        public static DataTable GetTable(string selectQuery)
        {
            try
            {
                DataTable dataTable = new DataTable();
                SqlConnection connection = DBConnection();
                SqlDataAdapter adapter = new SqlDataAdapter(selectQuery, connection);
                connection.Open();
                adapter.Fill(dataTable);
                connection.Close();
                return dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Data table not found - program will terminate.\n" +
                    "System error message: " + ex);
                Application.Exit();
                return null;
            }
        }    
    }
}
