﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS_OC.DataAccessLayer
{
    public class ProcessTableActions
    {
        private SqlConnection connection;
        public SqlCommand command; //needed to make this public as I am unsure how to pass parameters as a method

        public ProcessTableActions()  //creates a new instance of class and opens a connection
        {
            OpenConnection();
        }

        private bool OpenConnection() //Method to open a connection
        {
            try
            {
                connection = ConnectionManager.DBConnection();
                command = new SqlCommand();
                command.Connection = connection;
                connection.Open();
                command.Transaction = connection.BeginTransaction();

                return true;
            }
            catch (Exception ex)
            {
                FailedFileProcess();

                MessageBox.Show("Could not locate the database.\nProgram will terminate.\n" + ex, "Database not found"
                    , System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
                Application.Exit();
                return false;
            }
        }

        //Method to execute one or multiple sql commands - return # records changed each time
        public int ExecuteCommands(string commandText) 
        {
            try
            {
                this.command.CommandText = commandText;
                int recordCount = this.command.ExecuteNonQuery();
                return recordCount;
            }
            catch (Exception ex)
            {
                FailedFileProcess();

                MessageBox.Show("Update of the database failed - record not saved.\nAdvise system administrator.\n" + ex
                    , "Update failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return -1;
            }
        }

        public bool CloseConnection(bool completed) //Method to close the connection
        {
            if (completed)
            {
                try
                {
                    command.Transaction.Commit();
                    connection.Close();
                    return true;
                }
                catch (Exception ex)
                {
                    FailedFileProcess();

                    MessageBox.Show("Update of the database failed - record not saved.\nAdvise system administrator.\n" + ex
                        , "Update failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            else
            {
                FailedFileProcess();
                MessageBox.Show("Database operation failed.\nPlease advise system administrator."
                    , "Operation Failed", MessageBoxButtons.OK);
                return false;
            }
        }

        private void FailedFileProcess() //Rolls back transactions and closes the connection if failed
        {
            this.command.Transaction.Rollback();
            this.command.Dispose();
            this.connection.Dispose();
        }
         
        //Checks if a change in records - returns true if failed (Less than 1 expected change)
        public bool SaveFail(int recordCount)
        {
            if (recordCount < 1) // 0 or -1 returned
            {
                return true;
            }
            return false;
        }
    }
}
