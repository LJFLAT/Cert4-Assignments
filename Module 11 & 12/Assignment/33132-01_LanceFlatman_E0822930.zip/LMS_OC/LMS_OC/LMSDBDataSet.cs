﻿namespace LMS_OC
{


    partial class LMSDBDataSet
    {
    }
}
