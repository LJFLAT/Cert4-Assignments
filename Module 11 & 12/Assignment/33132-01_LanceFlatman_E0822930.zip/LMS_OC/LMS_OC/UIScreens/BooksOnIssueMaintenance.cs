﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmBooksOnIssueForm : Form
    {
        BookIssueReserveReturn bookIssResRet = new BookIssueReserveReturn();
        SearchFilterButtonState bookIssueSearchFilterButtonState;  // holds the state of the search / filter button

        private ListViewItemSorter lvItemSorter; //used to sort columns in listView items

        public frmBooksOnIssueForm()
        {
            InitializeComponent();

            // assign items for sorting listView columns
            lvItemSorter = new ListViewItemSorter();
            this.lvBooksOnIssueList.ListViewItemSorter = lvItemSorter;

            // link the Search / Filter button to the button state class
            bookIssueSearchFilterButtonState = new SearchFilterButtonState(btnSearchFilterBooksOnIssue);
        }

        private void BtnCloseForm_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnSearchFilterBooksOnIssue_Click(object sender, EventArgs e)
        {
            //This section manages the book search filter process and button state
            //State already set
            if (GlobalVariables.BookFilterSet())
            {
                ResetFilterAndDisplayForm();
            }
            else
            {
                //State not set
                frmBookSearchForm searchForm = new frmBookSearchForm();
                searchForm.ShowDialog();

                if (GlobalVariables.BookFilterSet())
                {
                    bookIssueSearchFilterButtonState.SearchFilterState("Press to Clear Book Filter");
                    LoadBookList();
                }
            }
        }

        private void ResetFilterAndDisplayForm()
        {
            //When the program returns it resets the book filter and refreshes the form
            GlobalVariables.ClearBookFilter();
            bookIssueSearchFilterButtonState.ResetFilterState();
            LoadBookList();
        }

        private void FrmBooksOnIssueForm_Load(object sender, EventArgs e)
        {
            //Opens the form and loads all book data
            LoadBookList();
        }

        private void LoadBookList()
        {
            lvBooksOnIssueList.Items.Clear();
            //This returns a dataTable will all books (calculations below determine if these are displayed)
            DataTable bookIssueDT = ConnectionManager.GetTable(bookIssResRet.FilteredBookIssueSQL());
            if (bookIssueDT.Rows.Count == 0)
            {
                //Create a response message based upon the state of the book search/filter
                string responseMessage = "No books on issue records to display.\nPlease ";
                if (GlobalVariables.BookFilterSet())
                {
                    responseMessage += "clear and change the filter.";
                }
                else
                {
                    responseMessage += "add book issue records.";
                }
                MessageBox.Show(responseMessage);
            }
            else
            {
                //moves through the bookIssueDT (DataTable) and adds the records to the listView
                for (int record = 0; record < bookIssueDT.Rows.Count; record++)
                {
                    int numberBooksIssued = int.Parse(bookIssueDT.Rows[record]["noOfBorrowedBooks"].ToString());
                    int numberBooksReserved = int.Parse(bookIssueDT.Rows[record]["noOfReservedBooks"].ToString());

                    //Checks the dataTable and only displays those books on issue or reserved - skips all other records.
                    if (numberBooksReserved > 0 || numberBooksIssued > 0)
                    {

                        ListViewItem listViewItem = new ListViewItem(bookIssueDT.Rows[record]["bookID"].ToString());  //Hidden Column
                        listViewItem.SubItems.Add(bookIssueDT.Rows[record]["title"].ToString());
                        listViewItem.SubItems.Add(bookIssueDT.Rows[record]["authorName"].ToString());
                        listViewItem.SubItems.Add(bookIssueDT.Rows[record]["ISBN"].ToString());

                        //if BookIssued returnDate has been passed from the table
                        string tempEarliestReturn = bookIssueDT.Rows[record]["earliestReturn"].ToString();
                        if (tempEarliestReturn.Length>0) //checks if issued return date is blank
                        {
                            listViewItem.SubItems.Add(tempEarliestReturn.Substring(0, 10));
                            if (DateTime.Parse(tempEarliestReturn) < DateTime.Today)
                            {
                                listViewItem.ForeColor = Color.Red;
                            }
                            else
                            {
                                listViewItem.ForeColor = Color.Black;
                            }
                        }
                        else
                        {
                            tempEarliestReturn = "";
                            listViewItem.SubItems.Add(tempEarliestReturn);
                        }
                        listViewItem.SubItems.Add(bookIssueDT.Rows[record]["noOfAvailableBooks"].ToString());
                        listViewItem.SubItems.Add(numberBooksIssued.ToString());
                        listViewItem.SubItems.Add(numberBooksReserved.ToString());
                        lvBooksOnIssueList.Items.Add(listViewItem);
                    }
                }
            }
        }

        private void BtnIssueReserveBooks_Click(object sender, EventArgs e)
        {
            frmBooksToIssueReserveForm subForm = new frmBooksToIssueReserveForm();
            subForm.ShowDialog();
            GlobalVariables.ClearBookFilter();
            LoadBookList();
        }

        private void BtnBookReturnCancelReserve_Click(object sender, EventArgs e)
        {
            //That form should allow removal of reserved students
            if (lvBooksOnIssueList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Book Issue Record to Enter a Return / Cancel a Reservation."
                    , "Book not selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
            // This opens the book details form setting it to modify existing book record to update the table
            frmBookIssueDetail subForm = new frmBookIssueDetail(int.Parse(lvBooksOnIssueList.SelectedItems[0].Text));
            subForm.ShowDialog();
            LoadBookList();
            }
        }

        private void LvBooksOnIssueList_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // This section of code handles the sorting of listView columns
            // General code structure was taken from links highlighted in ListViewItemSorter.cs and modified to suit
            int testClickColumn = e.Column;

            switch (testClickColumn)
            {
                case 5: //no sort on column 5, 6 or 7
                case 6:
                case 7:
                    return;
                default:
                    //checks performed within ListViewItemSorter class
                    lvItemSorter.checkPreviousOrder(testClickColumn);

                    // Perform the sort with these new sort options.
                    this.lvBooksOnIssueList.Sort();
                    return;
            }
        }
    }
}
