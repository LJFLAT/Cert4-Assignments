﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmBookIssueDetail : Form
    {
        BookIssueReserveReturn issueReserveReturn = new BookIssueReserveReturn();

        int bookID = 0;
        public frmBookIssueDetail(int bookToDisplay)
        {
            InitializeComponent();
            bookID = bookToDisplay;
        }

        private void BtnCancelReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmBookIssueDetail_Load(object sender, EventArgs e)
        {
            LoadIssuesAndReserves();
        }

        private void LoadIssuesAndReserves()
        { 
            lvBookIssueDetails.Items.Clear();
            string bookTitleQuery = "SELECT title FROM Book WHERE bookID = " + bookID + "";

            DataTable bookTitleDT = ConnectionManager.GetTable(bookTitleQuery);
            txtBookTitle.Text = bookTitleDT.Rows[0]["title"].ToString();
            bookTitleDT.Dispose();

            //Process the DataTable based upon this result (I suspect if this is blank - then it displays otherwise dont)
            string issueQuery = "SELECT BookIssue.issueID, BookIssue.studentID" +
                ", Student.firstName + ' ' + Student.lastName as stName, Student.contactNo, BookIssue.returnDate, " +
                "BookReturn.returnID FROM BookIssue LEFT JOIN Student ON BookIssue.studentID = Student.studentID " +
                "LEFT JOIN BookReturn ON BookIssue.issueID = BookReturn.issueID " +
                "WHERE BookIssue.bookID =" + bookID + " ORDER BY returnDate ASC";

            string reserveQuery = "SELECT BookReserve.studentID, Student.firstName + ' ' + Student.lastName as stName, reserveDate, " +
                "Student.contactNo FROM BookReserve LEFT JOIN Student ON BookReserve.studentID = Student.studentID " +
                "WHERE BookReserve.bookID = " + bookID + " ORDER BY reserveDate ASC";

            //Load ListView showing Grouped Issued Books and Grouped Reserved Books
            DataTable bookIssuedDT = ConnectionManager.GetTable(issueQuery);
            DataTable bookReserveDT = ConnectionManager.GetTable(reserveQuery);

            ListViewGroup issuedBooks = new ListViewGroup("Issued Books");
            ListViewGroup reservedBooks = new ListViewGroup("Reserved Books");
            lvBookIssueDetails.Groups.Add(issuedBooks);
            lvBookIssueDetails.Groups.Add(reservedBooks);

            for (int record = 0; record < bookIssuedDT.Rows.Count; record++)
            {
                //Where there is no returnID info, display the book issue
                if (bookIssuedDT.Rows[record]["returnID"].ToString().Equals(""))
                {
                    lvBookIssueDetails.ForeColor = Color.Black;
                    string tempReturnDate = bookIssuedDT.Rows[record]["returnDate"].ToString();
                    ListViewItem listViewItem = new ListViewItem(bookIssuedDT.Rows[record]["issueID"].ToString()
                        , issuedBooks);
                    listViewItem.SubItems.Add(bookIssuedDT.Rows[record]["studentID"].ToString());
                    listViewItem.SubItems.Add(bookIssuedDT.Rows[record]["stName"].ToString());
                    listViewItem.SubItems.Add(bookIssuedDT.Rows[record]["contactNo"].ToString());
                    listViewItem.SubItems.Add(tempReturnDate.Substring(0, 10));
                    if (DateTime.Parse(tempReturnDate) < DateTime.Today)
                    {
                        lvBookIssueDetails.ForeColor = Color.Red;
                    }
                    lvBookIssueDetails.Items.Add(listViewItem);
                }
            }

            for (int record = 0; record < bookReserveDT.Rows.Count; record++)
            {
                string tempReserveDate = bookReserveDT.Rows[record]["reserveDate"].ToString();
                ListViewItem listViewItem = new ListViewItem("", reservedBooks); //leaves the hidden column blank
                listViewItem.SubItems.Add(bookReserveDT.Rows[record]["studentID"].ToString());
                listViewItem.SubItems.Add(bookReserveDT.Rows[record]["stName"].ToString());
                listViewItem.SubItems.Add(bookReserveDT.Rows[record]["contactNo"].ToString());
                listViewItem.SubItems.Add("");
                listViewItem.SubItems.Add(tempReserveDate.Substring(0, 10));
                lvBookIssueDetails.Items.Add(listViewItem);
            }
        }

        //Function to create a return for a book or delete a reservation
        private void BtnCancelReservation_Click(object sender, EventArgs e)
        {
            //checks if item has been selected from the Reserved Books group listView
            if(lvBookIssueDetails.SelectedItems.Count == 0 
                || !(lvBookIssueDetails.SelectedItems[0].Group.Header.Equals("Reserved Books")))
            {
                MessageBox.Show("Please select an item from the Reserved Book List","Select Reserved Book",
                    MessageBoxButtons.OK);
                lvBookIssueDetails.Focus();
            }
            else
            {
                issueReserveReturn.StudentID = int.Parse(lvBookIssueDetails.SelectedItems[0].SubItems[1].Text);
                string reservedBookStudentName = lvBookIssueDetails.SelectedItems[0].SubItems[2].Text;

                DialogResult result = MessageBox.Show("Do you wish to remove the book reservation for\n "
                    + "Student ID: " + issueReserveReturn.StudentID + "\nStudent Name: " + reservedBookStudentName
                    , "Delete Reservation", MessageBoxButtons.YesNo , MessageBoxIcon.Warning
                    , MessageBoxDefaultButton.Button2);
                
                if(result == DialogResult.No)
                {
                    lvBookIssueDetails.Focus();
                    return;
                }
                issueReserveReturn.BookID = bookID;
                
                //Test if delete has been processed
                int recordCount = issueReserveReturn.BookReserveDelete(true); //Update occurs as an individual transaction
                if (recordCount == 0) //if no records deleted - should not occur as selected from the listView items.
                {
                    MessageBox.Show("Update Operation failed. Please select 1 entry and try again.");
                }
                else if(recordCount > 0) //# records successfully deleted.
                { 
                    MessageBox.Show("Reserved book successfully deleted", "Reserved Book Deleted"
                        , MessageBoxButtons.OK);
                    LoadIssuesAndReserves();
                } //Will skip both if there was a failure in the update. Message already provided to user
            }
        }

        private void BtnReturnIssuedBook_Click(object sender, EventArgs e)
        {
            //checks if item has been selected from the Issued Books group listView
            if (lvBookIssueDetails.SelectedItems.Count == 0
                || !(lvBookIssueDetails.SelectedItems[0].Group.Header.Equals("Issued Books")))
            {
                MessageBox.Show("Please select an item from the Issued Book List", "Select Reserved Book",
                    MessageBoxButtons.OK);
                lvBookIssueDetails.Focus();
            }
            else
            {
                issueReserveReturn.BookID = bookID;
                issueReserveReturn.IssueID = int.Parse(lvBookIssueDetails.SelectedItems[0].Text);
                issueReserveReturn.StudentID = int.Parse(lvBookIssueDetails.SelectedItems[0].SubItems[1].Text);
                issueReserveReturn.ReturnDate = DateTime.Parse(lvBookIssueDetails.SelectedItems[0].SubItems[4].Text);

                string reservedBookStudentName = lvBookIssueDetails.SelectedItems[0].SubItems[2].Text;

                //Opens a new form and asks user for Date and calculates fine information
                frmBookIssueReturn returnDetailsForm = new frmBookIssueReturn(issueReserveReturn, reservedBookStudentName);
                DialogResult completed = returnDetailsForm.ShowDialog();

                //If the returnDate is default, the return was not processed therefore advise user and return to this form
                if (completed == DialogResult.No)
                {
                    MessageBox.Show("The Book Return was not completed. Please try again.","Book Return Not Completed"
                        ,MessageBoxButtons.OK);
                    return;
                }
                issueReserveReturn.LibrarianID = int.Parse(System.Environment.GetEnvironmentVariable("librarianID"));

                int recordCount = issueReserveReturn.BookReturnAdd();
                if (recordCount == 0) //if no records deleted - should not occur as selected from the listView items.
                {
                    MessageBox.Show("Update Operation failed. Please select 1 record and try again.");
                }
                else if (recordCount > 0) //# records successfully deleted.
                {
                    string reservedBookAdvice = "";
                    if(lvBookIssueDetails.Groups[1].Items.Count > 0)
                    {
                        reservedBookAdvice = "\n\nReserved books can be filled.";
                    }
                    MessageBox.Show("Issued book successfully returned book" + reservedBookAdvice
                        , "Issued Book Returned", MessageBoxButtons.OK);
                    LoadIssuesAndReserves();
                } //Will skip both if there was a failure in the update. Message already provided to user.
            }
        }
    }
}
