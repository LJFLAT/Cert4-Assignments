﻿namespace LMS_OC.UIScreens
{
    partial class frmBookQuantityAdjustments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBookID = new System.Windows.Forms.Label();
            this.txtBookID = new System.Windows.Forms.TextBox();
            this.lblQuantityAdjusted = new System.Windows.Forms.Label();
            this.txtQuantityAdjusted = new System.Windows.Forms.TextBox();
            this.lblCostPerBookAdjustment = new System.Windows.Forms.Label();
            this.txtCostPerBookAdjustment = new System.Windows.Forms.TextBox();
            this.lblAdditionalComment = new System.Windows.Forms.Label();
            this.txtAdditionalComment = new System.Windows.Forms.TextBox();
            this.lblAdjustmentCategory = new System.Windows.Forms.Label();
            this.cbCategory = new System.Windows.Forms.ComboBox();
            this.gbOfficeUse = new System.Windows.Forms.GroupBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbAdjustmentAmount = new System.Windows.Forms.GroupBox();
            this.lblNewRemainingBookAverage = new System.Windows.Forms.Label();
            this.lblQuantityRange = new System.Windows.Forms.Label();
            this.gbAdjustmentDetails = new System.Windows.Forms.GroupBox();
            this.dtpAdjustmentDate = new System.Windows.Forms.DateTimePicker();
            this.lblAdjustmentDate = new System.Windows.Forms.Label();
            this.lblSavedComment = new System.Windows.Forms.Label();
            this.txtSavedComment = new System.Windows.Forms.TextBox();
            this.btnAddAdjustmentDetails = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblPriorAdjustments = new System.Windows.Forms.Label();
            this.lvPriorAdjustments = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbOfficeUse.SuspendLayout();
            this.gbAdjustmentAmount.SuspendLayout();
            this.gbAdjustmentDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBookID
            // 
            this.lblBookID.AutoSize = true;
            this.lblBookID.Location = new System.Drawing.Point(6, 22);
            this.lblBookID.Name = "lblBookID";
            this.lblBookID.Size = new System.Drawing.Size(52, 13);
            this.lblBookID.TabIndex = 0;
            this.lblBookID.Text = "Book ID :";
            // 
            // txtBookID
            // 
            this.txtBookID.Enabled = false;
            this.txtBookID.Location = new System.Drawing.Point(64, 19);
            this.txtBookID.Name = "txtBookID";
            this.txtBookID.ReadOnly = true;
            this.txtBookID.Size = new System.Drawing.Size(89, 20);
            this.txtBookID.TabIndex = 1;
            // 
            // lblQuantityAdjusted
            // 
            this.lblQuantityAdjusted.AutoSize = true;
            this.lblQuantityAdjusted.Location = new System.Drawing.Point(9, 22);
            this.lblQuantityAdjusted.Name = "lblQuantityAdjusted";
            this.lblQuantityAdjusted.Size = new System.Drawing.Size(90, 13);
            this.lblQuantityAdjusted.TabIndex = 0;
            this.lblQuantityAdjusted.Text = "Quantity Adjusted";
            // 
            // txtQuantityAdjusted
            // 
            this.txtQuantityAdjusted.Location = new System.Drawing.Point(156, 19);
            this.txtQuantityAdjusted.Name = "txtQuantityAdjusted";
            this.txtQuantityAdjusted.Size = new System.Drawing.Size(81, 20);
            this.txtQuantityAdjusted.TabIndex = 0;
            this.txtQuantityAdjusted.TextChanged += new System.EventHandler(this.TxtQuantityAdjusted_TextChanged);
            this.txtQuantityAdjusted.Leave += new System.EventHandler(this.TxtQuantityAdjusted_Leave);
            // 
            // lblCostPerBookAdjustment
            // 
            this.lblCostPerBookAdjustment.AutoSize = true;
            this.lblCostPerBookAdjustment.Location = new System.Drawing.Point(9, 48);
            this.lblCostPerBookAdjustment.Name = "lblCostPerBookAdjustment";
            this.lblCostPerBookAdjustment.Size = new System.Drawing.Size(145, 13);
            this.lblCostPerBookAdjustment.TabIndex = 0;
            this.lblCostPerBookAdjustment.Text = "Price / book Adjustement :  $";
            // 
            // txtCostPerBookAdjustment
            // 
            this.txtCostPerBookAdjustment.Location = new System.Drawing.Point(156, 45);
            this.txtCostPerBookAdjustment.Name = "txtCostPerBookAdjustment";
            this.txtCostPerBookAdjustment.Size = new System.Drawing.Size(81, 20);
            this.txtCostPerBookAdjustment.TabIndex = 1;
            this.txtCostPerBookAdjustment.TextChanged += new System.EventHandler(this.TxtCostPerBookAdjustment_TextChanged);
            this.txtCostPerBookAdjustment.Leave += new System.EventHandler(this.TxtCostPerBookAdjustment_Leave);
            // 
            // lblAdditionalComment
            // 
            this.lblAdditionalComment.AutoSize = true;
            this.lblAdditionalComment.Location = new System.Drawing.Point(6, 77);
            this.lblAdditionalComment.Name = "lblAdditionalComment";
            this.lblAdditionalComment.Size = new System.Drawing.Size(106, 13);
            this.lblAdditionalComment.TabIndex = 0;
            this.lblAdditionalComment.Text = "Additional Comment :";
            // 
            // txtAdditionalComment
            // 
            this.txtAdditionalComment.Location = new System.Drawing.Point(122, 74);
            this.txtAdditionalComment.Name = "txtAdditionalComment";
            this.txtAdditionalComment.Size = new System.Drawing.Size(301, 20);
            this.txtAdditionalComment.TabIndex = 2;
            this.txtAdditionalComment.TextChanged += new System.EventHandler(this.TxtAdditionalComment_TextChanged);
            this.txtAdditionalComment.Leave += new System.EventHandler(this.TxtAdditionalComment_Leave);
            // 
            // lblAdjustmentCategory
            // 
            this.lblAdjustmentCategory.AutoSize = true;
            this.lblAdjustmentCategory.Location = new System.Drawing.Point(6, 50);
            this.lblAdjustmentCategory.Name = "lblAdjustmentCategory";
            this.lblAdjustmentCategory.Size = new System.Drawing.Size(110, 13);
            this.lblAdjustmentCategory.TabIndex = 0;
            this.lblAdjustmentCategory.Text = "Adjustment Category :";
            // 
            // cbCategory
            // 
            this.cbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCategory.FormattingEnabled = true;
            this.cbCategory.Items.AddRange(new object[] {
            "Purchases (+)",
            "Damage (-)",
            "Stock Adjustment (+/-)",
            "Price Adjustment (Quantity na)",
            "Student Loss (-)",
            "Donations (+)",
            "Other (+/-)"});
            this.cbCategory.Location = new System.Drawing.Point(122, 47);
            this.cbCategory.Name = "cbCategory";
            this.cbCategory.Size = new System.Drawing.Size(199, 21);
            this.cbCategory.TabIndex = 1;
            this.cbCategory.TextChanged += new System.EventHandler(this.CbCategory_TextChanged);
            this.cbCategory.Leave += new System.EventHandler(this.CbCategory_Leave);
            // 
            // gbOfficeUse
            // 
            this.gbOfficeUse.Controls.Add(this.txtTitle);
            this.gbOfficeUse.Controls.Add(this.label1);
            this.gbOfficeUse.Controls.Add(this.txtBookID);
            this.gbOfficeUse.Controls.Add(this.lblBookID);
            this.gbOfficeUse.Location = new System.Drawing.Point(12, 12);
            this.gbOfficeUse.Name = "gbOfficeUse";
            this.gbOfficeUse.Size = new System.Drawing.Size(433, 79);
            this.gbOfficeUse.TabIndex = 5;
            this.gbOfficeUse.TabStop = false;
            this.gbOfficeUse.Text = "Office Use";
            // 
            // txtTitle
            // 
            this.txtTitle.Enabled = false;
            this.txtTitle.Location = new System.Drawing.Point(64, 45);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.ReadOnly = true;
            this.txtTitle.Size = new System.Drawing.Size(358, 20);
            this.txtTitle.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Title :";
            // 
            // gbAdjustmentAmount
            // 
            this.gbAdjustmentAmount.Controls.Add(this.lblNewRemainingBookAverage);
            this.gbAdjustmentAmount.Controls.Add(this.lblQuantityRange);
            this.gbAdjustmentAmount.Controls.Add(this.txtQuantityAdjusted);
            this.gbAdjustmentAmount.Controls.Add(this.lblQuantityAdjusted);
            this.gbAdjustmentAmount.Controls.Add(this.lblCostPerBookAdjustment);
            this.gbAdjustmentAmount.Controls.Add(this.txtCostPerBookAdjustment);
            this.gbAdjustmentAmount.Location = new System.Drawing.Point(12, 239);
            this.gbAdjustmentAmount.Name = "gbAdjustmentAmount";
            this.gbAdjustmentAmount.Size = new System.Drawing.Size(433, 78);
            this.gbAdjustmentAmount.TabIndex = 1;
            this.gbAdjustmentAmount.TabStop = false;
            this.gbAdjustmentAmount.Text = "Adjustment Amount";
            // 
            // lblNewRemainingBookAverage
            // 
            this.lblNewRemainingBookAverage.AutoSize = true;
            this.lblNewRemainingBookAverage.Location = new System.Drawing.Point(251, 48);
            this.lblNewRemainingBookAverage.Name = "lblNewRemainingBookAverage";
            this.lblNewRemainingBookAverage.Size = new System.Drawing.Size(0, 13);
            this.lblNewRemainingBookAverage.TabIndex = 2;
            // 
            // lblQuantityRange
            // 
            this.lblQuantityRange.AutoSize = true;
            this.lblQuantityRange.Location = new System.Drawing.Point(251, 22);
            this.lblQuantityRange.Name = "lblQuantityRange";
            this.lblQuantityRange.Size = new System.Drawing.Size(0, 13);
            this.lblQuantityRange.TabIndex = 2;
            // 
            // gbAdjustmentDetails
            // 
            this.gbAdjustmentDetails.Controls.Add(this.dtpAdjustmentDate);
            this.gbAdjustmentDetails.Controls.Add(this.lblAdjustmentDate);
            this.gbAdjustmentDetails.Controls.Add(this.lblAdjustmentCategory);
            this.gbAdjustmentDetails.Controls.Add(this.lblSavedComment);
            this.gbAdjustmentDetails.Controls.Add(this.lblAdditionalComment);
            this.gbAdjustmentDetails.Controls.Add(this.txtSavedComment);
            this.gbAdjustmentDetails.Controls.Add(this.txtAdditionalComment);
            this.gbAdjustmentDetails.Controls.Add(this.cbCategory);
            this.gbAdjustmentDetails.Location = new System.Drawing.Point(12, 97);
            this.gbAdjustmentDetails.Name = "gbAdjustmentDetails";
            this.gbAdjustmentDetails.Size = new System.Drawing.Size(433, 136);
            this.gbAdjustmentDetails.TabIndex = 0;
            this.gbAdjustmentDetails.TabStop = false;
            this.gbAdjustmentDetails.Text = "Adjustment Details";
            // 
            // dtpAdjustmentDate
            // 
            this.dtpAdjustmentDate.CustomFormat = "dd/MM/yyyy";
            this.dtpAdjustmentDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAdjustmentDate.Location = new System.Drawing.Point(122, 21);
            this.dtpAdjustmentDate.Name = "dtpAdjustmentDate";
            this.dtpAdjustmentDate.Size = new System.Drawing.Size(115, 20);
            this.dtpAdjustmentDate.TabIndex = 0;
            this.dtpAdjustmentDate.Value = new System.DateTime(2019, 1, 1, 0, 0, 0, 0);
            this.dtpAdjustmentDate.Leave += new System.EventHandler(this.DtpAdjustmentDate_Leave);
            // 
            // lblAdjustmentDate
            // 
            this.lblAdjustmentDate.AutoSize = true;
            this.lblAdjustmentDate.Location = new System.Drawing.Point(6, 23);
            this.lblAdjustmentDate.Name = "lblAdjustmentDate";
            this.lblAdjustmentDate.Size = new System.Drawing.Size(91, 13);
            this.lblAdjustmentDate.TabIndex = 0;
            this.lblAdjustmentDate.Text = "Adjustment Date :";
            // 
            // lblSavedComment
            // 
            this.lblSavedComment.AutoSize = true;
            this.lblSavedComment.Location = new System.Drawing.Point(6, 105);
            this.lblSavedComment.Name = "lblSavedComment";
            this.lblSavedComment.Size = new System.Drawing.Size(91, 13);
            this.lblSavedComment.TabIndex = 0;
            this.lblSavedComment.Text = "Saved Comment :";
            // 
            // txtSavedComment
            // 
            this.txtSavedComment.Enabled = false;
            this.txtSavedComment.Location = new System.Drawing.Point(122, 102);
            this.txtSavedComment.Name = "txtSavedComment";
            this.txtSavedComment.ReadOnly = true;
            this.txtSavedComment.Size = new System.Drawing.Size(301, 20);
            this.txtSavedComment.TabIndex = 3;
            // 
            // btnAddAdjustmentDetails
            // 
            this.btnAddAdjustmentDetails.Location = new System.Drawing.Point(12, 323);
            this.btnAddAdjustmentDetails.Name = "btnAddAdjustmentDetails";
            this.btnAddAdjustmentDetails.Size = new System.Drawing.Size(90, 38);
            this.btnAddAdjustmentDetails.TabIndex = 2;
            this.btnAddAdjustmentDetails.Text = "Add Adjustment Details";
            this.btnAddAdjustmentDetails.UseVisualStyleBackColor = true;
            this.btnAddAdjustmentDetails.Click += new System.EventHandler(this.BtnAddAdjustmentDetails_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(355, 323);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 38);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // lblPriorAdjustments
            // 
            this.lblPriorAdjustments.AutoSize = true;
            this.lblPriorAdjustments.Location = new System.Drawing.Point(463, 9);
            this.lblPriorAdjustments.Name = "lblPriorAdjustments";
            this.lblPriorAdjustments.Size = new System.Drawing.Size(88, 13);
            this.lblPriorAdjustments.TabIndex = 4;
            this.lblPriorAdjustments.Text = "Prior Adjustments";
            // 
            // lvPriorAdjustments
            // 
            this.lvPriorAdjustments.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lvPriorAdjustments.FullRowSelect = true;
            this.lvPriorAdjustments.GridLines = true;
            this.lvPriorAdjustments.HideSelection = false;
            this.lvPriorAdjustments.Location = new System.Drawing.Point(466, 26);
            this.lvPriorAdjustments.MultiSelect = false;
            this.lvPriorAdjustments.Name = "lvPriorAdjustments";
            this.lvPriorAdjustments.Size = new System.Drawing.Size(604, 335);
            this.lvPriorAdjustments.TabIndex = 4;
            this.lvPriorAdjustments.UseCompatibleStateImageBehavior = false;
            this.lvPriorAdjustments.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Date";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Qty Adjusted";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader2.Width = 75;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Adjustment $";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader3.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Comment";
            this.columnHeader4.Width = 225;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Librarian";
            this.columnHeader5.Width = 120;
            // 
            // frmBookQuantityAdjustments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 373);
            this.ControlBox = false;
            this.Controls.Add(this.lvPriorAdjustments);
            this.Controls.Add(this.lblPriorAdjustments);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAddAdjustmentDetails);
            this.Controls.Add(this.gbAdjustmentDetails);
            this.Controls.Add(this.gbAdjustmentAmount);
            this.Controls.Add(this.gbOfficeUse);
            this.Name = "frmBookQuantityAdjustments";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Book Quantity Adjustments";
            this.Load += new System.EventHandler(this.FrmBookQuantityAdjustments_Load);
            this.gbOfficeUse.ResumeLayout(false);
            this.gbOfficeUse.PerformLayout();
            this.gbAdjustmentAmount.ResumeLayout(false);
            this.gbAdjustmentAmount.PerformLayout();
            this.gbAdjustmentDetails.ResumeLayout(false);
            this.gbAdjustmentDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBookID;
        private System.Windows.Forms.TextBox txtBookID;
        private System.Windows.Forms.Label lblQuantityAdjusted;
        private System.Windows.Forms.TextBox txtQuantityAdjusted;
        private System.Windows.Forms.Label lblCostPerBookAdjustment;
        private System.Windows.Forms.TextBox txtCostPerBookAdjustment;
        private System.Windows.Forms.Label lblAdditionalComment;
        private System.Windows.Forms.TextBox txtAdditionalComment;
        private System.Windows.Forms.Label lblAdjustmentCategory;
        private System.Windows.Forms.ComboBox cbCategory;
        private System.Windows.Forms.GroupBox gbOfficeUse;
        private System.Windows.Forms.GroupBox gbAdjustmentAmount;
        private System.Windows.Forms.GroupBox gbAdjustmentDetails;
        private System.Windows.Forms.Label lblSavedComment;
        private System.Windows.Forms.TextBox txtSavedComment;
        private System.Windows.Forms.Button btnAddAdjustmentDetails;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpAdjustmentDate;
        private System.Windows.Forms.Label lblAdjustmentDate;
        private System.Windows.Forms.Label lblNewRemainingBookAverage;
        private System.Windows.Forms.Label lblQuantityRange;
        private System.Windows.Forms.Label lblPriorAdjustments;
        private System.Windows.Forms.ListView lvPriorAdjustments;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
    }
}