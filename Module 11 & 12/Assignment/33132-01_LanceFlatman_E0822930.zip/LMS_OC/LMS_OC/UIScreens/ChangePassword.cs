﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmChangePassword : Form
    {
        private string originalPassword = "";
        public string returnValue = ""; //used for passing information back to the calling form

        public frmChangePassword(string password)
        {
            //opens the form and stores the original password for checking purposes later
            InitializeComponent();
            originalPassword = password;
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            //returns a result of the form outcome - password hasn't changed
            this.returnValue = originalPassword;
            this.DialogResult = DialogResult.No;
            this.Close();
        }

        private void FrmChangePassword_Load(object sender, EventArgs e)
        {
            //loads the forms and displays items that are accessible at this stage
            btnConfirmChange.Enabled = false;
            txtNewPassword.Enabled = false;
            txtConfirmPassword.Enabled = false;
        }

        private void TxtConfirmPassword_Leave(object sender, EventArgs e)
        {
            //new and confirm matches
            if (txtNewPassword.Text == txtConfirmPassword.Text)
            {
                btnConfirmChange.Enabled = true;
                btnConfirmChange.Focus();
                return;
            }
            else if (txtNewPassword.Text == txtOldPassword.Text)
            {
                //new is the same as the old password
                MessageBox.Show("New password is the same as the old password. Please enter a new password", "",
                    MessageBoxButtons.OK);
            }
            else
            {
                //New and confirm doesn't match
                MessageBox.Show("New and confirm password don't match.", "Password mis-match", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            //Reset text boxes
            txtNewPassword.Text = "";
            txtOldPassword.Text = "";
            txtConfirmPassword.Text = "";
            txtNewPassword.Enabled = false;
            txtConfirmPassword.Enabled = false;
            txtOldPassword.Focus();            
        }

        private void TxtOldPassword_Leave(object sender, EventArgs e)
        {
            //if the user starts the process and doesnt wish to continue this allows cancel button to override
            if (txtOldPassword.TextLength > 0) 
            {
                if (txtOldPassword.Text == originalPassword)
                {
                    //old password matches the original - allow access to other items on the form
                    txtNewPassword.Enabled = true;
                    txtConfirmPassword.Enabled = true;
                    txtNewPassword.Focus();
                }
                else
                {
                    //When the entered old password doesn't match the original
                    MessageBox.Show("Old password doesn't match.", "Password mis-match", MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    txtOldPassword.Text = "";
                    txtOldPassword.Focus();
                }
            }
        }

        private void BtnConfirmChange_Click(object sender, EventArgs e)
        {
            //Checks if the old password valid & the new / confirm match
            if(txtOldPassword.Text == originalPassword && txtNewPassword.Text == txtConfirmPassword.Text)
            {
                DialogResult result = MessageBox.Show("Do you wish to continue?","Password change",
                    MessageBoxButtons.YesNo,MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if(result == DialogResult.Yes)
                {
                    //passes the changed password back to the calling form
                    this.returnValue = txtNewPassword.Text;
                    this.DialogResult = DialogResult.Yes;
                    this.Close();
                }
            }
        }
    }
}
