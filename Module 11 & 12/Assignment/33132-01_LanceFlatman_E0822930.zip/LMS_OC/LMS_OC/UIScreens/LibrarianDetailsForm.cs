﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmLibrarianDetailsForm : Form
    {
        Librarian librarian = new Librarian();

        //method to store a librarianID into the instance of librarian. 0 means add librarian
        public void SetLibrarianID(int selectedRecord)
        {
            librarian.LibrarianID = selectedRecord;
        }

        public frmLibrarianDetailsForm()
        {
            InitializeComponent();
        }

        private void BtnCancelReturn_Click(object sender, EventArgs e)
        {
            if (DetailsChanged())
            {
                DialogResult dialogResult = MessageBox.Show("Exiting will not update the information. Do you wish to continue?"
                    , "Information has changed", MessageBoxButtons.YesNo);
                if(dialogResult == DialogResult.Yes)
                {
                    CloseForm();
                }
            }
            else
            {
                CloseForm();
            }
        }

        private bool DetailsChanged()
        {
            bool changed = true;
            if(txtLibrarianID.Text == librarian.LibrarianID.ToString() && txtFirstName.Text == librarian.FirstName && 
                txtLastName.Text == librarian.LastName && txtAddress.Text == librarian.Address && 
                txtSuburb.Text == librarian.Suburb && cbState.Text == librarian.State && 
                txtPostCode.Text == librarian.PostCode.ToString() && txtEmail.Text == librarian.Email &&
                txtContactNo.Text == librarian.ContactNo && txtUserName.Text == librarian.UserName &&
                txtPassword.Text == librarian.Password)
            {
                changed = false;
            }
            return changed;
        }

        //The form displays personal information as Password chars
        //If the user wishes to edit the information - the individual user must log in again at the Edit screen
        //This will show the fields which were hidden (excluding password).
        //Once the form has changed - confirm the change with the user
        private void FrmLibrarianDetailsForm_Load(object sender, EventArgs e)
        {
            //Call password check

            if (librarian.LibrarianID == 0)
            {
                this.Text = "Add Librarian Details";
                //Shows the button to the user - enables personal data to be hidden while mouse is pressed on the button
                btnShowHiddenDetails.Visible = true;
            }
            else
            {
                
                this.Text = "Modify Librarian Details";
                btnAddModifyRecord.Text = "Modify Librarian Details";
                txtUserName.Enabled = false;
                txtPassword.Enabled = false;
                btnAddModifyRecord.Enabled = false;

                //Validate user - same user as displayed record
                //https://stackoverflow.com/questions/5233502/how-to-return-a-value-from-a-form-in-c
                frmVerifyUser verifyForm = new frmVerifyUser();
                var result = verifyForm.ShowDialog();
                if(result == DialogResult.Yes) //Returns a value from the subform when closed
                {
                    //test modify before verify user and delete later
                    //within modify only display the button once the same user has been checked
                    btnShowHiddenDetails.Visible = true;
                    txtPassword.Enabled = true;
                    btnAddModifyRecord.Enabled = true;
                }

                //Finds the selected record from the librarian table and creates a DataTable
                DataTable librarianDT = ConnectionManager.GetTable("SELECT * FROM Librarian WHERE librarianID=" 
                    + librarian.LibrarianID+ "");

                if (librarianDT.Rows.Count == 0)
                {
                    //This code should not run as the record was selected from the listView item on the maintenance screen
                    MessageBox.Show("Librarian with librarian ID " + librarian.LibrarianID + " doesn't exist.\n" +
                        "Program will return to previous screen.");
                    ResetTextBoxes();
                    CloseForm();
                }
                else
                {
                    //loads librarian instance with record details
                    librarian.LibrarianID = int.Parse(librarianDT.Rows[0]["librarianID"].ToString());
                    librarian.FirstName = librarianDT.Rows[0]["firstName"].ToString();
                    librarian.LastName = librarianDT.Rows[0]["lastName"].ToString();
                    librarian.Address = librarianDT.Rows[0]["address"].ToString();
                    librarian.Suburb = librarianDT.Rows[0]["suburb"].ToString();
                    librarian.State = librarianDT.Rows[0]["state"].ToString();
                    librarian.PostCode = int.Parse(librarianDT.Rows[0]["postCode"].ToString());
                    librarian.Email = librarianDT.Rows[0]["email"].ToString();
                    librarian.ContactNo = librarianDT.Rows[0]["contactNo"].ToString();
                    librarian.UserName = librarianDT.Rows[0]["userName"].ToString();
                    librarian.Password = librarianDT.Rows[0]["password"].ToString();

                    //loads the form fields with record details from the librarian instance
                    txtLibrarianID.Text = librarian.LibrarianID.ToString();
                    txtFirstName.Text = librarian.FirstName;
                    txtLastName.Text = librarian.LastName;
                    txtAddress.Text = librarian.Address;
                    txtSuburb.Text = librarian.Suburb;
                    cbState.Text = librarian.State;
                    txtPostCode.Text = librarian.PostCode.ToString();
                    txtEmail.Text = librarian.Email;
                    txtContactNo.Text = librarian.ContactNo;
                    txtUserName.Text = librarian.UserName;
                    txtPassword.Text = librarian.Password;
                }
            }
        }

        private void ResetTextBoxes()
        {
            //resets the form fields
            txtLibrarianID.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtAddress.Clear();
            txtSuburb.Clear();
            cbState.Text = "";
            txtPostCode.Clear();
            txtEmail.Clear();
            txtContactNo.Clear();
            txtUserName.Clear();
            txtPassword.Clear();
        }

        private void BtnShowHiddenDetails_MouseDown(object sender, MouseEventArgs e)
        {
            //Displays the personal fields while mouse is pushed on button
            txtAddress.UseSystemPasswordChar = false;
            txtSuburb.UseSystemPasswordChar = false;
            txtPostCode.UseSystemPasswordChar = false;
            txtUserName.UseSystemPasswordChar = false;
            txtContactNo.UseSystemPasswordChar = false;
            txtEmail.UseSystemPasswordChar = false;
        }

        private void BtnShowHiddenDetails_MouseUp(object sender, MouseEventArgs e)
        {
            //Hides the personal fields once mouse is released
            txtAddress.UseSystemPasswordChar = true;
            txtSuburb.UseSystemPasswordChar = true;
            txtPostCode.UseSystemPasswordChar = true;
            txtUserName.UseSystemPasswordChar = true;
            txtContactNo.UseSystemPasswordChar = true;
            txtEmail.UseSystemPasswordChar = true;
        }

        private void BtnAddModifyRecord_Click(object sender, EventArgs e)
        {
            if (CheckFields()) //If the field checks return a true, update the database
            {
                //stores the updated information into the librarian instance
                librarian.FirstName = txtFirstName.Text;
                librarian.LastName = txtLastName.Text;
                librarian.Address = txtAddress.Text;
                librarian.Suburb = txtSuburb.Text;
                librarian.State = cbState.Text;
                librarian.PostCode = int.Parse(txtPostCode.Text);
                librarian.ContactNo = txtContactNo.Text;
                librarian.Email = txtEmail.Text;
                librarian.UserName = txtUserName.Text;
                librarian.Password = txtPassword.Text;

                int recordSaved = librarian.LibrarianAddModify(); //udpate the librarian record with the method
                if (recordSaved == 0)
                {
                    //Where the update fails
                    MessageBox.Show("Update Operation failed. Check the values provided and try again."); 
                }
                else
                {
                    //where the add/modify completes
                    if (librarian.LibrarianID == 0)
                    {
                        MessageBox.Show("Librarian added successfully."); //add a librarian completed
                    }
                    else
                    {
                        MessageBox.Show("Librarian updated successfully."); //modify existing librarian completed
                    }
                }
                CloseForm();
            }
        }

        string errorMessage = "";
        private bool CheckFields()
        {
            //Checks the various fields for correct data / not length 0 unless appropriate
            errorMessage = "";
            CheckString(txtFirstName.Text, "First Name");
            CheckString(txtLastName.Text, "Last Name");
            CheckString(txtAddress.Text, "Address");
            CheckString(txtSuburb.Text, "Suburb");
            CheckString(cbState.Text, "State");
            //various checks for postcode
            if (CheckString(txtPostCode.Text, "Post code")) //checks if blank - continues if valid
            {
                try
                {
                    if (int.Parse(txtPostCode.Text.Trim()) > 9999) //checks if greater than the maximum postcode
                    {
                        errorMessage += "  Post code is incorrect\n";
                    }
                }
                catch
                {
                    errorMessage += "  Post code must be numerical\n"; //catches an error if the postcode is not numerical
                }
            }

            CheckString(txtUserName.Text, "User Name");
            CheckString(txtPassword.Text, "Password");

            //ContactNo can be blank but checks for general formatting ( ) and correct length
            if (txtContactNo.Text.Length > 0)
            {
                if (txtContactNo.Text.Length > 14 || !txtContactNo.Text.Contains("(") || !txtContactNo.Text.Contains(")")
                    || txtContactNo.Text.Length < 14)
                {
                    errorMessage += "  Phone number is incorrect. Format is: (##) #### ####\n";
                }
            }

            //email can be blank - this checks for general format of @ . and no spaces
            if (txtEmail.Text.Length > 0)
            {
                if (!txtEmail.Text.Contains("@") || !txtEmail.Text.Contains(".") || txtEmail.Text.Contains(" "))
                {
                    errorMessage += "  Email address is formatted incorrectly\n";
                }
            }

            if (errorMessage.Length > 0) //field information errors
            {
                MessageBox.Show("This information needs to be corrected:\n" + errorMessage);
                return false;
            }
            return true; //no field information errors
        }

        private bool CheckString(string item, string name)
        {
            //checks the item and uses name in the warning message to user of the issue
            if (item.Length == 0)
            {
                errorMessage += "  " + name + " cannot be blank\n";
                return false;
            }
            return true;
        }

        private void TxtPassword_Enter(object sender, EventArgs e)
        {
            //only works through ChangePassword when existing record - new allows initial entry of a password
            if (txtPassword.Enabled == true && librarian.LibrarianID != 0)
            {
                DialogResult dialogResult = MessageBox.Show("Do you wish to change the password?", "Password Change", 
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (dialogResult == DialogResult.Yes)
                {
                    //pass the original password until the form has been updated
                    frmChangePassword subForm = new frmChangePassword(librarian.Password);
                    var result = subForm.ShowDialog(); //load the change password form and store results
                    if (result == DialogResult.Yes) //if the password has changed
                    {
                        txtPassword.Text = subForm.returnValue; //store the new password into the form
                    }
                }
            }
        }

        private void TxtUserName_Leave(object sender, EventArgs e)
        {
            if (txtUserName.TextLength > 0)

            //Check librarian table to determine if the userName has already been used
            //DataTable librarianDT = ConnectionManager.GetTable("SELECT * FROM Librarian WHERE librarianID <>"  NOT EQUAL TO
            //        + librarian.LibrarianID + "");
            //If this returns a number > 0, then there is already a librarian with the same userName and therefore not allowed
            {
                DataTable librarianDT = ConnectionManager.GetTable("SELECT * FROM Librarian WHERE librarianID != "
                + librarian.LibrarianID + " AND userName = '" + txtUserName.Text + "'");

                if (!(librarianDT.Rows.Count == 0))
                {
                    MessageBox.Show("The username has already been used. Please enter an alternative.", "User Name Exists"
                        , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUserName.Text = "";
                    txtUserName.Focus();
                }
            }
        }

        private void TxtContactNo_Leave(object sender, EventArgs e)
        {
            //Allows the user to enter a full phone number and the program converts it to the standard format
            if (txtContactNo.Text.Length == 10)
            {
                string holdContactNo = "";
                for (int i = 0; i < txtContactNo.Text.Length; i++)
                {
                    switch (i)
                    {
                        case 0:
                            holdContactNo += "(" + txtContactNo.Text.Substring(i, 1);
                            break;
                        case 2:
                            holdContactNo += ") " + txtContactNo.Text.Substring(i, 1);
                            break;
                        case 6:
                            holdContactNo += " " + txtContactNo.Text.Substring(i, 1);
                            break;
                        default:
                            holdContactNo += txtContactNo.Text.Substring(i, 1);
                            break;
                    }
                }
                txtContactNo.Text = holdContactNo;
            }
        }

        private void CloseForm()
        {
            GlobalVariables.ClearLibrarianFilter();
            this.Close();
        }
    }
}
