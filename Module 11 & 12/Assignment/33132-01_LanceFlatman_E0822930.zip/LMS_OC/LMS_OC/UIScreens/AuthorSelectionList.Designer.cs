﻿namespace LMS_OC.UIScreens
{
    partial class frmAuthorSelectionList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvAuthorList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSelectAuthor = new System.Windows.Forms.Button();
            this.lblPartialName = new System.Windows.Forms.Label();
            this.txtSearchAuthor = new System.Windows.Forms.TextBox();
            this.btnAddAuthor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvAuthorList
            // 
            this.lvAuthorList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvAuthorList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lvAuthorList.FullRowSelect = true;
            this.lvAuthorList.GridLines = true;
            this.lvAuthorList.HideSelection = false;
            this.lvAuthorList.Location = new System.Drawing.Point(13, 13);
            this.lvAuthorList.MultiSelect = false;
            this.lvAuthorList.Name = "lvAuthorList";
            this.lvAuthorList.Size = new System.Drawing.Size(331, 285);
            this.lvAuthorList.TabIndex = 0;
            this.lvAuthorList.UseCompatibleStateImageBehavior = false;
            this.lvAuthorList.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Author ID";
            this.columnHeader1.Width = 0;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "AuthorName";
            this.columnHeader2.Width = 285;
            // 
            // btnSelectAuthor
            // 
            this.btnSelectAuthor.Location = new System.Drawing.Point(254, 304);
            this.btnSelectAuthor.Name = "btnSelectAuthor";
            this.btnSelectAuthor.Size = new System.Drawing.Size(90, 38);
            this.btnSelectAuthor.TabIndex = 3;
            this.btnSelectAuthor.Text = "Select Author";
            this.btnSelectAuthor.UseVisualStyleBackColor = true;
            this.btnSelectAuthor.Click += new System.EventHandler(this.BtnSelectAuthor_Click);
            // 
            // lblPartialName
            // 
            this.lblPartialName.AutoSize = true;
            this.lblPartialName.Location = new System.Drawing.Point(128, 305);
            this.lblPartialName.Name = "lblPartialName";
            this.lblPartialName.Size = new System.Drawing.Size(101, 13);
            this.lblPartialName.TabIndex = 5;
            this.lblPartialName.Text = "Name (min 3 chars):";
            // 
            // txtSearchAuthor
            // 
            this.txtSearchAuthor.Location = new System.Drawing.Point(129, 322);
            this.txtSearchAuthor.Name = "txtSearchAuthor";
            this.txtSearchAuthor.Size = new System.Drawing.Size(100, 20);
            this.txtSearchAuthor.TabIndex = 1;
            this.txtSearchAuthor.TextChanged += new System.EventHandler(this.TxtSearchAuthor_TextChanged);
            // 
            // btnAddAuthor
            // 
            this.btnAddAuthor.Location = new System.Drawing.Point(13, 304);
            this.btnAddAuthor.Name = "btnAddAuthor";
            this.btnAddAuthor.Size = new System.Drawing.Size(90, 38);
            this.btnAddAuthor.TabIndex = 2;
            this.btnAddAuthor.Text = "Add Author Details";
            this.btnAddAuthor.UseVisualStyleBackColor = true;
            this.btnAddAuthor.Click += new System.EventHandler(this.BtnAddAuthor_Click);
            // 
            // frmAuthorSelectionList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 354);
            this.ControlBox = false;
            this.Controls.Add(this.txtSearchAuthor);
            this.Controls.Add(this.lblPartialName);
            this.Controls.Add(this.btnAddAuthor);
            this.Controls.Add(this.btnSelectAuthor);
            this.Controls.Add(this.lvAuthorList);
            this.MaximumSize = new System.Drawing.Size(372, 393);
            this.MinimumSize = new System.Drawing.Size(372, 393);
            this.Name = "frmAuthorSelectionList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Author Selection List";
            this.Load += new System.EventHandler(this.FrmAuthorSelectionList_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvAuthorList;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btnSelectAuthor;
        private System.Windows.Forms.Label lblPartialName;
        private System.Windows.Forms.TextBox txtSearchAuthor;
        private System.Windows.Forms.Button btnAddAuthor;
    }
}