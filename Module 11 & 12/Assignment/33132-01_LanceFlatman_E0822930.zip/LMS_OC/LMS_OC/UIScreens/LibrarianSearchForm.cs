﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmLibrarianSearchForm : Form
    {
        public frmLibrarianSearchForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            GlobalVariables.ClearLibrarianFilter();
            this.Close();
        }

        private void BtnSetFilter_Click(object sender, EventArgs e)
        {
            //Checks for valid information e.g. does not allow special characters (minimise SQLinjection)
            if (!(GlobalVariables.TestFilterIsValid(txtLastName.Text) || GlobalVariables.TestFilterIsValid(txtFirstName.Text)))
            {
                MessageBox.Show("Characters or Numbers only for valid filter conditions.");
                txtLastName.Text = "";
                txtFirstName.Text = "";
                txtFirstName.Focus();
                return;
            }

            GlobalVariables.LibrarianLastName = txtLastName.Text.Trim();
            GlobalVariables.LibrarianFirstName = txtFirstName.Text.Trim();

            this.Close();
        }
    }
}
