﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmAuthorMaintenanceForm : Form
    {
        Author author = new Author(); //creates an author instance
        SearchFilterButtonState authorSearchFilterButtonState;  // holds the state of the search / filter button

        private ListViewItemSorter lvItemSorter; //used to sort columns in listView items

        public frmAuthorMaintenanceForm()
        {
            InitializeComponent();

            // assign items for sorting listView columns
            lvItemSorter = new ListViewItemSorter();
            this.lvAuthorList.ListViewItemSorter = lvItemSorter;

            // link the Search / Filter button to the button state class
            authorSearchFilterButtonState = new SearchFilterButtonState(btnSearchFilterAuthorList);
        }

        private void BtnCloseForm_Click(object sender, EventArgs e)
        {
            GlobalVariables.AuthorName="";
            this.Close();
        }

        private void FrmAuthorMaintenanceForm_Load(object sender, EventArgs e)
        {
            //Opens the form and loads all author data
            LoadAuthorList();
        }

        private void BtnAddAuthor_Click(object sender, EventArgs e)
        {
            frmAuthorDetailsForm subForm = new frmAuthorDetailsForm();
            subForm.SetAuthorID(0); //Passes this as authorID - if 0 then new author record
            subForm.ShowDialog();
            ResetFilterAndDisplayForm();
        }

        private void BtnModifyAuthor_Click(object sender, EventArgs e)
        {
            if (lvAuthorList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select an Author Record to Modify their information.");
            }
            else
            {
                // This opens the author details form setting it to modify existing author record to update the table
                frmAuthorDetailsForm subForm = new frmAuthorDetailsForm();
                subForm.SetAuthorID(int.Parse(lvAuthorList.SelectedItems[0].Text)); //passes the author to the form
                subForm.ShowDialog();
                ResetFilterAndDisplayForm();
            }
        }

        private void BtnSearchFilterAuthorList_Click(object sender, EventArgs e)
        {
            //This section manages the author search filter process and button state
            //State already set
            if (GlobalVariables.AuthorName.Length>0)
            {
                ResetFilterAndDisplayForm();
            }
            else
            {
                //State not set
                frmAuthorSearchForm searchForm = new frmAuthorSearchForm();
                searchForm.ShowDialog();

                if (GlobalVariables.AuthorName.Length>0)
                {
                    authorSearchFilterButtonState.SearchFilterState("Press to Clear Author Filter");
                    LoadAuthorList();
                }
            }
        }

        private void LoadAuthorList()
        {
            lvAuthorList.Items.Clear();
            DataTable authorDT = ConnectionManager.GetTable(author.FilteredAuthorSQL());
            if (authorDT.Rows.Count == 0)
            {
                //Create a response message based upon the state of the author search/filter
                string responseMessage = "No author records to display.\nPlease ";
                if (GlobalVariables.AuthorName.Length>0)
                {
                    responseMessage += "clear and change the filter.";
                }
                else
                {
                    responseMessage += "add author records.";
                }
                MessageBox.Show(responseMessage);
            }
            else
            {
                //moves through the authorDT (DataTable) and adds the records to the listView
                for (int record = 0; record < authorDT.Rows.Count; record++)
                {
                    ListViewItem listViewItem = new ListViewItem(authorDT.Rows[record]["authorID"].ToString());
                    listViewItem.SubItems.Add(authorDT.Rows[record]["authorName"].ToString());
                    lvAuthorList.Items.Add(listViewItem);
                }
            }
        }

        private void ResetFilterAndDisplayForm()
        {
            //When the program returns it resets the author filter and refreshes the form
            GlobalVariables.AuthorName="";
            authorSearchFilterButtonState.ResetFilterState();
            LoadAuthorList();
        }

        private void LvAuthorList_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // This section of code handles the sorting of listView columns
            // General code structure was taken from links highlighted in ListViewItemSorter.cs and modified to suit
            int testClickColumn = e.Column;

            //checks performed within ListViewItemSorter class
            lvItemSorter.checkPreviousOrder(testClickColumn);

            // Perform the sort with these new sort options.
            this.lvAuthorList.Sort();
            return;
        }
    }
}
