﻿namespace LMS_OC.UIScreens
{
    partial class frmBookIssueConfirmSave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbRecordDetails = new System.Windows.Forms.GroupBox();
            this.lblBookDetails = new System.Windows.Forms.Label();
            this.txtBookID = new System.Windows.Forms.TextBox();
            this.txtBookTitle = new System.Windows.Forms.TextBox();
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.lblStudentDetails = new System.Windows.Forms.Label();
            this.txtStudentName = new System.Windows.Forms.TextBox();
            this.gbDateDetails = new System.Windows.Forms.GroupBox();
            this.lblReturnDate = new System.Windows.Forms.Label();
            this.dtpReturnReserveDate = new System.Windows.Forms.DateTimePicker();
            this.lblIssueDate = new System.Windows.Forms.Label();
            this.txtIssueDate = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirmIssue = new System.Windows.Forms.Button();
            this.gbRecordDetails.SuspendLayout();
            this.gbDateDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbRecordDetails
            // 
            this.gbRecordDetails.Controls.Add(this.txtStudentName);
            this.gbRecordDetails.Controls.Add(this.txtStudentID);
            this.gbRecordDetails.Controls.Add(this.lblStudentDetails);
            this.gbRecordDetails.Controls.Add(this.txtBookTitle);
            this.gbRecordDetails.Controls.Add(this.txtBookID);
            this.gbRecordDetails.Controls.Add(this.lblBookDetails);
            this.gbRecordDetails.Location = new System.Drawing.Point(13, 13);
            this.gbRecordDetails.Name = "gbRecordDetails";
            this.gbRecordDetails.Size = new System.Drawing.Size(500, 87);
            this.gbRecordDetails.TabIndex = 0;
            this.gbRecordDetails.TabStop = false;
            this.gbRecordDetails.Text = "Record Details";
            // 
            // lblBookDetails
            // 
            this.lblBookDetails.AutoSize = true;
            this.lblBookDetails.Location = new System.Drawing.Point(9, 24);
            this.lblBookDetails.Name = "lblBookDetails";
            this.lblBookDetails.Size = new System.Drawing.Size(84, 13);
            this.lblBookDetails.TabIndex = 0;
            this.lblBookDetails.Text = "Book ID && Title :";
            // 
            // txtBookID
            // 
            this.txtBookID.Enabled = false;
            this.txtBookID.Location = new System.Drawing.Point(120, 21);
            this.txtBookID.Name = "txtBookID";
            this.txtBookID.ReadOnly = true;
            this.txtBookID.Size = new System.Drawing.Size(70, 20);
            this.txtBookID.TabIndex = 1;
            // 
            // txtBookTitle
            // 
            this.txtBookTitle.Enabled = false;
            this.txtBookTitle.Location = new System.Drawing.Point(202, 21);
            this.txtBookTitle.Name = "txtBookTitle";
            this.txtBookTitle.ReadOnly = true;
            this.txtBookTitle.Size = new System.Drawing.Size(284, 20);
            this.txtBookTitle.TabIndex = 3;
            // 
            // txtStudentID
            // 
            this.txtStudentID.Enabled = false;
            this.txtStudentID.Location = new System.Drawing.Point(120, 47);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.ReadOnly = true;
            this.txtStudentID.Size = new System.Drawing.Size(70, 20);
            this.txtStudentID.TabIndex = 5;
            // 
            // lblStudentDetails
            // 
            this.lblStudentDetails.AutoSize = true;
            this.lblStudentDetails.Location = new System.Drawing.Point(9, 50);
            this.lblStudentDetails.Name = "lblStudentDetails";
            this.lblStudentDetails.Size = new System.Drawing.Size(104, 13);
            this.lblStudentDetails.TabIndex = 4;
            this.lblStudentDetails.Text = "Student ID && Name :";
            // 
            // txtStudentName
            // 
            this.txtStudentName.Enabled = false;
            this.txtStudentName.Location = new System.Drawing.Point(202, 47);
            this.txtStudentName.Name = "txtStudentName";
            this.txtStudentName.ReadOnly = true;
            this.txtStudentName.Size = new System.Drawing.Size(284, 20);
            this.txtStudentName.TabIndex = 7;
            // 
            // gbDateDetails
            // 
            this.gbDateDetails.Controls.Add(this.txtIssueDate);
            this.gbDateDetails.Controls.Add(this.dtpReturnReserveDate);
            this.gbDateDetails.Controls.Add(this.lblIssueDate);
            this.gbDateDetails.Controls.Add(this.lblReturnDate);
            this.gbDateDetails.Location = new System.Drawing.Point(13, 106);
            this.gbDateDetails.Name = "gbDateDetails";
            this.gbDateDetails.Size = new System.Drawing.Size(432, 61);
            this.gbDateDetails.TabIndex = 1;
            this.gbDateDetails.TabStop = false;
            this.gbDateDetails.Text = "Date Details";
            // 
            // lblReturnDate
            // 
            this.lblReturnDate.AutoSize = true;
            this.lblReturnDate.Location = new System.Drawing.Point(9, 24);
            this.lblReturnDate.Name = "lblReturnDate";
            this.lblReturnDate.Size = new System.Drawing.Size(71, 13);
            this.lblReturnDate.TabIndex = 0;
            this.lblReturnDate.Text = "Return Date :";
            // 
            // dtpReturnReserveDate
            // 
            this.dtpReturnReserveDate.CustomFormat = "";
            this.dtpReturnReserveDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReturnReserveDate.Location = new System.Drawing.Point(120, 21);
            this.dtpReturnReserveDate.Name = "dtpReturnReserveDate";
            this.dtpReturnReserveDate.Size = new System.Drawing.Size(102, 20);
            this.dtpReturnReserveDate.TabIndex = 1;
            // 
            // lblIssueDate
            // 
            this.lblIssueDate.AutoSize = true;
            this.lblIssueDate.Location = new System.Drawing.Point(242, 24);
            this.lblIssueDate.Name = "lblIssueDate";
            this.lblIssueDate.Size = new System.Drawing.Size(64, 13);
            this.lblIssueDate.TabIndex = 0;
            this.lblIssueDate.Text = "Issue Date :";
            // 
            // txtIssueDate
            // 
            this.txtIssueDate.Enabled = false;
            this.txtIssueDate.Location = new System.Drawing.Point(312, 21);
            this.txtIssueDate.Name = "txtIssueDate";
            this.txtIssueDate.ReadOnly = true;
            this.txtIssueDate.Size = new System.Drawing.Size(100, 20);
            this.txtIssueDate.TabIndex = 2;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(423, 173);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 38);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // btnConfirmIssue
            // 
            this.btnConfirmIssue.Location = new System.Drawing.Point(13, 173);
            this.btnConfirmIssue.Name = "btnConfirmIssue";
            this.btnConfirmIssue.Size = new System.Drawing.Size(90, 38);
            this.btnConfirmIssue.TabIndex = 3;
            this.btnConfirmIssue.Text = "Confirm Book Issue";
            this.btnConfirmIssue.UseVisualStyleBackColor = true;
            this.btnConfirmIssue.Click += new System.EventHandler(this.BtnConfirmIssue_Click);
            // 
            // frmBookIssueConfirmSave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 220);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfirmIssue);
            this.Controls.Add(this.gbDateDetails);
            this.Controls.Add(this.gbRecordDetails);
            this.MaximumSize = new System.Drawing.Size(539, 259);
            this.MinimumSize = new System.Drawing.Size(539, 259);
            this.Name = "frmBookIssueConfirmSave";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Book Issue Details";
            this.Load += new System.EventHandler(this.FrmBookIssueConfirmSave_Load);
            this.gbRecordDetails.ResumeLayout(false);
            this.gbRecordDetails.PerformLayout();
            this.gbDateDetails.ResumeLayout(false);
            this.gbDateDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbRecordDetails;
        private System.Windows.Forms.TextBox txtStudentName;
        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.Label lblStudentDetails;
        private System.Windows.Forms.TextBox txtBookTitle;
        private System.Windows.Forms.TextBox txtBookID;
        private System.Windows.Forms.Label lblBookDetails;
        private System.Windows.Forms.GroupBox gbDateDetails;
        private System.Windows.Forms.DateTimePicker dtpReturnReserveDate;
        private System.Windows.Forms.Label lblReturnDate;
        private System.Windows.Forms.TextBox txtIssueDate;
        private System.Windows.Forms.Label lblIssueDate;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirmIssue;
    }
}