﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.DataAccessLayer;
using LMS_OC.BusinessLogicLayer;


//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmAuthorDetailsForm : Form
    {
        Author author = new Author();
        public int returnValue = 0;

        //method to store a authorID into the instance of author. 0 means add author
        public void SetAuthorID(int selectedRecord)
        {
            author.AuthorID = selectedRecord;
        }

        public frmAuthorDetailsForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            CloseForm();
        }

        private void FrmAuthorDetailsForm_Load(object sender, EventArgs e)
        {
            if (author.AuthorID == 0) //Form option for new author
            {
                this.Text = "Add Author Details";
            }
            else
            {
                this.Text = "Modify Author Details"; //form option to modify existing author
                btnAddModifyAuthorDetails.Text = "Modify Author Details";
            
                //Finds the selected record from the author table and creates a DataTable
                DataTable authorDT = ConnectionManager.GetTable("SELECT * FROM Author WHERE authorID =" 
                    + author.AuthorID + "");

                if (authorDT.Rows.Count == 0)
                {
                    //This code should not run as the record was selected from the listView item on the maintenance screen
                    MessageBox.Show("Author with authorID " + author.AuthorID + " doesn't exist.\n" +
                        "Program will return to previous screen.");
                    ResetTextBoxes();
                    CloseForm();
                }
                else
                {
                    //loads author instance with record details
                    author.AuthorID = int.Parse(authorDT.Rows[0]["authorID"].ToString());
                    author.AuthorName = authorDT.Rows[0]["authorName"].ToString();

                    //loads the form fields with record details from the author instance
                    txtAuthorID.Text = author.AuthorID.ToString();
                    txtAuthorName.Text = author.AuthorName;
                    txtAuthorName.Focus();
                }
            }
        }

        public int newAuthorID = 0;
        private void BtnAddModifyAuthorDetails_Click(object sender, EventArgs e)
        {
            if (CheckFields()) //Checks the entered information for validity
            {
                author.AuthorName = txtAuthorName.Text;  //updates the author instance

                newAuthorID = author.AuthorAddModify(); //updates the author table
                if (newAuthorID == 0)
                {
                    MessageBox.Show("Update Operation failed. Check the values provided and try again."); //shows if failed
                }
                else
                {
                    if (author.AuthorID == 0)
                    {
                        MessageBox.Show("Author added successfully."); //displays if new author
                    }
                    else
                    {
                        MessageBox.Show("Author updated successfully."); //displays if existing author
                        newAuthorID = 0; //This signifies to the calling form the Author is prevously existing.
                    }
                }
                CloseForm();
            }
        }

        private string errorMessage = "";
        private bool CheckFields()
        {            
            //Checks the various fields for correct data / not length 0 unless appropriate
            errorMessage = "";
            if(CheckString(txtAuthorName.Text, "Author Name"))
            {
                if(txtAuthorName.Text.Contains("'"))
                {
                    errorMessage += "  Author Name cannot contain '\n";
                }
            }


            if (errorMessage.Length > 0) //field information errors
            {
                MessageBox.Show("This information needs to be corrected:\n" + errorMessage);
                return false;
            }
            return true; //no field information errors
        }

        private bool CheckString(string item, string name)
        {
            //checks the item and uses name in the warning message to user of the issue
            if (item.Length == 0)
            {
                errorMessage += "  " + name + " cannot be blank\n";
                return false;
            }
            return true;
        }

        private void ResetTextBoxes()
        {
            txtAuthorName.Text = "";
            txtAuthorName.Focus();
        }

        private void CloseForm()
        {
            GlobalVariables.AuthorName = "";
            this.returnValue = newAuthorID;
            if (newAuthorID > 0) //Where a new author has been added this is true
            {
                this.DialogResult = DialogResult.Yes;
            }
            else
            {
                this.DialogResult = DialogResult.No;
            }
            this.Close();
        }
    }
}
