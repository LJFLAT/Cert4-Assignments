﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmBookQuantityAdjustments : Form
    {
        BookAdjustment bookAdjustment = new BookAdjustment();

        private int bookID, maxBooks, borrowedBooks; //holds bookID and numbers to calculate averages later
        decimal originalBookPriceAverage, newAdjustedPrice; //used to determine the adjusted price and new ajusted price
        public frmBookQuantityAdjustments(int selectedBookID)
        {
            InitializeComponent();
            bookID = selectedBookID;
        }

        private void FrmBookQuantityAdjustments_Load(object sender, EventArgs e)
        {
            //Look up existing book information
            DataTable bookOriginalDetails = ConnectionManager.GetTable("SELECT * FROM Book WHERE bookID = " + bookID + "");
            if (bookOriginalDetails.Rows.Count == 0)
            {
                //This code should not run as the record was selected from the listView item on the maintenance screen
                MessageBox.Show("Book with bookID " + bookID + " doesn't exist.\n" +
                    "Program will return to previous screen.");
                this.Close();
            }
            else
            {
                //loads historic book information - used for processes and calculations later
                maxBooks = int.Parse(bookOriginalDetails.Rows[0]["noOfAvailableBooks"].ToString());
                borrowedBooks = int.Parse(bookOriginalDetails.Rows[0]["noOfBorrowedBooks"].ToString());
                originalBookPriceAverage = decimal.Parse(bookOriginalDetails.Rows[0]["price"].ToString());
                txtTitle.Text = bookOriginalDetails.Rows[0]["title"].ToString();
            }
            dtpAdjustmentDate.Value = DateTime.Today;
            txtBookID.Text = bookID.ToString();

            LoadPriorAdjustments();
        }

        private void LoadPriorAdjustments()
        {
            //Loads prior adjustments into the listView
            DataTable bookAdjustmentHistoryDT = ConnectionManager.GetTable("SELECT dateAdjusted, quantityAdjusted, " +
                "costPerBook, adjustmentComment, Librarian.firstName + ' ' + Librarian.lastName AS libName " +
                "FROM BookAdjustments LEFT JOIN Librarian ON BookAdjustments.LibrarianID = Librarian.LibrarianID " +
                "WHERE bookID = " + bookID + " ORDER BY dateAdjusted DESC");
            if (bookAdjustmentHistoryDT.Rows.Count > 0)
            {
                lvPriorAdjustments.Items.Clear();
                for (int record = 0; record < bookAdjustmentHistoryDT.Rows.Count; record++)
                {
                    string tempDate = bookAdjustmentHistoryDT.Rows[record]["dateAdjusted"].ToString();
                    ListViewItem listViewItem = new ListViewItem(tempDate.Substring(0,10));
                    listViewItem.SubItems.Add(bookAdjustmentHistoryDT.Rows[record]["quantityAdjusted"].ToString());
                    listViewItem.SubItems.Add(bookAdjustmentHistoryDT.Rows[record]["costPerBook"].ToString());
                    listViewItem.SubItems.Add(bookAdjustmentHistoryDT.Rows[record]["adjustmentComment"].ToString());
                    listViewItem.SubItems.Add(bookAdjustmentHistoryDT.Rows[record]["libName"].ToString());
                    lvPriorAdjustments.Items.Add(listViewItem);
                }
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnAddAdjustmentDetails_Click(object sender, EventArgs e)
        {
            //Re-check for blanks only (if user bypasses a field by mouse click) - correctness has already been tested
            //Blanks are tested at the time of input as these may affect other methods / calculations
            if (CheckFields())
            {
                bookAdjustment.BookID = bookID;
                bookAdjustment.QuantityAdjusted = int.Parse(txtQuantityAdjusted.Text);
                bookAdjustment.CostPerBook = decimal.Parse(txtCostPerBookAdjustment.Text);
                bookAdjustment.AdjustmentComment = txtSavedComment.Text;
                bookAdjustment.AdjustmentDate = dtpAdjustmentDate.Value;
                bookAdjustment.LibrarianID = int.Parse(System.Environment.GetEnvironmentVariable("librarianID"));

                int recordCount = bookAdjustment.BookAdjustmentAdd(newAdjustedPrice);
                if (recordCount == 0)
                {
                    MessageBox.Show("Save Operation failed. Check the values provided and try again."); //shows if failed
                }
                else
                {
                    MessageBox.Show("Book Adjustment added successfully."); //displays if new book
                    this.Close();
                }
            }
            else
            {
                dtpAdjustmentDate.Focus();
            }
        }

        private string errorMessage;
        private bool CheckFields()
        {
            errorMessage = "";
            CheckString(cbCategory.Text, "Category");
            CheckString(txtAdditionalComment.Text, "Additional Comment");
            CheckString(txtQuantityAdjusted.Text, "Quantity Adjusted");
            CheckString(txtCostPerBookAdjustment.Text, "Price / Book Adjustment");

            if (errorMessage.Length > 0) //field information errors
            {
                MessageBox.Show("This information needs to be corrected:\n" + errorMessage);
                return false;
            }

            return true;
        }

        private bool CheckString(string item, string name)
        {
            //checks the item and uses name in the warning message to user of the issue
            if (item.Length == 0)
            {
                errorMessage += "  " + name + " cannot be blank\n";
                return false;
            }
            return true;
        }

        private void DtpAdjustmentDate_Leave(object sender, EventArgs e)
        {
            if (dtpAdjustmentDate.Value > DateTime.Today)
            {
                MessageBox.Show("A forward date cannot be entered", "Invalid Date", MessageBoxButtons.OK);
                dtpAdjustmentDate.Value = DateTime.Today;
                dtpAdjustmentDate.Focus();
            }
            else
            {
                cbCategory.Focus();
            }
        }

        private string categoryText = "";
        private void CbCategory_TextChanged(object sender, EventArgs e)
        {
            //Return string prior to the first '(' and removes any ending blanks - stores result in categoryText
            //used to create the text in the txtSavedComment field
            categoryText = cbCategory.Text.Substring(0, cbCategory.Text.IndexOf('(') - 1);
            txtAdditionalComment.Text = "";
            SavedCommentCreator();

            //displays existing pricing information for existing books
            txtQuantityAdjusted.Text = "";
            txtCostPerBookAdjustment.Text = originalBookPriceAverage.ToString("0.00");
            txtAdditionalComment.Text = "";
            LabelOriginalAveragePrice();

            //revert to original if previously set
            if (txtQuantityAdjusted.Enabled == false)
            {
                txtQuantityAdjusted.Enabled = true;
                txtQuantityAdjusted.ReadOnly = false;
                txtQuantityAdjusted.Text = "";
            }
            lblQuantityRange.Text = "";

            //note that Donations has na as part of its value therefore was triggering this statement
            if (cbCategory.Text.IndexOf("na)") > 0) //where na selected - quantity adjustments not relevant (only price adjustments)
            {
                txtQuantityAdjusted.Enabled = false;
                txtQuantityAdjusted.ReadOnly = true;
                txtQuantityAdjusted.Text = "0";
            }
            else if (cbCategory.Text.IndexOf('-') > 0) //any quantity adjustment which allows a -ve (not relevant for +ve only adjustments
            {
                lblQuantityRange.Text = "Minimum adjustment value : -" + maxBooks;
            }
            txtAdditionalComment.Focus();
        }

        //function to store the relevant text and original book value to the label
        private void LabelOriginalAveragePrice()
        {
            newAdjustedPrice = 0;
            lblNewRemainingBookAverage.Text = "Average Existing Price : $" + originalBookPriceAverage.ToString("0.00");
        }

        //Check that a category has been selected
        private void CbCategory_Leave(object sender, EventArgs e)
        {
            if (cbCategory.Text.Length == 0)
            {
                MessageBox.Show("Category must be selected to continue", "Category not entered", MessageBoxButtons.OK);
                cbCategory.Text = "";
                cbCategory.Focus();
            }
        }

        //on changes to additional comment - updates the SavedCommentCreator string
        private void TxtAdditionalComment_TextChanged(object sender, EventArgs e)
        {
            SavedCommentCreator();
        }

        //Creates the comment that will be saved with the BookAdjustment Record
        private void SavedCommentCreator()
        {
            txtSavedComment.Text = categoryText + " - " + txtAdditionalComment.Text;
        }

        //Check to ensure a comment has been entered
        private void TxtAdditionalComment_Leave(object sender, EventArgs e)
        {
            if(txtAdditionalComment.TextLength == 0)
            {
                MessageBox.Show("Please enter a comment", "Comment not entered",MessageBoxButtons.OK);
                txtAdditionalComment.Focus();
            }
        }

        //Loads the field with the original book price - as default
        private void TxtQuantityAdjusted_TextChanged(object sender, EventArgs e)
        {
            txtCostPerBookAdjustment.Text = originalBookPriceAverage.ToString();
        }


        private void TxtQuantityAdjusted_Leave(object sender, EventArgs e)
        {
            //user should not be able to enter this field if not enabled via 'na' in cbCategory Changed above
            if (txtQuantityAdjusted.TextLength == 0)
            {
                MessageBox.Show("A quantity needs to be entered", "No quantity entered", MessageBoxButtons.OK);
                txtQuantityAdjusted.Focus();
            }
            else
            {
                try
                {
                    int testQuantityAdjusted = int.Parse(txtQuantityAdjusted.Text); //This will fail if not a whole number

                    //tests if 0 when an adjustment amount should be entered
                    if(testQuantityAdjusted == 0)
                    {
                        MessageBox.Show("Adjusted quantity cannot be 0","Incorrect quantity", MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                        ResetQuantityAdjusted();
                    }
                    //tests if the adjusted quantity is entered as a positive when not applicable based upon cbCategory
                    else if (cbCategory.Text.IndexOf('+') == -1 && testQuantityAdjusted > 0)
                    {
                        MessageBox.Show("Adjusted books must be a negative number.", "Incorrect quantity",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        ResetQuantityAdjusted();
                    }
                    //tests if a negative cbCategory and is less than the noOfAvailable books on hand at present.
                    else if (cbCategory.Text.IndexOf('-') > 0 && testQuantityAdjusted < -maxBooks)
                    {
                            MessageBox.Show("Adjusted books greater than number available.", "Greater than available",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            ResetQuantityAdjusted();
                    }
                    //tests if no -ve in cbCategory and where adjusted quantity is less than 0
                    else if(cbCategory.Text.IndexOf('-') == -1 && testQuantityAdjusted < 0)
                    {
                        MessageBox.Show("Adjusted book cannot be negative.","Incorrect quantity", 
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        ResetQuantityAdjusted();
                    }
                }
                catch
                {
                    //IF the entered amount was not a whole number
                    MessageBox.Show("Adjusted quantity must be a whole number.","Adjusted Quantity incorrect", 
                        MessageBoxButtons.OK);
                    ResetQuantityAdjusted();
                }
            }
        }

        //Where there was an incorrect entry in the QuantityAdjusted field - reset and return focus there
        private void ResetQuantityAdjusted()
        {
            txtQuantityAdjusted.Text = "";
            txtQuantityAdjusted.Focus();
        }

        private void TxtCostPerBookAdjustment_TextChanged(object sender, EventArgs e)
        {
            //This looks for any changes to the CostPerBookAdjustment field
            try
            {
                //Tests to see if valid input
                decimal inputAdjustedPrice = decimal.Parse(txtCostPerBookAdjustment.Text);
                if(inputAdjustedPrice != originalBookPriceAverage)
                {
                    //Runs the function which calculates the new average price for remaining books based 
                    //upon the varied adjustment amount
                    newAdjustedPrice = AveragePriceRecalculation();
                    lblNewRemainingBookAverage.Text = "New average cost / book : $" + newAdjustedPrice.ToString("0.00");
                }
                else
                {
                    LabelOriginalAveragePrice(); //resets the label with original text and value
                    SavedCommentCreator(); //ensures the comment is updated to calculated
                }
            }
            catch
            {
                //Only display warning message when not blank
                if (txtCostPerBookAdjustment.TextLength > 0)
                {
                    //Where a non decimal has been entered
                    MessageBox.Show("Price must be a decimal number.", "Price incorrectly entered",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                AdjustedPriceReset();
            }
        }

        private void AdjustedPriceReset()
        {
            txtCostPerBookAdjustment.Text = originalBookPriceAverage.ToString("0.00");
            txtCostPerBookAdjustment.Focus();
        }

        private decimal AveragePriceRecalculation()
        {
            if (cbCategory.Text.IndexOf("na)") > 0)
            {
                //This section calculates when value of the books has changed without affecting quantity
                newAdjustedPrice = decimal.Parse(txtCostPerBookAdjustment.Text); //What the user has entered
                //Change in total value of books
                decimal changeInTotalBookValue = (decimal)(maxBooks + borrowedBooks) * 
                    (newAdjustedPrice - originalBookPriceAverage);

                SavedCommentCreator(); //Change Comment to calculated value and then add Change value amount
                if(changeInTotalBookValue<0)
                {
                    txtSavedComment.Text += " ($" + changeInTotalBookValue + ")"; //Brackets for negative value (clearer)
                }
                else
                {
                    txtSavedComment.Text += " $" + changeInTotalBookValue;
                }
            }
            else
            {
                //This section calculates where book quantities have changed and their impact on the origina average price
                //This calculates the total cost of books on hand prior to adjustments
                decimal originalTotalValue = ((decimal)maxBooks + (decimal)borrowedBooks) * (originalBookPriceAverage);
                //Calculates the additional/reduction value of any change by the entered price of the change
                decimal adjustedAmount = decimal.Parse(txtQuantityAdjusted.Text) * decimal.Parse(txtCostPerBookAdjustment.Text);
                //divides this new total by the adjusted total (maxBooks (original) + borrowed + adjQty)
                newAdjustedPrice = ((originalTotalValue + adjustedAmount) /
                    ((decimal)maxBooks + (decimal)borrowedBooks + decimal.Parse(txtQuantityAdjusted.Text)));
            }
            return newAdjustedPrice;
        }

        private void TxtCostPerBookAdjustment_Leave(object sender, EventArgs e)
        {
            decimal tempCostAdjustment = decimal.Parse(txtCostPerBookAdjustment.Text);
            txtCostPerBookAdjustment.Text = tempCostAdjustment.ToString("0.00");
        }
    }
}
