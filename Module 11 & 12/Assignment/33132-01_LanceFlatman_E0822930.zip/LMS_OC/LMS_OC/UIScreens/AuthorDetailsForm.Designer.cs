﻿namespace LMS_OC.UIScreens
{
    partial class frmAuthorDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAddModifyAuthorDetails = new System.Windows.Forms.Button();
            this.lblAuthorID = new System.Windows.Forms.Label();
            this.lblAuthorName = new System.Windows.Forms.Label();
            this.txtAuthorID = new System.Windows.Forms.TextBox();
            this.txtAuthorName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(317, 110);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 38);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel / Close Form";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // btnAddModifyAuthorDetails
            // 
            this.btnAddModifyAuthorDetails.Location = new System.Drawing.Point(12, 110);
            this.btnAddModifyAuthorDetails.Name = "btnAddModifyAuthorDetails";
            this.btnAddModifyAuthorDetails.Size = new System.Drawing.Size(90, 38);
            this.btnAddModifyAuthorDetails.TabIndex = 1;
            this.btnAddModifyAuthorDetails.Text = "Add Author Details";
            this.btnAddModifyAuthorDetails.UseVisualStyleBackColor = true;
            this.btnAddModifyAuthorDetails.Click += new System.EventHandler(this.BtnAddModifyAuthorDetails_Click);
            // 
            // lblAuthorID
            // 
            this.lblAuthorID.AutoSize = true;
            this.lblAuthorID.Location = new System.Drawing.Point(13, 13);
            this.lblAuthorID.Name = "lblAuthorID";
            this.lblAuthorID.Size = new System.Drawing.Size(55, 13);
            this.lblAuthorID.TabIndex = 18;
            this.lblAuthorID.Text = "Author ID:";
            // 
            // lblAuthorName
            // 
            this.lblAuthorName.AutoSize = true;
            this.lblAuthorName.Location = new System.Drawing.Point(12, 39);
            this.lblAuthorName.Name = "lblAuthorName";
            this.lblAuthorName.Size = new System.Drawing.Size(77, 13);
            this.lblAuthorName.TabIndex = 19;
            this.lblAuthorName.Text = "Author Names:";
            // 
            // txtAuthorID
            // 
            this.txtAuthorID.Enabled = false;
            this.txtAuthorID.Location = new System.Drawing.Point(95, 10);
            this.txtAuthorID.Name = "txtAuthorID";
            this.txtAuthorID.ReadOnly = true;
            this.txtAuthorID.Size = new System.Drawing.Size(72, 20);
            this.txtAuthorID.TabIndex = 20;
            // 
            // txtAuthorName
            // 
            this.txtAuthorName.Location = new System.Drawing.Point(95, 36);
            this.txtAuthorName.Name = "txtAuthorName";
            this.txtAuthorName.Size = new System.Drawing.Size(312, 20);
            this.txtAuthorName.TabIndex = 0;
            // 
            // frmAuthorDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 158);
            this.ControlBox = false;
            this.Controls.Add(this.txtAuthorName);
            this.Controls.Add(this.txtAuthorID);
            this.Controls.Add(this.lblAuthorName);
            this.Controls.Add(this.lblAuthorID);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnAddModifyAuthorDetails);
            this.Name = "frmAuthorDetailsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Author Details Form";
            this.Load += new System.EventHandler(this.FrmAuthorDetailsForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAddModifyAuthorDetails;
        private System.Windows.Forms.Label lblAuthorID;
        private System.Windows.Forms.Label lblAuthorName;
        private System.Windows.Forms.TextBox txtAuthorID;
        private System.Windows.Forms.TextBox txtAuthorName;
    }
}