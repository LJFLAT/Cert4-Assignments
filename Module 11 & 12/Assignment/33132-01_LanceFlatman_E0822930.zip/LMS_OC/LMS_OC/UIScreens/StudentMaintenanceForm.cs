﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmStudentMaintenanceForm : Form
    {
        Student student = new Student();  //initialises a Student class object
        SearchFilterButtonState studentSearchFilterButtonState;  // holds the state of the search / filter button

        private ListViewItemSorter lvItemSorter; //used to sort columns in listView items

        public frmStudentMaintenanceForm()
        {
            InitializeComponent();

            // assign items for sorting listView columns
            lvItemSorter = new ListViewItemSorter();
            this.lvStudentList.ListViewItemSorter = lvItemSorter;

            // link the Search / Filter button to the button state class
            studentSearchFilterButtonState = new SearchFilterButtonState(btnSearchFilterStudentList);
        }

        private void StudentMaintenanceForm_Load(object sender, EventArgs e)
        {
            //Opens the form and loads all student data
            LoadStudentList();
        }

        private void LoadStudentList()
        {
            lvStudentList.Items.Clear();
            DataTable studentDT = ConnectionManager.GetTable(student.FilteredStudentSQL());
            if (studentDT.Rows.Count == 0)
            {
                //Create a response message based upon the state of the student search/filter
                string responseMessage = "No student records to display.\nPlease ";
                if(GlobalVariables.StudentFilterSet())
                {
                    responseMessage += "clear and change the filter.";
                }
                else
                {
                    responseMessage += "add student records.";
                }
                MessageBox.Show(responseMessage);
            }
            else
            {
                //moves through the studentDT (DataTable) and adds the records to the listView
                for (int record = 0; record < studentDT.Rows.Count; record++)
                {
                    ListViewItem listViewItem = new ListViewItem(studentDT.Rows[record]["studentID"].ToString());
                    listViewItem.SubItems.Add(studentDT.Rows[record]["firstName"].ToString());
                    listViewItem.SubItems.Add(studentDT.Rows[record]["lastName"].ToString());
                    listViewItem.SubItems.Add(studentDT.Rows[record]["suburb"].ToString());
                    listViewItem.SubItems.Add(studentDT.Rows[record]["postCode"].ToString());
                    listViewItem.SubItems.Add(studentDT.Rows[record]["email"].ToString());
                    listViewItem.SubItems.Add(studentDT.Rows[record]["contactNo"].ToString());
                    lvStudentList.Items.Add(listViewItem);
                }
            }
        }

        private void BtnCloseForm_Click(object sender, EventArgs e)
        {
            // on closing the form, this clears the Student Global Variables
            GlobalVariables.ClearStudentFilter();
            this.Close();
        }

        private void BtnSearchFilterStudentList_Click(object sender, EventArgs e)
        {
            // This section manages the student search filter process and button state
            //State already set
            if (GlobalVariables.StudentFilterSet())
            {
                ResetFilterAndDisplayForm();
            }
            else
            {
                //State not set
                frmStudentSearchForm searchForm = new frmStudentSearchForm();
                searchForm.ShowDialog();

                if (GlobalVariables.StudentFilterSet())
                {
                    studentSearchFilterButtonState.SearchFilterState("Press to Clear Student Filter");
                    LoadStudentList();
                }
            }
        }

        private void BtnAddStudent_Click(object sender, EventArgs e)
        {
            // This opens the student details form setting it to add new students into the database
            frmStudentDetailsForm subForm = new frmStudentDetailsForm();
            subForm.SetStudentID(0); //passes this as the studentID - if 0 is a new studentID
            subForm.ShowDialog();
            ResetFilterAndDisplayForm();
        }

        private void BtnModifyStudent_Click(object sender, EventArgs e)
        {
            if (lvStudentList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Student Record to Modify their information.");
            }
            else
            {
                // This opens the student details form setting it to modify existing student record to update the table
                frmStudentDetailsForm subForm = new frmStudentDetailsForm();
                subForm.SetStudentID(int.Parse(lvStudentList.SelectedItems[0].Text)); //passes the studentID to the form
                subForm.ShowDialog();
                ResetFilterAndDisplayForm();
            }
        }

        private void ResetFilterAndDisplayForm()
        {
            //When the program returns it resets the student filter and refreshes the form
            GlobalVariables.ClearStudentFilter();
            studentSearchFilterButtonState.ResetFilterState();
            LoadStudentList();
        }

        private void LvStudentList_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // This section of code handles the sorting of listView columns
            // General code structure was taken from links highlighted in ListViewItemSorter.cs and modified to suit
            int testClickColumn = e.Column;

            switch (testClickColumn)
            {
                case 5: //no sort on column 5 or 6
                case 6:
                    return;
                default:
                    //checks performed within ListViewItemSorter class
                    lvItemSorter.checkPreviousOrder(testClickColumn);

                    // Perform the sort with these new sort options.
                    this.lvStudentList.Sort();
                    return;
            }
        }
    }
}
