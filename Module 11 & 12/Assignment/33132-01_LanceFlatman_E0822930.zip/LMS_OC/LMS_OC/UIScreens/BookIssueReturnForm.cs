﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;

namespace LMS_OC.UIScreens
{
    public partial class frmBookIssueReturn : Form
    {
        BookIssueReserveReturn issuedReturn;

        public frmBookIssueReturn(BookIssueReserveReturn issuedBookReturnDetails, string studentName)
        {
            InitializeComponent();
            issuedReturn = issuedBookReturnDetails;
            txtStudentName.Text = studentName;
            txtStudentID.Text = issuedReturn.StudentID.ToString();
            txtExpectedReturnDate.Text = issuedReturn.ReturnDate.ToString("dd/MM/yyyy");
        }

        private void FrmBookIssueReturn_Load(object sender, EventArgs e)
        {
            dtpReturnDate.Value = DateTime.Today;
            DisplayOverdue();
            DisplayFine();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No;
            this.Close();
        }

        private void BtnConfirmReturn_Click(object sender, EventArgs e)
        {
            //issuedReturn.ReturnDate - originally expected stored as BookIssue return - this changes to actual return date
            issuedReturn.ReturnDate = dtpReturnDate.Value;
            issuedReturn.Fine = double.Parse(txtFineAmount.Text);

            this.DialogResult = DialogResult.Yes;
            this.Close();
        }

        private string errorMessage;
        private bool CheckFields()
        {
            errorMessage = "";
            CheckString(txtFineAmount.Text, "Fine Amount");

            if (errorMessage.Length > 0) //field information errors
            {
                MessageBox.Show("This information needs to be corrected:\n" + errorMessage);
                return false;
            }
            return true; //no field information errors
        }

        private bool CheckString(string item, string name)
        {
            //checks the item and uses name in the warning message to user of the issue
            if (item.Length == 0)
            {
                errorMessage += "  " + name + " cannot be blank\n";
                return false;
            }
            return true;
        }

        private void DtpReturnDate_ValueChanged(object sender, EventArgs e)
        {
            if (dtpReturnDate.Value > DateTime.Today)
            {
                MessageBox.Show("A forward date cannot be used. Please try again.", "Incorrect date used"
                   , MessageBoxButtons.OK);
                dtpReturnDate.Value = DateTime.Today;
                txtFineAmount.Text = "";
                dtpReturnDate.Focus();
            }
            else
            {
                DisplayOverdue();
                DisplayFine();
            }
        }

        private void DisplayOverdue()
        {
            txtDaysOverdue.Text = issuedReturn.DaysOverdue(dtpReturnDate.Value).ToString();
        }

        private void DisplayFine()
        {
            //Function that calculates the fine based on the entered date and changes the txtFineAmount state
            txtFineAmount.Text = issuedReturn.CalculateFine(dtpReturnDate.Value).ToString("0.00");
            if (double.Parse(txtFineAmount.Text) == 0.00)
            {
                txtFineAmount.Enabled = false;
                txtFineAmount.ReadOnly = true;
                btnConfirmReturn.Focus();
            }
            else
            {
                txtFineAmount.Enabled = true;
                txtFineAmount.ReadOnly = false;
                txtFineAmount.Focus();
            }
        }

        private void TxtFineAmount_Leave(object sender, EventArgs e)
        {
            if (!CheckString(txtFineAmount.Text, "Fine Amount"))
            {
                MessageBox.Show("Fine amount cannot be blank.", "Entry cannot be blank"
                    , MessageBoxButtons.OK);
            }
            else
            {
                try
                {
                    double tempFine = double.Parse(txtFineAmount.Text);
                    txtFineAmount.Text = tempFine.ToString("0.00");
                    return;
                }
                catch
                {
                    MessageBox.Show("Fine Amount must be a decimal.", "Incorrect Entry Type"
                        , MessageBoxButtons.OK);
                }
            }
            DisplayFine();
        }
    }
}
