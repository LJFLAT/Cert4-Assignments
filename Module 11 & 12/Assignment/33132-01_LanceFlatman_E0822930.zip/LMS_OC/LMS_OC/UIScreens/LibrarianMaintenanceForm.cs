﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmLibrarianMaintenanceForm : Form
    {
        Librarian librarian = new Librarian(); //initialises librarian class object
        SearchFilterButtonState librarianSearchFilterButtonState;  // holds the state of the search / filter button

        private ListViewItemSorter lvItemSorter; //used to sort columns in listView items

        public frmLibrarianMaintenanceForm()
        {
            InitializeComponent();

            // assign items for sorting listView columns
            lvItemSorter = new ListViewItemSorter();
            this.lvLibrarianList.ListViewItemSorter = lvItemSorter;

            // link the Search / Filter button to the button state class
            librarianSearchFilterButtonState = new SearchFilterButtonState(btnSearchFilterLibrarianList);
        }

        private void FrmLibrarianMaintenanceForm_Load(object sender, EventArgs e)
        {
            //Opens the form and loads all librarian data
            LoadLibrarianList();
        }

        private void LoadLibrarianList()
        {
            lvLibrarianList.Items.Clear();
            DataTable librarianDT = ConnectionManager.GetTable(librarian.FilteredLibrarianSQL());
            if (librarianDT.Rows.Count == 0)
            {
                //Create a response message based upon the state of the librarian search/filter
                string responseMessage = "No librarian records to display.\nPlease ";
                if (GlobalVariables.LibrarianFilterSet())
                {
                    responseMessage += "clear and change the filter.";
                }
                else
                {
                    responseMessage += "add librarian records.";
                }
                MessageBox.Show(responseMessage);
            }
            else
            {
                //moves through the librarianDT (DataTable) and adds the records to the listView
                for (int record = 0; record < librarianDT.Rows.Count; record++)
                {
                    ListViewItem listViewItem = new ListViewItem(librarianDT.Rows[record]["librarianID"].ToString());
                    listViewItem.SubItems.Add(librarianDT.Rows[record]["firstName"].ToString());
                    listViewItem.SubItems.Add(librarianDT.Rows[record]["lastName"].ToString());
                    lvLibrarianList.Items.Add(listViewItem);
                }
            }
        }

        private void BtnCloseForm_Click(object sender, EventArgs e)
        {
            // on closing the form, this clears the Librarian Global Variables
            GlobalVariables.ClearLibrarianFilter();
            this.Close();
        }

        private void BtnSearchFilterLibrarianList_Click(object sender, EventArgs e)
        {            
            //This section manages the librarian search filter process and button state
            //State already set
            if (GlobalVariables.LibrarianFilterSet())
            {
                ResetFilterAndDisplayForm();
            }
            else
            {
                //State not set
                frmLibrarianSearchForm searchForm = new frmLibrarianSearchForm();
                searchForm.ShowDialog();

                if (GlobalVariables.LibrarianFilterSet())
                {
                    librarianSearchFilterButtonState.SearchFilterState("Press to Clear Librarian Filter");
                    LoadLibrarianList();
                }
            }
        }

        private void BtnAddLibrarian_Click(object sender, EventArgs e)
        {
            frmLibrarianDetailsForm subForm = new frmLibrarianDetailsForm();
            subForm.SetLibrarianID(0); //Passes this as librarianID - if 0 then new librarian record
            subForm.ShowDialog();
            ResetFilterAndDisplayForm();
        }

        private void BtnModifyLibrarian_Click(object sender, EventArgs e)
        {
            if (lvLibrarianList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Librarian Record to Modify their information.");
            }
            else
            {
                if (System.Environment.GetEnvironmentVariable("librarianID") != lvLibrarianList.SelectedItems[0].Text)
                {
                    MessageBox.Show("You are not authorised to access this information.");
                    return;
                }

                // This opens the librarian details form setting it to modify existing librarian record to update the table
                frmLibrarianDetailsForm subForm = new frmLibrarianDetailsForm ();
                subForm.SetLibrarianID(int.Parse(lvLibrarianList.SelectedItems[0].Text)); //passes the librarianID to the form
                subForm.ShowDialog();
                ResetFilterAndDisplayForm();
            }
        }

        private void ResetFilterAndDisplayForm()
        {
            //When the program returns it resets the librarian filter and refreshes the form
            GlobalVariables.ClearLibrarianFilter();
            librarianSearchFilterButtonState.ResetFilterState();
            LoadLibrarianList();
        }

        private void LvLibrarianList_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // This section of code handles the sorting of listView columns
            // General code structure was taken from links highlighted in ListViewItemSorter.cs and modified to suit
            int testClickColumn = e.Column;

            //checks performed within ListViewItemSorter class
            lvItemSorter.checkPreviousOrder(testClickColumn);

            // Perform the sort with these new sort options.
            this.lvLibrarianList.Sort();
            return;
        }
    }
}
