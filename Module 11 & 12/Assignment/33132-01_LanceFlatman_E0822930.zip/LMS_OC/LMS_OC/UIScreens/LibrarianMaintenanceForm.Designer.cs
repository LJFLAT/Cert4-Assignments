﻿namespace LMS_OC.UIScreens
{
    partial class frmLibrarianMaintenanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvLibrarianList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSearchFilterLibrarianList = new System.Windows.Forms.Button();
            this.btnModifyLibrarian = new System.Windows.Forms.Button();
            this.btnAddLibrarian = new System.Windows.Forms.Button();
            this.btnCloseForm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvLibrarianList
            // 
            this.lvLibrarianList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvLibrarianList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lvLibrarianList.FullRowSelect = true;
            this.lvLibrarianList.GridLines = true;
            this.lvLibrarianList.HideSelection = false;
            this.lvLibrarianList.Location = new System.Drawing.Point(13, 10);
            this.lvLibrarianList.MultiSelect = false;
            this.lvLibrarianList.Name = "lvLibrarianList";
            this.lvLibrarianList.Size = new System.Drawing.Size(1169, 573);
            this.lvLibrarianList.TabIndex = 0;
            this.lvLibrarianList.UseCompatibleStateImageBehavior = false;
            this.lvLibrarianList.View = System.Windows.Forms.View.Details;
            this.lvLibrarianList.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.LvLibrarianList_ColumnClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Librarian ID";
            this.columnHeader1.Width = 70;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "First Name";
            this.columnHeader2.Width = 150;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Last Name";
            this.columnHeader3.Width = 150;
            // 
            // btnSearchFilterLibrarianList
            // 
            this.btnSearchFilterLibrarianList.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSearchFilterLibrarianList.Location = new System.Drawing.Point(606, 589);
            this.btnSearchFilterLibrarianList.Name = "btnSearchFilterLibrarianList";
            this.btnSearchFilterLibrarianList.Size = new System.Drawing.Size(90, 38);
            this.btnSearchFilterLibrarianList.TabIndex = 3;
            this.btnSearchFilterLibrarianList.Text = "Search / Filter Librarian List";
            this.btnSearchFilterLibrarianList.UseVisualStyleBackColor = true;
            this.btnSearchFilterLibrarianList.Click += new System.EventHandler(this.BtnSearchFilterLibrarianList_Click);
            // 
            // btnModifyLibrarian
            // 
            this.btnModifyLibrarian.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnModifyLibrarian.Location = new System.Drawing.Point(120, 589);
            this.btnModifyLibrarian.Name = "btnModifyLibrarian";
            this.btnModifyLibrarian.Size = new System.Drawing.Size(90, 38);
            this.btnModifyLibrarian.TabIndex = 2;
            this.btnModifyLibrarian.Text = "Modify Librarian Details";
            this.btnModifyLibrarian.UseVisualStyleBackColor = true;
            this.btnModifyLibrarian.Click += new System.EventHandler(this.BtnModifyLibrarian_Click);
            // 
            // btnAddLibrarian
            // 
            this.btnAddLibrarian.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAddLibrarian.Location = new System.Drawing.Point(13, 589);
            this.btnAddLibrarian.Name = "btnAddLibrarian";
            this.btnAddLibrarian.Size = new System.Drawing.Size(90, 38);
            this.btnAddLibrarian.TabIndex = 1;
            this.btnAddLibrarian.Text = "Add Librarian Details";
            this.btnAddLibrarian.UseVisualStyleBackColor = true;
            this.btnAddLibrarian.Click += new System.EventHandler(this.BtnAddLibrarian_Click);
            // 
            // btnCloseForm
            // 
            this.btnCloseForm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloseForm.Location = new System.Drawing.Point(1091, 589);
            this.btnCloseForm.Name = "btnCloseForm";
            this.btnCloseForm.Size = new System.Drawing.Size(90, 38);
            this.btnCloseForm.TabIndex = 4;
            this.btnCloseForm.Text = "Close Librarian Maintenance";
            this.btnCloseForm.UseVisualStyleBackColor = true;
            this.btnCloseForm.Click += new System.EventHandler(this.BtnCloseForm_Click);
            // 
            // frmLibrarianMaintenanceForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1194, 634);
            this.ControlBox = false;
            this.Controls.Add(this.lvLibrarianList);
            this.Controls.Add(this.btnSearchFilterLibrarianList);
            this.Controls.Add(this.btnModifyLibrarian);
            this.Controls.Add(this.btnAddLibrarian);
            this.Controls.Add(this.btnCloseForm);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1210, 650);
            this.Name = "frmLibrarianMaintenanceForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Librarian Maintenance Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmLibrarianMaintenanceForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvLibrarianList;
        private System.Windows.Forms.Button btnSearchFilterLibrarianList;
        private System.Windows.Forms.Button btnModifyLibrarian;
        private System.Windows.Forms.Button btnAddLibrarian;
        private System.Windows.Forms.Button btnCloseForm;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
    }
}