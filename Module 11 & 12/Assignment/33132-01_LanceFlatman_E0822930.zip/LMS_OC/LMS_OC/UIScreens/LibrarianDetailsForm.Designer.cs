﻿namespace LMS_OC.UIScreens
{
    partial class frmLibrarianDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLibrarianDetailsForm));
            this.btnAddModifyRecord = new System.Windows.Forms.Button();
            this.btnCancelReturn = new System.Windows.Forms.Button();
            this.gbContactDetails = new System.Windows.Forms.GroupBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtContactNo = new System.Windows.Forms.TextBox();
            this.lblContactNo = new System.Windows.Forms.Label();
            this.gbOfficeUse = new System.Windows.Forms.GroupBox();
            this.txtLibrarianID = new System.Windows.Forms.TextBox();
            this.lblLibrarianID = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.lblUserName = new System.Windows.Forms.Label();
            this.gbLibrarianAddress = new System.Windows.Forms.GroupBox();
            this.cbState = new System.Windows.Forms.ComboBox();
            this.lblState = new System.Windows.Forms.Label();
            this.txtPostCode = new System.Windows.Forms.TextBox();
            this.lblPostCode = new System.Windows.Forms.Label();
            this.txtSuburb = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblSuburb = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.gbLibrarianName = new System.Windows.Forms.GroupBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.btnShowHiddenDetails = new System.Windows.Forms.Button();
            this.gbContactDetails.SuspendLayout();
            this.gbOfficeUse.SuspendLayout();
            this.gbLibrarianAddress.SuspendLayout();
            this.gbLibrarianName.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAddModifyRecord
            // 
            resources.ApplyResources(this.btnAddModifyRecord, "btnAddModifyRecord");
            this.btnAddModifyRecord.Name = "btnAddModifyRecord";
            this.btnAddModifyRecord.UseVisualStyleBackColor = true;
            this.btnAddModifyRecord.Click += new System.EventHandler(this.BtnAddModifyRecord_Click);
            // 
            // btnCancelReturn
            // 
            resources.ApplyResources(this.btnCancelReturn, "btnCancelReturn");
            this.btnCancelReturn.Name = "btnCancelReturn";
            this.btnCancelReturn.UseVisualStyleBackColor = true;
            this.btnCancelReturn.Click += new System.EventHandler(this.BtnCancelReturn_Click);
            // 
            // gbContactDetails
            // 
            this.gbContactDetails.Controls.Add(this.txtEmail);
            this.gbContactDetails.Controls.Add(this.lblEmail);
            this.gbContactDetails.Controls.Add(this.txtContactNo);
            this.gbContactDetails.Controls.Add(this.lblContactNo);
            resources.ApplyResources(this.gbContactDetails, "gbContactDetails");
            this.gbContactDetails.Name = "gbContactDetails";
            this.gbContactDetails.TabStop = false;
            // 
            // txtEmail
            // 
            resources.ApplyResources(this.txtEmail, "txtEmail");
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.UseSystemPasswordChar = true;
            // 
            // lblEmail
            // 
            resources.ApplyResources(this.lblEmail, "lblEmail");
            this.lblEmail.Name = "lblEmail";
            // 
            // txtContactNo
            // 
            resources.ApplyResources(this.txtContactNo, "txtContactNo");
            this.txtContactNo.Name = "txtContactNo";
            this.txtContactNo.UseSystemPasswordChar = true;
            this.txtContactNo.Leave += new System.EventHandler(this.TxtContactNo_Leave);
            // 
            // lblContactNo
            // 
            resources.ApplyResources(this.lblContactNo, "lblContactNo");
            this.lblContactNo.Name = "lblContactNo";
            // 
            // gbOfficeUse
            // 
            this.gbOfficeUse.Controls.Add(this.txtLibrarianID);
            this.gbOfficeUse.Controls.Add(this.lblLibrarianID);
            this.gbOfficeUse.Controls.Add(this.txtPassword);
            this.gbOfficeUse.Controls.Add(this.lblPassword);
            this.gbOfficeUse.Controls.Add(this.txtUserName);
            this.gbOfficeUse.Controls.Add(this.lblUserName);
            resources.ApplyResources(this.gbOfficeUse, "gbOfficeUse");
            this.gbOfficeUse.Name = "gbOfficeUse";
            this.gbOfficeUse.TabStop = false;
            // 
            // txtLibrarianID
            // 
            resources.ApplyResources(this.txtLibrarianID, "txtLibrarianID");
            this.txtLibrarianID.Name = "txtLibrarianID";
            this.txtLibrarianID.ReadOnly = true;
            // 
            // lblLibrarianID
            // 
            resources.ApplyResources(this.lblLibrarianID, "lblLibrarianID");
            this.lblLibrarianID.Name = "lblLibrarianID";
            // 
            // txtPassword
            // 
            resources.ApplyResources(this.txtPassword, "txtPassword");
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.Enter += new System.EventHandler(this.TxtPassword_Enter);
            // 
            // lblPassword
            // 
            resources.ApplyResources(this.lblPassword, "lblPassword");
            this.lblPassword.Name = "lblPassword";
            // 
            // txtUserName
            // 
            resources.ApplyResources(this.txtUserName, "txtUserName");
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.UseSystemPasswordChar = true;
            this.txtUserName.Leave += new System.EventHandler(this.TxtUserName_Leave);
            // 
            // lblUserName
            // 
            resources.ApplyResources(this.lblUserName, "lblUserName");
            this.lblUserName.Name = "lblUserName";
            // 
            // gbLibrarianAddress
            // 
            this.gbLibrarianAddress.Controls.Add(this.cbState);
            this.gbLibrarianAddress.Controls.Add(this.lblState);
            this.gbLibrarianAddress.Controls.Add(this.txtPostCode);
            this.gbLibrarianAddress.Controls.Add(this.lblPostCode);
            this.gbLibrarianAddress.Controls.Add(this.txtSuburb);
            this.gbLibrarianAddress.Controls.Add(this.txtAddress);
            this.gbLibrarianAddress.Controls.Add(this.lblSuburb);
            this.gbLibrarianAddress.Controls.Add(this.lblAddress);
            resources.ApplyResources(this.gbLibrarianAddress, "gbLibrarianAddress");
            this.gbLibrarianAddress.Name = "gbLibrarianAddress";
            this.gbLibrarianAddress.TabStop = false;
            // 
            // cbState
            // 
            this.cbState.AllowDrop = true;
            this.cbState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbState.FormattingEnabled = true;
            this.cbState.Items.AddRange(new object[] {
            resources.GetString("cbState.Items"),
            resources.GetString("cbState.Items1"),
            resources.GetString("cbState.Items2"),
            resources.GetString("cbState.Items3"),
            resources.GetString("cbState.Items4"),
            resources.GetString("cbState.Items5"),
            resources.GetString("cbState.Items6"),
            resources.GetString("cbState.Items7")});
            resources.ApplyResources(this.cbState, "cbState");
            this.cbState.Name = "cbState";
            // 
            // lblState
            // 
            resources.ApplyResources(this.lblState, "lblState");
            this.lblState.Name = "lblState";
            // 
            // txtPostCode
            // 
            resources.ApplyResources(this.txtPostCode, "txtPostCode");
            this.txtPostCode.Name = "txtPostCode";
            this.txtPostCode.UseSystemPasswordChar = true;
            // 
            // lblPostCode
            // 
            resources.ApplyResources(this.lblPostCode, "lblPostCode");
            this.lblPostCode.Name = "lblPostCode";
            // 
            // txtSuburb
            // 
            resources.ApplyResources(this.txtSuburb, "txtSuburb");
            this.txtSuburb.Name = "txtSuburb";
            this.txtSuburb.UseSystemPasswordChar = true;
            // 
            // txtAddress
            // 
            resources.ApplyResources(this.txtAddress, "txtAddress");
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.UseSystemPasswordChar = true;
            // 
            // lblSuburb
            // 
            resources.ApplyResources(this.lblSuburb, "lblSuburb");
            this.lblSuburb.Name = "lblSuburb";
            // 
            // lblAddress
            // 
            resources.ApplyResources(this.lblAddress, "lblAddress");
            this.lblAddress.Name = "lblAddress";
            // 
            // gbLibrarianName
            // 
            this.gbLibrarianName.Controls.Add(this.txtFirstName);
            this.gbLibrarianName.Controls.Add(this.lblFirstName);
            this.gbLibrarianName.Controls.Add(this.lblLastName);
            this.gbLibrarianName.Controls.Add(this.txtLastName);
            resources.ApplyResources(this.gbLibrarianName, "gbLibrarianName");
            this.gbLibrarianName.Name = "gbLibrarianName";
            this.gbLibrarianName.TabStop = false;
            // 
            // txtFirstName
            // 
            resources.ApplyResources(this.txtFirstName, "txtFirstName");
            this.txtFirstName.Name = "txtFirstName";
            // 
            // lblFirstName
            // 
            resources.ApplyResources(this.lblFirstName, "lblFirstName");
            this.lblFirstName.Name = "lblFirstName";
            // 
            // lblLastName
            // 
            resources.ApplyResources(this.lblLastName, "lblLastName");
            this.lblLastName.Name = "lblLastName";
            // 
            // txtLastName
            // 
            resources.ApplyResources(this.txtLastName, "txtLastName");
            this.txtLastName.Name = "txtLastName";
            // 
            // btnShowHiddenDetails
            // 
            resources.ApplyResources(this.btnShowHiddenDetails, "btnShowHiddenDetails");
            this.btnShowHiddenDetails.Name = "btnShowHiddenDetails";
            this.btnShowHiddenDetails.UseVisualStyleBackColor = true;
            this.btnShowHiddenDetails.MouseDown += new System.Windows.Forms.MouseEventHandler(this.BtnShowHiddenDetails_MouseDown);
            this.btnShowHiddenDetails.MouseUp += new System.Windows.Forms.MouseEventHandler(this.BtnShowHiddenDetails_MouseUp);
            // 
            // frmLibrarianDetailsForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ControlBox = false;
            this.Controls.Add(this.btnShowHiddenDetails);
            this.Controls.Add(this.btnAddModifyRecord);
            this.Controls.Add(this.btnCancelReturn);
            this.Controls.Add(this.gbContactDetails);
            this.Controls.Add(this.gbOfficeUse);
            this.Controls.Add(this.gbLibrarianAddress);
            this.Controls.Add(this.gbLibrarianName);
            this.Name = "frmLibrarianDetailsForm";
            this.Load += new System.EventHandler(this.FrmLibrarianDetailsForm_Load);
            this.gbContactDetails.ResumeLayout(false);
            this.gbContactDetails.PerformLayout();
            this.gbOfficeUse.ResumeLayout(false);
            this.gbOfficeUse.PerformLayout();
            this.gbLibrarianAddress.ResumeLayout(false);
            this.gbLibrarianAddress.PerformLayout();
            this.gbLibrarianName.ResumeLayout(false);
            this.gbLibrarianName.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAddModifyRecord;
        private System.Windows.Forms.Button btnCancelReturn;
        private System.Windows.Forms.GroupBox gbContactDetails;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtContactNo;
        private System.Windows.Forms.Label lblContactNo;
        private System.Windows.Forms.GroupBox gbOfficeUse;
        private System.Windows.Forms.TextBox txtLibrarianID;
        private System.Windows.Forms.Label lblLibrarianID;
        private System.Windows.Forms.GroupBox gbLibrarianAddress;
        private System.Windows.Forms.ComboBox cbState;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.TextBox txtPostCode;
        private System.Windows.Forms.Label lblPostCode;
        private System.Windows.Forms.TextBox txtSuburb;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblSuburb;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.GroupBox gbLibrarianName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Button btnShowHiddenDetails;
    }
}