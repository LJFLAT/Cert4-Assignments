﻿namespace LMS_OC.UIScreens
{
    partial class frmMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.newStudentEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.librarianMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.librarianMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.booksOnIssueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.authorMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logUserOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newStudentEntryToolStripMenuItem,
            this.librarianMasterToolStripMenuItem,
            this.bookMasterToolStripMenuItem,
            this.logUserOutToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(9, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1264, 27);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // newStudentEntryToolStripMenuItem
            // 
            this.newStudentEntryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentMaintenanceToolStripMenuItem});
            this.newStudentEntryToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.newStudentEntryToolStripMenuItem.Name = "newStudentEntryToolStripMenuItem";
            this.newStudentEntryToolStripMenuItem.Size = new System.Drawing.Size(116, 23);
            this.newStudentEntryToolStripMenuItem.Text = "Student Master";
            // 
            // studentMaintenanceToolStripMenuItem
            // 
            this.studentMaintenanceToolStripMenuItem.Name = "studentMaintenanceToolStripMenuItem";
            this.studentMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(209, 24);
            this.studentMaintenanceToolStripMenuItem.Text = "Student Maintenance";
            this.studentMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.StudentMaintenanceToolStripMenuItem_Click);
            // 
            // librarianMasterToolStripMenuItem
            // 
            this.librarianMasterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.librarianMaintenanceToolStripMenuItem});
            this.librarianMasterToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.librarianMasterToolStripMenuItem.Name = "librarianMasterToolStripMenuItem";
            this.librarianMasterToolStripMenuItem.Size = new System.Drawing.Size(121, 23);
            this.librarianMasterToolStripMenuItem.Text = "Librarian Master";
            // 
            // librarianMaintenanceToolStripMenuItem
            // 
            this.librarianMaintenanceToolStripMenuItem.Name = "librarianMaintenanceToolStripMenuItem";
            this.librarianMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(214, 24);
            this.librarianMaintenanceToolStripMenuItem.Text = "Librarian Maintenance";
            this.librarianMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.LibrarianMaintenanceToolStripMenuItem_Click);
            // 
            // bookMasterToolStripMenuItem
            // 
            this.bookMasterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bookMaintenanceToolStripMenuItem,
            this.authorMaintenanceToolStripMenuItem,
            this.toolStripSeparator1,
            this.booksOnIssueToolStripMenuItem});
            this.bookMasterToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.bookMasterToolStripMenuItem.Name = "bookMasterToolStripMenuItem";
            this.bookMasterToolStripMenuItem.Size = new System.Drawing.Size(99, 23);
            this.bookMasterToolStripMenuItem.Text = "Book Master";
            // 
            // bookMaintenanceToolStripMenuItem
            // 
            this.bookMaintenanceToolStripMenuItem.Name = "bookMaintenanceToolStripMenuItem";
            this.bookMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(204, 24);
            this.bookMaintenanceToolStripMenuItem.Text = "Book Maintenance";
            this.bookMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.BookMaintenanceToolStripMenuItem_Click);
            // 
            // booksOnIssueToolStripMenuItem
            // 
            this.booksOnIssueToolStripMenuItem.Name = "booksOnIssueToolStripMenuItem";
            this.booksOnIssueToolStripMenuItem.Size = new System.Drawing.Size(204, 24);
            this.booksOnIssueToolStripMenuItem.Text = "Books on Issue";
            this.booksOnIssueToolStripMenuItem.Click += new System.EventHandler(this.BooksOnIssueToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(201, 6);
            // 
            // authorMaintenanceToolStripMenuItem
            // 
            this.authorMaintenanceToolStripMenuItem.Name = "authorMaintenanceToolStripMenuItem";
            this.authorMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(204, 24);
            this.authorMaintenanceToolStripMenuItem.Text = "Author Maintenance";
            this.authorMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.AuthorMaintenanceToolStripMenuItem_Click);
            // 
            // logUserOutToolStripMenuItem
            // 
            this.logUserOutToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.logUserOutToolStripMenuItem.Name = "logUserOutToolStripMenuItem";
            this.logUserOutToolStripMenuItem.Size = new System.Drawing.Size(104, 23);
            this.logUserOutToolStripMenuItem.Text = "Log User Out";
            this.logUserOutToolStripMenuItem.Click += new System.EventHandler(this.LogUserOutToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 712);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(1, 0, 21, 0);
            this.statusStrip.Size = new System.Drawing.Size(1264, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // frmMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 734);
            this.ControlBox = false;
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1280, 750);
            this.Name = "frmMainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Library Management System";
            this.TransparencyKey = System.Drawing.SystemColors.Control;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem newStudentEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem librarianMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem librarianMaintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentMaintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookMaintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem booksOnIssueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem authorMaintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem logUserOutToolStripMenuItem;
    }
}



