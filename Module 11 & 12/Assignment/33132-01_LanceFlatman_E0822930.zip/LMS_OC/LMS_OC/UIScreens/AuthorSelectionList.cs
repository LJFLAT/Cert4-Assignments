﻿using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmAuthorSelectionList : Form
    {
        Author author = new Author();
        int SEARCH_AUTHOR_LENGTH = 2;

        public frmAuthorSelectionList()
        {
            InitializeComponent();
        }

        private void FrmAuthorSelectionList_Load(object sender, EventArgs e)
        {
            //Opens the form and loads all authors into the listView object
            LoadAuthorList();
        }

        private void LoadAuthorList()
        {
            string selectQuery = "SELECT * FROM Author";
            if (txtSearchAuthor.TextLength > SEARCH_AUTHOR_LENGTH)
            {
                selectQuery += " WHERE authorName LIKE ('%" + txtSearchAuthor.Text.Trim() + "%')";
            }
            selectQuery += " ORDER BY authorName";

            lvAuthorList.Items.Clear();
            DataTable authorDT = ConnectionManager.GetTable(selectQuery);
            if (authorDT.Rows.Count == 0)
            {
                //Create a response message based upon the state of the author 
                string responseMessage = "No author records to display.\nPlease ";
                if (txtSearchAuthor.TextLength > 3)
                {
                    responseMessage += "use a different author name filter.";
                }
                else
                {
                    responseMessage += "add author records.";
                }
                MessageBox.Show(responseMessage);
                txtSearchAuthor.Text = "";
                LoadAuthorList();
                txtSearchAuthor.Focus();
            }
            else
            {
                //moves through the authorDT (DataTable) and adds the records to the listView
                for (int record = 0; record < authorDT.Rows.Count; record++)
                {
                    ListViewItem listViewItem = new ListViewItem(authorDT.Rows[record]["authorID"].ToString());
                    listViewItem.SubItems.Add(authorDT.Rows[record]["authorName"].ToString());
                    lvAuthorList.Items.Add(listViewItem);
                }
            }
        }

        private void BtnSelectAuthor_Click(object sender, EventArgs e)
        {
            if (lvAuthorList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select an Author to continue.");
                txtSearchAuthor.Focus();
            }
            else
            {
                newAuthorID = int.Parse(lvAuthorList.SelectedItems[0].Text);
                CloseForm();
            }
        }

        public int newAuthorID = 0;
        private void BtnAddAuthor_Click(object sender, EventArgs e)
        {
            //Load AuthorDetails form with Add option
            //get back an authorID to use with the BookDetails form
            frmAuthorDetailsForm subForm = new frmAuthorDetailsForm();
            subForm.SetAuthorID(0);
            DialogResult result = subForm.ShowDialog();

            if (result == DialogResult.Yes)
            {
                newAuthorID = subForm.returnValue;
                CloseForm();
            }
            else
            {
                txtSearchAuthor.Text = "";
                txtSearchAuthor.Focus();
            }
        }

        private void TxtSearchAuthor_TextChanged(object sender, EventArgs e)
        {
            LoadAuthorList();
            txtSearchAuthor.Focus();
        }

        public int returnValue;
        private void CloseForm()
        {
            GlobalVariables.AuthorName = "";
            this.returnValue = newAuthorID;
            if (newAuthorID > 0)
            {
                this.DialogResult = DialogResult.Yes;
            }
            else
            {
                this.DialogResult = DialogResult.No;
            }
            this.Close();
        }
    }
}
