﻿namespace LMS_OC.UIScreens
{
    partial class frmAuthorMaintenanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvAuthorList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSearchFilterAuthorList = new System.Windows.Forms.Button();
            this.btnModifyAuthor = new System.Windows.Forms.Button();
            this.btnAddAuthor = new System.Windows.Forms.Button();
            this.btnCloseForm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvAuthorList
            // 
            this.lvAuthorList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvAuthorList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lvAuthorList.FullRowSelect = true;
            this.lvAuthorList.GridLines = true;
            this.lvAuthorList.HideSelection = false;
            this.lvAuthorList.Location = new System.Drawing.Point(13, 10);
            this.lvAuthorList.MultiSelect = false;
            this.lvAuthorList.Name = "lvAuthorList";
            this.lvAuthorList.Size = new System.Drawing.Size(1169, 573);
            this.lvAuthorList.TabIndex = 0;
            this.lvAuthorList.UseCompatibleStateImageBehavior = false;
            this.lvAuthorList.View = System.Windows.Forms.View.Details;
            this.lvAuthorList.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.LvAuthorList_ColumnClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Author ID";
            this.columnHeader1.Width = 70;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Author Name";
            this.columnHeader2.Width = 180;
            // 
            // btnSearchFilterAuthorList
            // 
            this.btnSearchFilterAuthorList.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSearchFilterAuthorList.Location = new System.Drawing.Point(606, 589);
            this.btnSearchFilterAuthorList.Name = "btnSearchFilterAuthorList";
            this.btnSearchFilterAuthorList.Size = new System.Drawing.Size(90, 38);
            this.btnSearchFilterAuthorList.TabIndex = 3;
            this.btnSearchFilterAuthorList.Text = "Search / Filter Author List";
            this.btnSearchFilterAuthorList.UseVisualStyleBackColor = true;
            this.btnSearchFilterAuthorList.Click += new System.EventHandler(this.BtnSearchFilterAuthorList_Click);
            // 
            // btnModifyAuthor
            // 
            this.btnModifyAuthor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnModifyAuthor.Location = new System.Drawing.Point(120, 589);
            this.btnModifyAuthor.Name = "btnModifyAuthor";
            this.btnModifyAuthor.Size = new System.Drawing.Size(90, 38);
            this.btnModifyAuthor.TabIndex = 2;
            this.btnModifyAuthor.Text = "Modify Author Details";
            this.btnModifyAuthor.UseVisualStyleBackColor = true;
            this.btnModifyAuthor.Click += new System.EventHandler(this.BtnModifyAuthor_Click);
            // 
            // btnAddAuthor
            // 
            this.btnAddAuthor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAddAuthor.Location = new System.Drawing.Point(13, 589);
            this.btnAddAuthor.Name = "btnAddAuthor";
            this.btnAddAuthor.Size = new System.Drawing.Size(90, 38);
            this.btnAddAuthor.TabIndex = 1;
            this.btnAddAuthor.Text = "Add Author Details";
            this.btnAddAuthor.UseVisualStyleBackColor = true;
            this.btnAddAuthor.Click += new System.EventHandler(this.BtnAddAuthor_Click);
            // 
            // btnCloseForm
            // 
            this.btnCloseForm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloseForm.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCloseForm.Location = new System.Drawing.Point(1092, 589);
            this.btnCloseForm.Name = "btnCloseForm";
            this.btnCloseForm.Size = new System.Drawing.Size(90, 38);
            this.btnCloseForm.TabIndex = 4;
            this.btnCloseForm.Text = "Close Author Maintenance";
            this.btnCloseForm.UseVisualStyleBackColor = true;
            this.btnCloseForm.Click += new System.EventHandler(this.BtnCloseForm_Click);
            // 
            // frmAuthorMaintenanceForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1194, 634);
            this.ControlBox = false;
            this.Controls.Add(this.lvAuthorList);
            this.Controls.Add(this.btnSearchFilterAuthorList);
            this.Controls.Add(this.btnModifyAuthor);
            this.Controls.Add(this.btnAddAuthor);
            this.Controls.Add(this.btnCloseForm);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1210, 650);
            this.Name = "frmAuthorMaintenanceForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Author Maintenance Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmAuthorMaintenanceForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvAuthorList;
        private System.Windows.Forms.Button btnSearchFilterAuthorList;
        private System.Windows.Forms.Button btnModifyAuthor;
        private System.Windows.Forms.Button btnAddAuthor;
        private System.Windows.Forms.Button btnCloseForm;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
    }
}