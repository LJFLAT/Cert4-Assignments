﻿namespace LMS_OC.UIScreens
{
    partial class frmBookDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbBookDetails = new System.Windows.Forms.GroupBox();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.gbOfficeUse = new System.Windows.Forms.GroupBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtLibrarian = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblLibrarian = new System.Windows.Forms.Label();
            this.lblBookID = new System.Windows.Forms.Label();
            this.txtBookID = new System.Windows.Forms.TextBox();
            this.gbBookLocation = new System.Windows.Forms.GroupBox();
            this.mtbRackNo = new System.Windows.Forms.MaskedTextBox();
            this.lblReserved = new System.Windows.Forms.Label();
            this.txtReservedBooks = new System.Windows.Forms.TextBox();
            this.lblBorrowed = new System.Windows.Forms.Label();
            this.txtBorrowedBooks = new System.Windows.Forms.TextBox();
            this.lblAvailable = new System.Windows.Forms.Label();
            this.txtAvailableBooks = new System.Windows.Forms.TextBox();
            this.lblRackNo = new System.Windows.Forms.Label();
            this.lblISBN = new System.Windows.Forms.Label();
            this.txtISBN = new System.Windows.Forms.TextBox();
            this.btnCloseForm = new System.Windows.Forms.Button();
            this.btnAddModifyBookDetails = new System.Windows.Forms.Button();
            this.gbBookDetails.SuspendLayout();
            this.gbOfficeUse.SuspendLayout();
            this.gbBookLocation.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbBookDetails
            // 
            this.gbBookDetails.Controls.Add(this.txtAuthor);
            this.gbBookDetails.Controls.Add(this.lblAuthor);
            this.gbBookDetails.Controls.Add(this.txtTitle);
            this.gbBookDetails.Controls.Add(this.lblTitle);
            this.gbBookDetails.Location = new System.Drawing.Point(12, 12);
            this.gbBookDetails.Name = "gbBookDetails";
            this.gbBookDetails.Size = new System.Drawing.Size(460, 79);
            this.gbBookDetails.TabIndex = 0;
            this.gbBookDetails.TabStop = false;
            this.gbBookDetails.Text = "Book Details";
            // 
            // txtAuthor
            // 
            this.txtAuthor.Location = new System.Drawing.Point(54, 43);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.ReadOnly = true;
            this.txtAuthor.Size = new System.Drawing.Size(395, 20);
            this.txtAuthor.TabIndex = 1;
            this.txtAuthor.Enter += new System.EventHandler(this.TxtAuthor_Enter);
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Location = new System.Drawing.Point(7, 46);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(41, 13);
            this.lblAuthor.TabIndex = 2;
            this.lblAuthor.Text = "Author:";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(54, 17);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(395, 20);
            this.txtTitle.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(7, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(30, 13);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Title:";
            // 
            // gbOfficeUse
            // 
            this.gbOfficeUse.Controls.Add(this.txtPrice);
            this.gbOfficeUse.Controls.Add(this.txtLibrarian);
            this.gbOfficeUse.Controls.Add(this.lblPrice);
            this.gbOfficeUse.Controls.Add(this.lblLibrarian);
            this.gbOfficeUse.Controls.Add(this.lblBookID);
            this.gbOfficeUse.Controls.Add(this.txtBookID);
            this.gbOfficeUse.Location = new System.Drawing.Point(233, 97);
            this.gbOfficeUse.Name = "gbOfficeUse";
            this.gbOfficeUse.Size = new System.Drawing.Size(239, 105);
            this.gbOfficeUse.TabIndex = 2;
            this.gbOfficeUse.TabStop = false;
            this.gbOfficeUse.Text = "Office Use";
            // 
            // txtPrice
            // 
            this.txtPrice.Enabled = false;
            this.txtPrice.Location = new System.Drawing.Point(74, 45);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.ReadOnly = true;
            this.txtPrice.Size = new System.Drawing.Size(84, 20);
            this.txtPrice.TabIndex = 1;
            this.txtPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPrice.Leave += new System.EventHandler(this.TxtPrice_Leave);
            // 
            // txtLibrarian
            // 
            this.txtLibrarian.Enabled = false;
            this.txtLibrarian.Location = new System.Drawing.Point(74, 71);
            this.txtLibrarian.Name = "txtLibrarian";
            this.txtLibrarian.ReadOnly = true;
            this.txtLibrarian.Size = new System.Drawing.Size(154, 20);
            this.txtLibrarian.TabIndex = 2;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(15, 48);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(49, 13);
            this.lblPrice.TabIndex = 2;
            this.lblPrice.Text = "Price :  $";
            // 
            // lblLibrarian
            // 
            this.lblLibrarian.AutoSize = true;
            this.lblLibrarian.Location = new System.Drawing.Point(15, 74);
            this.lblLibrarian.Name = "lblLibrarian";
            this.lblLibrarian.Size = new System.Drawing.Size(53, 13);
            this.lblLibrarian.TabIndex = 2;
            this.lblLibrarian.Text = "Librarian :";
            // 
            // lblBookID
            // 
            this.lblBookID.AutoSize = true;
            this.lblBookID.Location = new System.Drawing.Point(15, 20);
            this.lblBookID.Name = "lblBookID";
            this.lblBookID.Size = new System.Drawing.Size(49, 13);
            this.lblBookID.TabIndex = 1;
            this.lblBookID.Text = "Book ID:";
            // 
            // txtBookID
            // 
            this.txtBookID.Enabled = false;
            this.txtBookID.Location = new System.Drawing.Point(74, 17);
            this.txtBookID.Name = "txtBookID";
            this.txtBookID.ReadOnly = true;
            this.txtBookID.Size = new System.Drawing.Size(84, 20);
            this.txtBookID.TabIndex = 0;
            // 
            // gbBookLocation
            // 
            this.gbBookLocation.Controls.Add(this.mtbRackNo);
            this.gbBookLocation.Controls.Add(this.lblReserved);
            this.gbBookLocation.Controls.Add(this.txtReservedBooks);
            this.gbBookLocation.Controls.Add(this.lblBorrowed);
            this.gbBookLocation.Controls.Add(this.txtBorrowedBooks);
            this.gbBookLocation.Controls.Add(this.lblAvailable);
            this.gbBookLocation.Controls.Add(this.txtAvailableBooks);
            this.gbBookLocation.Controls.Add(this.lblRackNo);
            this.gbBookLocation.Controls.Add(this.lblISBN);
            this.gbBookLocation.Controls.Add(this.txtISBN);
            this.gbBookLocation.Location = new System.Drawing.Point(12, 97);
            this.gbBookLocation.Name = "gbBookLocation";
            this.gbBookLocation.Size = new System.Drawing.Size(203, 158);
            this.gbBookLocation.TabIndex = 1;
            this.gbBookLocation.TabStop = false;
            this.gbBookLocation.Text = "Book Location";
            // 
            // mtbRackNo
            // 
            this.mtbRackNo.HidePromptOnLeave = true;
            this.mtbRackNo.Location = new System.Drawing.Point(78, 45);
            this.mtbRackNo.Mask = "L-00";
            this.mtbRackNo.Name = "mtbRackNo";
            this.mtbRackNo.Size = new System.Drawing.Size(108, 20);
            this.mtbRackNo.TabIndex = 1;
            this.mtbRackNo.Leave += new System.EventHandler(this.MtbRackNo_Leave);
            // 
            // lblReserved
            // 
            this.lblReserved.AutoSize = true;
            this.lblReserved.Location = new System.Drawing.Point(6, 126);
            this.lblReserved.Name = "lblReserved";
            this.lblReserved.Size = new System.Drawing.Size(66, 13);
            this.lblReserved.TabIndex = 11;
            this.lblReserved.Text = "# Reserved:";
            // 
            // txtReservedBooks
            // 
            this.txtReservedBooks.Enabled = false;
            this.txtReservedBooks.Location = new System.Drawing.Point(78, 123);
            this.txtReservedBooks.Name = "txtReservedBooks";
            this.txtReservedBooks.Size = new System.Drawing.Size(108, 20);
            this.txtReservedBooks.TabIndex = 4;
            // 
            // lblBorrowed
            // 
            this.lblBorrowed.AutoSize = true;
            this.lblBorrowed.Location = new System.Drawing.Point(6, 100);
            this.lblBorrowed.Name = "lblBorrowed";
            this.lblBorrowed.Size = new System.Drawing.Size(65, 13);
            this.lblBorrowed.TabIndex = 9;
            this.lblBorrowed.Text = "# Borrowed:";
            // 
            // txtBorrowedBooks
            // 
            this.txtBorrowedBooks.Enabled = false;
            this.txtBorrowedBooks.Location = new System.Drawing.Point(78, 97);
            this.txtBorrowedBooks.Name = "txtBorrowedBooks";
            this.txtBorrowedBooks.Size = new System.Drawing.Size(108, 20);
            this.txtBorrowedBooks.TabIndex = 3;
            // 
            // lblAvailable
            // 
            this.lblAvailable.AutoSize = true;
            this.lblAvailable.Location = new System.Drawing.Point(6, 74);
            this.lblAvailable.Name = "lblAvailable";
            this.lblAvailable.Size = new System.Drawing.Size(63, 13);
            this.lblAvailable.TabIndex = 7;
            this.lblAvailable.Text = "# Available:";
            // 
            // txtAvailableBooks
            // 
            this.txtAvailableBooks.Location = new System.Drawing.Point(78, 71);
            this.txtAvailableBooks.Name = "txtAvailableBooks";
            this.txtAvailableBooks.Size = new System.Drawing.Size(108, 20);
            this.txtAvailableBooks.TabIndex = 2;
            // 
            // lblRackNo
            // 
            this.lblRackNo.AutoSize = true;
            this.lblRackNo.Location = new System.Drawing.Point(6, 48);
            this.lblRackNo.Name = "lblRackNo";
            this.lblRackNo.Size = new System.Drawing.Size(46, 13);
            this.lblRackNo.TabIndex = 5;
            this.lblRackNo.Text = "Rack #:";
            // 
            // lblISBN
            // 
            this.lblISBN.AutoSize = true;
            this.lblISBN.Location = new System.Drawing.Point(6, 22);
            this.lblISBN.Name = "lblISBN";
            this.lblISBN.Size = new System.Drawing.Size(35, 13);
            this.lblISBN.TabIndex = 3;
            this.lblISBN.Text = "ISBN:";
            // 
            // txtISBN
            // 
            this.txtISBN.Location = new System.Drawing.Point(78, 19);
            this.txtISBN.Name = "txtISBN";
            this.txtISBN.Size = new System.Drawing.Size(108, 20);
            this.txtISBN.TabIndex = 0;
            this.txtISBN.Leave += new System.EventHandler(this.TxtISBN_Leave);
            // 
            // btnCloseForm
            // 
            this.btnCloseForm.Location = new System.Drawing.Point(382, 265);
            this.btnCloseForm.Name = "btnCloseForm";
            this.btnCloseForm.Size = new System.Drawing.Size(90, 39);
            this.btnCloseForm.TabIndex = 4;
            this.btnCloseForm.Text = "Close Book Maintenance";
            this.btnCloseForm.UseVisualStyleBackColor = true;
            this.btnCloseForm.Click += new System.EventHandler(this.BtnCloseForm_Click);
            // 
            // btnAddModifyBookDetails
            // 
            this.btnAddModifyBookDetails.Location = new System.Drawing.Point(12, 266);
            this.btnAddModifyBookDetails.Name = "btnAddModifyBookDetails";
            this.btnAddModifyBookDetails.Size = new System.Drawing.Size(90, 38);
            this.btnAddModifyBookDetails.TabIndex = 3;
            this.btnAddModifyBookDetails.Text = "Add New Book";
            this.btnAddModifyBookDetails.UseVisualStyleBackColor = true;
            this.btnAddModifyBookDetails.Click += new System.EventHandler(this.BtnAddModifyBookDetails_Click);
            // 
            // frmBookDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 316);
            this.ControlBox = false;
            this.Controls.Add(this.btnAddModifyBookDetails);
            this.Controls.Add(this.btnCloseForm);
            this.Controls.Add(this.gbOfficeUse);
            this.Controls.Add(this.gbBookLocation);
            this.Controls.Add(this.gbBookDetails);
            this.MaximumSize = new System.Drawing.Size(550, 355);
            this.MinimumSize = new System.Drawing.Size(430, 355);
            this.Name = "frmBookDetailsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Book Details Form";
            this.Load += new System.EventHandler(this.FrmBookDetailsForm_Load);
            this.gbBookDetails.ResumeLayout(false);
            this.gbBookDetails.PerformLayout();
            this.gbOfficeUse.ResumeLayout(false);
            this.gbOfficeUse.PerformLayout();
            this.gbBookLocation.ResumeLayout(false);
            this.gbBookLocation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox gbBookDetails;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox gbOfficeUse;
        private System.Windows.Forms.Label lblBookID;
        private System.Windows.Forms.TextBox txtBookID;
        private System.Windows.Forms.GroupBox gbBookLocation;
        private System.Windows.Forms.Label lblReserved;
        private System.Windows.Forms.TextBox txtReservedBooks;
        private System.Windows.Forms.Label lblBorrowed;
        private System.Windows.Forms.TextBox txtBorrowedBooks;
        private System.Windows.Forms.Label lblAvailable;
        private System.Windows.Forms.TextBox txtAvailableBooks;
        private System.Windows.Forms.Label lblRackNo;
        private System.Windows.Forms.Label lblISBN;
        private System.Windows.Forms.TextBox txtISBN;
        private System.Windows.Forms.Button btnCloseForm;
        private System.Windows.Forms.Button btnAddModifyBookDetails;
        private System.Windows.Forms.MaskedTextBox mtbRackNo;
        private System.Windows.Forms.TextBox txtLibrarian;
        private System.Windows.Forms.Label lblLibrarian;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblPrice;
    }
}