﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.DataAccessLayer;
using LMS_OC.BusinessLogicLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmBookDetailsForm : Form
    {
        Book book = new Book();

        //method to store a bookID into the instance of book. 0 means add book
        public void SetBookID(int selectedRecord)
        {
            book.BookID = selectedRecord;
        }
        public frmBookDetailsForm()
        {
            InitializeComponent();
        }

        private void FrmBookDetailsForm_Load(object sender, EventArgs e)
        {
            if (book.BookID == 0)
            {
                this.Text = "Add New Book Details";
                txtPrice.Enabled = true;
                txtPrice.ReadOnly = false;
            }
            else
            {
                this.Text = "Modify Existing Book Details";
                btnAddModifyBookDetails.Text = "Modify Book Details";
                txtAvailableBooks.Enabled = false;

                //Finds the selected record from the book table and creates a DataTable
                DataTable bookDT = ConnectionManager.GetTable("SELECT * FROM Book WHERE bookID ="
                    + book.BookID + "");

                if (bookDT.Rows.Count == 0)
                {
                    //This code should not run as the record was selected from the listView item on the maintenance screen
                    MessageBox.Show("Book with bookID " + book.BookID + " doesn't exist.\n" +
                        "Program will return to previous screen.");
                    ClearForm();
                    CloseForm();
                }
                else
                {
                    //loads author instance with record details
                    book.BookTitle = bookDT.Rows[0]["title"].ToString();
                    book.BookAuthorID = int.Parse(bookDT.Rows[0]["authorID"].ToString());
                    book.BookISBN = bookDT.Rows[0]["ISBN"].ToString();
                    book.RackNumber = bookDT.Rows[0]["rackNo"].ToString();
                    book.AvailableBooks = int.Parse(bookDT.Rows[0]["noOfAvailableBooks"].ToString());
                    book.BorrowedBooks = int.Parse(bookDT.Rows[0]["noOfBorrowedBooks"].ToString());
                    book.LibrarianID = int.Parse(bookDT.Rows[0]["librarianID"].ToString());
                    book.BookPrice = double.Parse(bookDT.Rows[0]["price"].ToString());
                    
                    //loads the form fields with record details from the author instance
                    txtTitle.Text = book.BookTitle.ToString();
                    txtISBN.Text = book.BookISBN;
                    mtbRackNo.Text = book.RackNumber;
                    txtAvailableBooks.Text = book.AvailableBooks.ToString();
                    txtBorrowedBooks.Text = book.BorrowedBooks.ToString();
                    txtPrice.Text = book.BookPrice.ToString("0.00");

                    FindAuthor();
                    FindLibrarian();
                    txtReservedBooks.Text = CalculateReserved().ToString();

                    txtTitle.Focus();
                }
            }
        }

        private void BtnCloseForm_Click(object sender, EventArgs e)
        {
            CloseForm();
        }

        private void CloseForm()
        {
            GlobalVariables.ClearBookFilter();
            this.Close();
        }

        private void BtnAddModifyBookDetails_Click(object sender, EventArgs e)
        {
            if (CheckFields()) //Checks the entered information for validity
            {
                book.BookTitle = txtTitle.Text;
                book.BookISBN = txtISBN.Text;
                book.RackNumber = mtbRackNo.Text;
                book.AvailableBooks = int.Parse(txtAvailableBooks.Text);
                string tempPrice = txtPrice.Text.ToString();
                book.BookPrice = double.Parse(tempPrice.ToString());
                book.LibrarianID = int.Parse(System.Environment.GetEnvironmentVariable("librarianID"));

                int bookCount = book.BookAddModify(); //updates the author table
                if (bookCount == 0)
                {
                    MessageBox.Show("Update Operation failed. Check the values provided and try again."); //shows if failed
                }
                else
                {
                    if (book.BookID == 0)
                    {
                        MessageBox.Show("Book added successfully."); //displays if new book
                    }
                    else
                    {
                        MessageBox.Show("Book updated successfully."); //displays if existing book
                    }
                    CloseForm();
                }
            }
        }

        private string errorMessage = "";
        private bool CheckFields()
        {
            //Checks the various fields for correct data / not length 0 unless appropriate
            errorMessage = "";

            if(CheckString(txtTitle.Text, "Title"))
            {
                if (txtTitle.Text.Contains("'"))
                {
                    errorMessage += "  Title cannot contain '";
                }
            }
            CheckString(txtAuthor.Text, "Author Name");
            CheckString(txtISBN.Text, "ISBN");

            if (CheckString(txtAvailableBooks.Text, "# Available Books"))
            {
                try
                {
                    if (int.Parse(txtAvailableBooks.Text) < 0)
                    {
                        errorMessage += "  # Available Books must be a positive number\n";
                    }
                }
                catch
                {
                    errorMessage += "  # Available Books must be a whole number\n";
                }
            }
            if (CheckString(txtPrice.Text, "Price"))
            {
                try
                {
                    //Price cannot be 0 when Available>0 or Available=0 and Borrowed>0 eg Books exist
                    if(decimal.Parse(txtPrice.Text) == 0 && (int.Parse(txtAvailableBooks.Text)!=0 
                        || int.Parse(txtAvailableBooks.Text)==0 && int.Parse(txtBorrowedBooks.Text) != 0))
                    {
                        errorMessage += "  Price needs to be entered\n";
                    }
                }
                catch
                {
                    errorMessage += "  Price must be a decimal number\n";
                }
            }

            if (errorMessage.Length > 0) //field information errors
            {
                MessageBox.Show("This information needs to be corrected:\n" + errorMessage);
                return false;
            }
            return true; //no field information errors
        }

        private bool CheckString(string item, string name)
        {
            //checks the item and uses name in the warning message to user of the issue
            if (item.Trim().Length == 0)
            {
                errorMessage += "  " + name + " cannot be blank\n";
                return false;
            }
            return true;
        }

        private bool CheckSpecialCharacters(string checkText, string name)
        {
            //check for reduced potential SQLinjection and valid characters
            //goes through each character and compares for AlphaNumeric
            if (!(checkText.All(ch => char.IsLetterOrDigit(ch) || char.IsWhiteSpace(ch))))
            {
                errorMessage += "  " + name + " cannot contain special characters\n";
                return false;
            }
            return true;
        }

        private void TxtAuthor_Enter(object sender, EventArgs e)
        {
            if (txtAuthor.TextLength > 0)
            {
                DialogResult dialogResult = MessageBox.Show("Would you like to change the author details?", "",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
                if (dialogResult == DialogResult.No)
                {
                    return;
                }
            }
            //Code to find an Author - listview / seach / add options
            frmAuthorSelectionList subForm = new frmAuthorSelectionList();
            DialogResult result = subForm.ShowDialog();
            if (result == DialogResult.Yes)
            {
                book.BookAuthorID = subForm.returnValue;
                FindAuthor();
            }
        }

        private void FindAuthor()
        {
            DataTable authorDT = ConnectionManager.GetTable("SELECT * FROM Author WHERE authorID = "
                + book.BookAuthorID + "");

            if (authorDT.Rows.Count == 0)
            {
                MessageBox.Show("The author could not be found. This record will be cleared.", "Author Not Found"
                    , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ClearForm();
                txtTitle.Focus();
            }
            else
            {
                txtAuthor.Text = authorDT.Rows[0]["authorName"].ToString();
            }
        }

        private void FindLibrarian()
        {
            DataTable librarianID = ConnectionManager.GetTable("SELECT * FROM Librarian WHERE librarianID = "
                + book.LibrarianID + "");

            if (librarianID.Rows.Count == 0)
            {
                MessageBox.Show("The librarian could not be found. This record will be cleared.", "Librarian Not Found"
                    , MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ClearForm();
                txtTitle.Focus();
            }
            else
            {
                txtLibrarian.Text = librarianID.Rows[0]["firstName"].ToString() + " " + librarianID.Rows[0]["lastName"];
            }
        }

        private int CalculateReserved()
        {
            //Counts the number of reserved books from the BookReserve table and creates a DataTable
            DataTable reservedDT = ConnectionManager.GetTable("SELECT * FROM BookReserve WHERE bookID ="
            + book.BookID + "");
            return (reservedDT.Rows.Count);
        }

        private void TxtRackNo_Leave(object sender, EventArgs e)
        {
            //Check the rack details are entered correctly
        }

        private void ClearForm()
        {
            txtTitle.Text = "";
            txtAuthor.Text = "";
            txtISBN.Text = "";
            mtbRackNo.Clear();
            txtAvailableBooks.Text = "";
            txtBorrowedBooks.Text = "";
            txtReservedBooks.Text = "";
        }

        private void TxtPrice_Leave(object sender, EventArgs e)
        {
            //checks the Fine information and changes the format to currency if entered incorrectly. Sets to 0.00 if incorrect
            if (txtPrice.Text.Length > 0)
            {
                try
                {
                    decimal tempPrice = decimal.Parse(txtPrice.Text);
                    txtPrice.Text = tempPrice.ToString("0.00");
                }
                catch
                {
                    txtPrice.Text = "0.00";
                }
            }
        }

        private void TxtISBN_Leave(object sender, EventArgs e)
        {
            if (txtISBN.TextLength == 10 && txtISBN.Text.All(ch => char.IsDigit(ch)))
            {
                {
                    //Converts the entered 10 digit ISBN to x-xxx-xxxxx-x number format
                    string holdISBN = "";
                    for (int i = 0; i < txtISBN.Text.Length; i++)
                    {
                        switch (i)
                        {
                            case 1:
                            case 4:
                            case 9:
                                holdISBN += "-" + txtISBN.Text.Substring(i, 1);
                                break;
                            default:
                                holdISBN += txtISBN.Text.Substring(i, 1);
                                break;
                        }
                    }
                    txtISBN.Text = holdISBN;
                }
            }
            else if(txtISBN.TextLength >= 13)
                {
                    if(txtISBN.Text.All(ch => char.IsDigit(ch)))
                    {
                        MessageBox.Show("Please format the ISBN correctly.","ISBN wrong format", MessageBoxButtons.OK);
                        txtISBN.Focus();
                    }
                }
            else
            {
                MessageBox.Show("ISBN is incorrectly formatted.","ISBN wrong format",MessageBoxButtons.OK);
                txtISBN.Text = "";
                txtISBN.Focus();
            }
        }

        private void MtbRackNo_Leave(object sender, EventArgs e)
        {
            if(mtbRackNo.Text.Trim().Length < 4)
            {
                MessageBox.Show("Rack no. requires full information.", "Rack No incorrect", MessageBoxButtons.OK);
                mtbRackNo.Text = "";
                mtbRackNo.Focus();
            }
            else
            {
                mtbRackNo.Text = mtbRackNo.Text.ToUpper();
            }
        }
    }
}

