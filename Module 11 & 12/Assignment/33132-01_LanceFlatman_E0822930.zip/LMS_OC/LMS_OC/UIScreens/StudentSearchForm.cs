﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmStudentSearchForm : Form
    {
        public frmStudentSearchForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnSetFilter_Click(object sender, EventArgs e)
        {
            //Checks for valid information e.g. does not allow special characters (minimise SQLinjection)
            if ((txtLastName.TextLength > 0 && !GlobalVariables.TestFilterIsValid(txtLastName.Text)) 
                || (txtSuburb.TextLength > 0 && !GlobalVariables.TestFilterIsValid(txtSuburb.Text)))
            {
                MessageBox.Show("Characters or Numbers only for valid filter conditions.");
                txtLastName.Text = "";
                txtPostCode.Text = "";
                txtSuburb.Text = "";
                txtLastName.Focus();
                return;
            }

            if (txtPostCode.Text.Trim().Length > 0)
            {
                try
                {
                    int.Parse(txtPostCode.Text.Trim());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Post code must be numerical\n"+ex);
                    return;
                }
            }
            GlobalVariables.StudentLastName = txtLastName.Text.Trim();
            GlobalVariables.StudentPostCode = txtPostCode.Text.Trim();
            GlobalVariables.StudentSuburb = txtSuburb.Text.Trim();

            this.Close();
        }
    }
}
