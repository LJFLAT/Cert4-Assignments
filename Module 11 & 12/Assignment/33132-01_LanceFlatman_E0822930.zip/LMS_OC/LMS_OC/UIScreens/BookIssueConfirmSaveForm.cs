﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;

namespace LMS_OC.UIScreens
{
    public partial class frmBookIssueConfirmSave : Form
    {
        BookIssueReserveReturn bookIssueReserve;
        bool isBookIssue;
        public frmBookIssueConfirmSave(BookIssueReserveReturn bookDetails, bool bookIssue
            , string sentTitle, string sentStudentName)
        {
            InitializeComponent();
            bookIssueReserve = bookDetails;
            isBookIssue = bookIssue;
            txtBookID.Text = bookIssueReserve.BookID.ToString();
            txtStudentID.Text = bookIssueReserve.StudentID.ToString();
            txtBookTitle.Text = sentTitle;
            txtStudentName.Text = sentStudentName;
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No;
            this.Close();
        }

        private void FrmBookIssueConfirmSave_Load(object sender, EventArgs e)
        {
            if(isBookIssue) // normal book issue
            {
                StandardReturnDays();
                txtIssueDate.Text = DateTime.Today.ToString("dd/MM/yyyy");
            }
            else // reservation of a book
            {
                //Change text and details of form to enter reservation information
                lblIssueDate.Visible = false;
                txtIssueDate.Visible = false;
                lblReturnDate.Text = "Reservation Date";
                dtpReturnReserveDate.Value = DateTime.Today;
                btnConfirmIssue.Text = "New Book Reservation";
                this.Text = "Book Reservation Details";
            }
        }

        private void BtnConfirmIssue_Click(object sender, EventArgs e)
        {
            if(isBookIssue) //When issue of a book
            {
                if (dtpReturnReserveDate.Value < DateTime.Today)
                {
                    MessageBox.Show("Return date cannot be earlier than today","Wrong date information"
                        ,MessageBoxButtons.OK);
                    StandardReturnDays();
                    return;
                }
                if(dtpReturnReserveDate.Value > bookIssueReserve.MaximumReturnDays(DateTime.Today))
                {
                    MessageBox.Show("Return date is over the allowed period.", "Return Date Beyond Allowed"
                        , MessageBoxButtons.OK);
                    StandardReturnDays();
                    return;
                }
                bookIssueReserve.IssueReserveDate = DateTime.Parse(txtIssueDate.Text);
                bookIssueReserve.ReturnDate = dtpReturnReserveDate.Value;
            }
            else //when reserving a book
            {
                if(dtpReturnReserveDate.Value < DateTime.Today.AddDays(-1))
                {
                    MessageBox.Show("Reservation date cannot be earlier than the previous day"
                        ,"Incorrect Reservation Date", MessageBoxButtons.OK);
                    dtpReturnReserveDate.Value = DateTime.Today;
                    return;
                }
                bookIssueReserve.IssueReserveDate = dtpReturnReserveDate.Value;
            }
            this.DialogResult = DialogResult.Yes;
            this.Close();
        }

        //Looks up the method in the BookIssueReserveReturn class and sets the return date to default
        private void StandardReturnDays()
        {
            dtpReturnReserveDate.Value = bookIssueReserve.StandardReturnDays(DateTime.Today);
        }
    }
}
