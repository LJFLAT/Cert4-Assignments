﻿namespace LMS_OC.UIScreens
{
    partial class frmBooksToIssueReserveForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvBookList = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvStudentList = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblBookList = new System.Windows.Forms.Label();
            this.lblStudentList = new System.Windows.Forms.Label();
            this.btnCancelReturn = new System.Windows.Forms.Button();
            this.btnIssueReserveSelectedBookToStudent = new System.Windows.Forms.Button();
            this.txtTitleFilter = new System.Windows.Forms.TextBox();
            this.lblPartialTitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLastNameFilter = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lvBookList
            // 
            this.lvBookList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lvBookList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11});
            this.lvBookList.FullRowSelect = true;
            this.lvBookList.GridLines = true;
            this.lvBookList.HideSelection = false;
            this.lvBookList.Location = new System.Drawing.Point(12, 26);
            this.lvBookList.MultiSelect = false;
            this.lvBookList.Name = "lvBookList";
            this.lvBookList.Size = new System.Drawing.Size(674, 385);
            this.lvBookList.TabIndex = 0;
            this.lvBookList.UseCompatibleStateImageBehavior = false;
            this.lvBookList.View = System.Windows.Forms.View.Details;
            this.lvBookList.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.LvBookList_ColumnClick);
            this.lvBookList.SelectedIndexChanged += new System.EventHandler(this.LvBookList_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Book ID";
            this.columnHeader1.Width = 0;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Title";
            this.columnHeader6.Width = 180;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Author Name";
            this.columnHeader7.Width = 150;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "ISBN";
            this.columnHeader8.Width = 110;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "# Available";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader9.Width = 65;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "# Issued";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader10.Width = 65;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "# Reserved";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader11.Width = 70;
            // 
            // lvStudentList
            // 
            this.lvStudentList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvStudentList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader12});
            this.lvStudentList.FullRowSelect = true;
            this.lvStudentList.GridLines = true;
            this.lvStudentList.HideSelection = false;
            this.lvStudentList.Location = new System.Drawing.Point(697, 26);
            this.lvStudentList.MultiSelect = false;
            this.lvStudentList.Name = "lvStudentList";
            this.lvStudentList.Size = new System.Drawing.Size(447, 385);
            this.lvStudentList.TabIndex = 1;
            this.lvStudentList.UseCompatibleStateImageBehavior = false;
            this.lvStudentList.View = System.Windows.Forms.View.Details;
            this.lvStudentList.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.LvStudentList_ColumnClick);
            this.lvStudentList.SelectedIndexChanged += new System.EventHandler(this.LvStudentList_SelectedIndexChanged);
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Student ID";
            this.columnHeader5.Width = 0;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "First Name";
            this.columnHeader2.Width = 110;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Last Name";
            this.columnHeader3.Width = 110;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Contact #";
            this.columnHeader4.Width = 100;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Reserve Date";
            this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader12.Width = 95;
            // 
            // lblBookList
            // 
            this.lblBookList.AutoSize = true;
            this.lblBookList.Location = new System.Drawing.Point(12, 7);
            this.lblBookList.Name = "lblBookList";
            this.lblBookList.Size = new System.Drawing.Size(54, 13);
            this.lblBookList.TabIndex = 1;
            this.lblBookList.Text = "Book List:";
            // 
            // lblStudentList
            // 
            this.lblStudentList.AutoSize = true;
            this.lblStudentList.Location = new System.Drawing.Point(694, 7);
            this.lblStudentList.Name = "lblStudentList";
            this.lblStudentList.Size = new System.Drawing.Size(66, 13);
            this.lblStudentList.TabIndex = 1;
            this.lblStudentList.Text = "Student List:";
            // 
            // btnCancelReturn
            // 
            this.btnCancelReturn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancelReturn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCancelReturn.Location = new System.Drawing.Point(1054, 420);
            this.btnCancelReturn.Name = "btnCancelReturn";
            this.btnCancelReturn.Size = new System.Drawing.Size(90, 38);
            this.btnCancelReturn.TabIndex = 5;
            this.btnCancelReturn.Text = "Cancel / Close Form";
            this.btnCancelReturn.UseVisualStyleBackColor = true;
            this.btnCancelReturn.Click += new System.EventHandler(this.BtnCancelReturn_Click);
            // 
            // btnIssueReserveSelectedBookToStudent
            // 
            this.btnIssueReserveSelectedBookToStudent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnIssueReserveSelectedBookToStudent.Location = new System.Drawing.Point(12, 420);
            this.btnIssueReserveSelectedBookToStudent.Name = "btnIssueReserveSelectedBookToStudent";
            this.btnIssueReserveSelectedBookToStudent.Size = new System.Drawing.Size(92, 38);
            this.btnIssueReserveSelectedBookToStudent.TabIndex = 2;
            this.btnIssueReserveSelectedBookToStudent.Text = "Issue / Reserve Book to Student";
            this.btnIssueReserveSelectedBookToStudent.UseVisualStyleBackColor = true;
            this.btnIssueReserveSelectedBookToStudent.Click += new System.EventHandler(this.BtnIssueReserveSelectedBookToStudent_Click);
            // 
            // txtTitleFilter
            // 
            this.txtTitleFilter.Location = new System.Drawing.Point(139, 438);
            this.txtTitleFilter.Name = "txtTitleFilter";
            this.txtTitleFilter.Size = new System.Drawing.Size(100, 20);
            this.txtTitleFilter.TabIndex = 3;
            this.txtTitleFilter.TextChanged += new System.EventHandler(this.TxtTitleFilter_TextChanged);
            // 
            // lblPartialTitle
            // 
            this.lblPartialTitle.AutoSize = true;
            this.lblPartialTitle.Location = new System.Drawing.Point(130, 420);
            this.lblPartialTitle.Name = "lblPartialTitle";
            this.lblPartialTitle.Size = new System.Drawing.Size(128, 13);
            this.lblPartialTitle.TabIndex = 13;
            this.lblPartialTitle.Text = "Filter TITLE (min 3 chars):";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(787, 420);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Filter LAST NAME (min 3 chars):";
            // 
            // txtLastNameFilter
            // 
            this.txtLastNameFilter.Location = new System.Drawing.Point(816, 438);
            this.txtLastNameFilter.Name = "txtLastNameFilter";
            this.txtLastNameFilter.Size = new System.Drawing.Size(100, 20);
            this.txtLastNameFilter.TabIndex = 4;
            this.txtLastNameFilter.TextChanged += new System.EventHandler(this.TxtLastNameFilter_TextChanged);
            // 
            // frmBooksToIssueReserveForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1156, 467);
            this.Controls.Add(this.txtLastNameFilter);
            this.Controls.Add(this.txtTitleFilter);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblPartialTitle);
            this.Controls.Add(this.btnIssueReserveSelectedBookToStudent);
            this.Controls.Add(this.btnCancelReturn);
            this.Controls.Add(this.lblStudentList);
            this.Controls.Add(this.lblBookList);
            this.Controls.Add(this.lvStudentList);
            this.Controls.Add(this.lvBookList);
            this.MinimumSize = new System.Drawing.Size(1068, 506);
            this.Name = "frmBooksToIssueReserveForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Books To Issue / Reserve Form";
            this.Load += new System.EventHandler(this.FrmBooksToIssueReserveForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvBookList;
        private System.Windows.Forms.ListView lvStudentList;
        private System.Windows.Forms.Label lblBookList;
        private System.Windows.Forms.Label lblStudentList;
        private System.Windows.Forms.Button btnCancelReturn;
        private System.Windows.Forms.Button btnIssueReserveSelectedBookToStudent;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.TextBox txtTitleFilter;
        private System.Windows.Forms.Label lblPartialTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLastNameFilter;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader12;
    }
}