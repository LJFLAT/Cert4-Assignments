﻿namespace LMS_OC.UIScreens
{
    partial class frmStudentDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblStudentID = new System.Windows.Forms.Label();
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.lblAddress1 = new System.Windows.Forms.Label();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.lblAddress2 = new System.Windows.Forms.Label();
            this.gbStudentName = new System.Windows.Forms.GroupBox();
            this.txtSuburb = new System.Windows.Forms.TextBox();
            this.lblSuburb = new System.Windows.Forms.Label();
            this.gbStudentAddress = new System.Windows.Forms.GroupBox();
            this.cbState = new System.Windows.Forms.ComboBox();
            this.lblState = new System.Windows.Forms.Label();
            this.txtPostCode = new System.Windows.Forms.TextBox();
            this.lblPostCode = new System.Windows.Forms.Label();
            this.gbOfficeUse = new System.Windows.Forms.GroupBox();
            this.txtFine = new System.Windows.Forms.TextBox();
            this.lblFine = new System.Windows.Forms.Label();
            this.gbContactDetails = new System.Windows.Forms.GroupBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtContactNo = new System.Windows.Forms.TextBox();
            this.lblContactNo = new System.Windows.Forms.Label();
            this.btnCancelReturn = new System.Windows.Forms.Button();
            this.btnAddModifyRecord = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.gbStudentName.SuspendLayout();
            this.gbStudentAddress.SuspendLayout();
            this.gbOfficeUse.SuspendLayout();
            this.gbContactDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblStudentID
            // 
            this.lblStudentID.AutoSize = true;
            this.lblStudentID.Location = new System.Drawing.Point(6, 25);
            this.lblStudentID.Name = "lblStudentID";
            this.lblStudentID.Size = new System.Drawing.Size(61, 13);
            this.lblStudentID.TabIndex = 0;
            this.lblStudentID.Text = "Student ID:";
            // 
            // txtStudentID
            // 
            this.txtStudentID.Enabled = false;
            this.txtStudentID.Location = new System.Drawing.Point(96, 22);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.ReadOnly = true;
            this.txtStudentID.Size = new System.Drawing.Size(102, 20);
            this.txtStudentID.TabIndex = 0;
            this.txtStudentID.TabStop = false;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(103, 22);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(199, 20);
            this.txtFirstName.TabIndex = 0;
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(9, 25);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 2;
            this.lblFirstName.Text = "First Name:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(103, 48);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(199, 20);
            this.txtLastName.TabIndex = 1;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(9, 51);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 4;
            this.lblLastName.Text = "Last Name:";
            // 
            // txtAddress1
            // 
            this.txtAddress1.Location = new System.Drawing.Point(102, 19);
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(200, 20);
            this.txtAddress1.TabIndex = 0;
            // 
            // lblAddress1
            // 
            this.lblAddress1.AutoSize = true;
            this.lblAddress1.Location = new System.Drawing.Point(8, 22);
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.Size = new System.Drawing.Size(57, 13);
            this.lblAddress1.TabIndex = 6;
            this.lblAddress1.Text = "Address 1:";
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(102, 45);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(200, 20);
            this.txtAddress2.TabIndex = 1;
            // 
            // lblAddress2
            // 
            this.lblAddress2.AutoSize = true;
            this.lblAddress2.Location = new System.Drawing.Point(8, 48);
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.Size = new System.Drawing.Size(57, 13);
            this.lblAddress2.TabIndex = 8;
            this.lblAddress2.Text = "Address 2:";
            // 
            // gbStudentName
            // 
            this.gbStudentName.Controls.Add(this.txtFirstName);
            this.gbStudentName.Controls.Add(this.lblFirstName);
            this.gbStudentName.Controls.Add(this.lblLastName);
            this.gbStudentName.Controls.Add(this.txtLastName);
            this.gbStudentName.Location = new System.Drawing.Point(12, 12);
            this.gbStudentName.Name = "gbStudentName";
            this.gbStudentName.Size = new System.Drawing.Size(318, 81);
            this.gbStudentName.TabIndex = 0;
            this.gbStudentName.TabStop = false;
            this.gbStudentName.Text = "Student Name";
            // 
            // txtSuburb
            // 
            this.txtSuburb.Location = new System.Drawing.Point(102, 71);
            this.txtSuburb.Name = "txtSuburb";
            this.txtSuburb.Size = new System.Drawing.Size(200, 20);
            this.txtSuburb.TabIndex = 2;
            // 
            // lblSuburb
            // 
            this.lblSuburb.AutoSize = true;
            this.lblSuburb.Location = new System.Drawing.Point(8, 74);
            this.lblSuburb.Name = "lblSuburb";
            this.lblSuburb.Size = new System.Drawing.Size(44, 13);
            this.lblSuburb.TabIndex = 10;
            this.lblSuburb.Text = "Suburb:";
            // 
            // gbStudentAddress
            // 
            this.gbStudentAddress.Controls.Add(this.cbState);
            this.gbStudentAddress.Controls.Add(this.lblState);
            this.gbStudentAddress.Controls.Add(this.txtPostCode);
            this.gbStudentAddress.Controls.Add(this.lblPostCode);
            this.gbStudentAddress.Controls.Add(this.txtSuburb);
            this.gbStudentAddress.Controls.Add(this.txtAddress1);
            this.gbStudentAddress.Controls.Add(this.lblSuburb);
            this.gbStudentAddress.Controls.Add(this.lblAddress1);
            this.gbStudentAddress.Controls.Add(this.lblAddress2);
            this.gbStudentAddress.Controls.Add(this.txtAddress2);
            this.gbStudentAddress.Location = new System.Drawing.Point(12, 109);
            this.gbStudentAddress.Name = "gbStudentAddress";
            this.gbStudentAddress.Size = new System.Drawing.Size(318, 157);
            this.gbStudentAddress.TabIndex = 1;
            this.gbStudentAddress.TabStop = false;
            this.gbStudentAddress.Text = "Student Address";
            // 
            // cbState
            // 
            this.cbState.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbState.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbState.FormattingEnabled = true;
            this.cbState.Items.AddRange(new object[] {
            "NSW",
            "VIC",
            "QLD",
            "WA",
            "SA",
            "TAS",
            "ACT",
            "NT"});
            this.cbState.Location = new System.Drawing.Point(102, 97);
            this.cbState.Name = "cbState";
            this.cbState.Size = new System.Drawing.Size(89, 21);
            this.cbState.TabIndex = 3;
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(8, 100);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(35, 13);
            this.lblState.TabIndex = 14;
            this.lblState.Text = "State:";
            // 
            // txtPostCode
            // 
            this.txtPostCode.Location = new System.Drawing.Point(102, 124);
            this.txtPostCode.Name = "txtPostCode";
            this.txtPostCode.Size = new System.Drawing.Size(89, 20);
            this.txtPostCode.TabIndex = 4;
            // 
            // lblPostCode
            // 
            this.lblPostCode.AutoSize = true;
            this.lblPostCode.Location = new System.Drawing.Point(8, 127);
            this.lblPostCode.Name = "lblPostCode";
            this.lblPostCode.Size = new System.Drawing.Size(59, 13);
            this.lblPostCode.TabIndex = 12;
            this.lblPostCode.Text = "Post Code:";
            // 
            // gbOfficeUse
            // 
            this.gbOfficeUse.Controls.Add(this.txtFine);
            this.gbOfficeUse.Controls.Add(this.lblFine);
            this.gbOfficeUse.Controls.Add(this.txtStudentID);
            this.gbOfficeUse.Controls.Add(this.lblStudentID);
            this.gbOfficeUse.Location = new System.Drawing.Point(363, 12);
            this.gbOfficeUse.Name = "gbOfficeUse";
            this.gbOfficeUse.Size = new System.Drawing.Size(210, 81);
            this.gbOfficeUse.TabIndex = 2;
            this.gbOfficeUse.TabStop = false;
            this.gbOfficeUse.Text = "Office Use";
            // 
            // txtFine
            // 
            this.txtFine.Enabled = false;
            this.txtFine.Location = new System.Drawing.Point(96, 48);
            this.txtFine.Name = "txtFine";
            this.txtFine.ReadOnly = true;
            this.txtFine.Size = new System.Drawing.Size(102, 20);
            this.txtFine.TabIndex = 1;
            this.txtFine.TabStop = false;
            this.txtFine.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip.SetToolTip(this.txtFine, "Format ##.##");
            this.txtFine.Leave += new System.EventHandler(this.TxtFine_Leave);
            // 
            // lblFine
            // 
            this.lblFine.AutoSize = true;
            this.lblFine.Location = new System.Drawing.Point(6, 51);
            this.lblFine.Name = "lblFine";
            this.lblFine.Size = new System.Drawing.Size(30, 13);
            this.lblFine.TabIndex = 2;
            this.lblFine.Text = "Fine:";
            // 
            // gbContactDetails
            // 
            this.gbContactDetails.Controls.Add(this.txtEmail);
            this.gbContactDetails.Controls.Add(this.lblEmail);
            this.gbContactDetails.Controls.Add(this.txtContactNo);
            this.gbContactDetails.Controls.Add(this.lblContactNo);
            this.gbContactDetails.Location = new System.Drawing.Point(354, 109);
            this.gbContactDetails.Name = "gbContactDetails";
            this.gbContactDetails.Size = new System.Drawing.Size(369, 84);
            this.gbContactDetails.TabIndex = 3;
            this.gbContactDetails.TabStop = false;
            this.gbContactDetails.Text = "Contact Details";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(100, 52);
            this.txtEmail.MaxLength = 100;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(256, 20);
            this.txtEmail.TabIndex = 1;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(6, 55);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.TabIndex = 14;
            this.lblEmail.Text = "Email:";
            // 
            // txtContactNo
            // 
            this.txtContactNo.Location = new System.Drawing.Point(100, 26);
            this.txtContactNo.Name = "txtContactNo";
            this.txtContactNo.Size = new System.Drawing.Size(119, 20);
            this.txtContactNo.TabIndex = 0;
            this.toolTip.SetToolTip(this.txtContactNo, "Format (##) #### ####");
            this.txtContactNo.Leave += new System.EventHandler(this.TxtContactNo_Leave);
            // 
            // lblContactNo
            // 
            this.lblContactNo.AutoSize = true;
            this.lblContactNo.Location = new System.Drawing.Point(6, 29);
            this.lblContactNo.Name = "lblContactNo";
            this.lblContactNo.Size = new System.Drawing.Size(81, 13);
            this.lblContactNo.TabIndex = 12;
            this.lblContactNo.Text = "Phone Number:";
            // 
            // btnCancelReturn
            // 
            this.btnCancelReturn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancelReturn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCancelReturn.Location = new System.Drawing.Point(632, 281);
            this.btnCancelReturn.Name = "btnCancelReturn";
            this.btnCancelReturn.Size = new System.Drawing.Size(90, 38);
            this.btnCancelReturn.TabIndex = 5;
            this.btnCancelReturn.Text = "Cancel / Close Form";
            this.btnCancelReturn.UseVisualStyleBackColor = true;
            this.btnCancelReturn.Click += new System.EventHandler(this.BtnCancelReturn_Click);
            // 
            // btnAddModifyRecord
            // 
            this.btnAddModifyRecord.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAddModifyRecord.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnAddModifyRecord.Location = new System.Drawing.Point(12, 281);
            this.btnAddModifyRecord.Name = "btnAddModifyRecord";
            this.btnAddModifyRecord.Size = new System.Drawing.Size(90, 38);
            this.btnAddModifyRecord.TabIndex = 4;
            this.btnAddModifyRecord.Text = "Add Student Record";
            this.btnAddModifyRecord.UseVisualStyleBackColor = true;
            this.btnAddModifyRecord.Click += new System.EventHandler(this.BtnAddModifyRecord_Click);
            // 
            // toolTip
            // 
            this.toolTip.AutomaticDelay = 100;
            this.toolTip.AutoPopDelay = 5000;
            this.toolTip.InitialDelay = 50;
            this.toolTip.ReshowDelay = 20;
            this.toolTip.UseAnimation = false;
            this.toolTip.UseFading = false;
            // 
            // frmStudentDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 331);
            this.Controls.Add(this.btnAddModifyRecord);
            this.Controls.Add(this.btnCancelReturn);
            this.Controls.Add(this.gbContactDetails);
            this.Controls.Add(this.gbOfficeUse);
            this.Controls.Add(this.gbStudentAddress);
            this.Controls.Add(this.gbStudentName);
            this.MaximumSize = new System.Drawing.Size(750, 370);
            this.MinimumSize = new System.Drawing.Size(750, 370);
            this.Name = "frmStudentDetailsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Details Form";
            this.Load += new System.EventHandler(this.StudentDetailsForm_Load);
            this.gbStudentName.ResumeLayout(false);
            this.gbStudentName.PerformLayout();
            this.gbStudentAddress.ResumeLayout(false);
            this.gbStudentAddress.PerformLayout();
            this.gbOfficeUse.ResumeLayout(false);
            this.gbOfficeUse.PerformLayout();
            this.gbContactDetails.ResumeLayout(false);
            this.gbContactDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblStudentID;
        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.Label lblAddress1;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.Label lblAddress2;
        private System.Windows.Forms.GroupBox gbStudentName;
        private System.Windows.Forms.TextBox txtSuburb;
        private System.Windows.Forms.Label lblSuburb;
        private System.Windows.Forms.GroupBox gbStudentAddress;
        private System.Windows.Forms.GroupBox gbOfficeUse;
        private System.Windows.Forms.TextBox txtFine;
        private System.Windows.Forms.Label lblFine;
        private System.Windows.Forms.GroupBox gbContactDetails;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtContactNo;
        private System.Windows.Forms.Label lblContactNo;
        private System.Windows.Forms.Button btnCancelReturn;
        private System.Windows.Forms.Button btnAddModifyRecord;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ComboBox cbState;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.TextBox txtPostCode;
        private System.Windows.Forms.Label lblPostCode;
    }
}