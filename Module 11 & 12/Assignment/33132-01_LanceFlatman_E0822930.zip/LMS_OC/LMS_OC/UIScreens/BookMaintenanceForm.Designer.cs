﻿namespace LMS_OC.UIScreens
{
    partial class frmBookMaintenanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvBookList = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSearchFilterBookList = new System.Windows.Forms.Button();
            this.btnModifyBook = new System.Windows.Forms.Button();
            this.btnAddBook = new System.Windows.Forms.Button();
            this.btnCloseForm = new System.Windows.Forms.Button();
            this.btnAdjustBookQuantity = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvBookList
            // 
            this.lvBookList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvBookList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader5,
            this.columnHeader4,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader1});
            this.lvBookList.FullRowSelect = true;
            this.lvBookList.GridLines = true;
            this.lvBookList.HideSelection = false;
            this.lvBookList.Location = new System.Drawing.Point(13, 10);
            this.lvBookList.MultiSelect = false;
            this.lvBookList.Name = "lvBookList";
            this.lvBookList.Size = new System.Drawing.Size(1169, 573);
            this.lvBookList.TabIndex = 9;
            this.lvBookList.UseCompatibleStateImageBehavior = false;
            this.lvBookList.View = System.Windows.Forms.View.Details;
            this.lvBookList.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.LvBookList_ColumnClick);
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Book ID";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Title";
            this.columnHeader2.Width = 180;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Author Name";
            this.columnHeader3.Width = 150;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "ISBN";
            this.columnHeader5.Width = 110;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Rack #";
            this.columnHeader4.Width = 50;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "# Available";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader6.Width = 70;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "# Issued";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 70;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "# Reserved";
            this.columnHeader1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader1.Width = 70;
            // 
            // btnSearchFilterBookList
            // 
            this.btnSearchFilterBookList.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSearchFilterBookList.Location = new System.Drawing.Point(606, 589);
            this.btnSearchFilterBookList.Name = "btnSearchFilterBookList";
            this.btnSearchFilterBookList.Size = new System.Drawing.Size(90, 38);
            this.btnSearchFilterBookList.TabIndex = 8;
            this.btnSearchFilterBookList.Text = "Search / Filter Book List";
            this.btnSearchFilterBookList.UseVisualStyleBackColor = true;
            this.btnSearchFilterBookList.Click += new System.EventHandler(this.BtnSearchFilterBookList_Click);
            // 
            // btnModifyBook
            // 
            this.btnModifyBook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnModifyBook.Location = new System.Drawing.Point(120, 589);
            this.btnModifyBook.Name = "btnModifyBook";
            this.btnModifyBook.Size = new System.Drawing.Size(90, 38);
            this.btnModifyBook.TabIndex = 7;
            this.btnModifyBook.Text = "Modify Book Details";
            this.btnModifyBook.UseVisualStyleBackColor = true;
            this.btnModifyBook.Click += new System.EventHandler(this.BtnModifyBook_Click);
            // 
            // btnAddBook
            // 
            this.btnAddBook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAddBook.Location = new System.Drawing.Point(13, 589);
            this.btnAddBook.Name = "btnAddBook";
            this.btnAddBook.Size = new System.Drawing.Size(90, 38);
            this.btnAddBook.TabIndex = 6;
            this.btnAddBook.Text = "Add Book Details";
            this.btnAddBook.UseVisualStyleBackColor = true;
            this.btnAddBook.Click += new System.EventHandler(this.BtnAddBook_Click);
            // 
            // btnCloseForm
            // 
            this.btnCloseForm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloseForm.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCloseForm.Location = new System.Drawing.Point(1092, 589);
            this.btnCloseForm.Name = "btnCloseForm";
            this.btnCloseForm.Size = new System.Drawing.Size(90, 38);
            this.btnCloseForm.TabIndex = 5;
            this.btnCloseForm.Text = "Close Book Maintenance";
            this.btnCloseForm.UseVisualStyleBackColor = true;
            this.btnCloseForm.Click += new System.EventHandler(this.BtnCloseForm_Click);
            // 
            // btnAdjustBookQuantity
            // 
            this.btnAdjustBookQuantity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAdjustBookQuantity.Location = new System.Drawing.Point(363, 589);
            this.btnAdjustBookQuantity.Name = "btnAdjustBookQuantity";
            this.btnAdjustBookQuantity.Size = new System.Drawing.Size(90, 38);
            this.btnAdjustBookQuantity.TabIndex = 10;
            this.btnAdjustBookQuantity.Text = "Adjust Book Quantity";
            this.btnAdjustBookQuantity.UseVisualStyleBackColor = true;
            this.btnAdjustBookQuantity.Click += new System.EventHandler(this.BtnAdjustBookQuantity_Click);
            // 
            // frmBookMaintenanceForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1194, 634);
            this.ControlBox = false;
            this.Controls.Add(this.btnAdjustBookQuantity);
            this.Controls.Add(this.lvBookList);
            this.Controls.Add(this.btnSearchFilterBookList);
            this.Controls.Add(this.btnModifyBook);
            this.Controls.Add(this.btnAddBook);
            this.Controls.Add(this.btnCloseForm);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1210, 650);
            this.Name = "frmBookMaintenanceForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Book Maintenance Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmBookMaintenanceForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvBookList;
        private System.Windows.Forms.Button btnSearchFilterBookList;
        private System.Windows.Forms.Button btnModifyBook;
        private System.Windows.Forms.Button btnAddBook;
        private System.Windows.Forms.Button btnCloseForm;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Button btnAdjustBookQuantity;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader8;
    }
}