﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmBooksToIssueReserveForm : Form
    {
        private BookIssueReserveReturn addIssueReserve = new BookIssueReserveReturn(); //Creates an instance of a bookIssueReserve Class
        private DataTable bookDT;

        private ListViewItemSorter lvStudentItemSorter; //used to sort columns in student listView items
        private ListViewItemSorter lvBookItemSorter; //used to sort columns in book listView items

        private bool newReservationIssue = false; //Used to hold the click state of the Issue / Reserve button
        int noAvail = 0; //holds the number of selected presently available books
        int noReserved = 0; //holds the number of selected presently reserved books

        public frmBooksToIssueReserveForm()
        {
            InitializeComponent();

            // assign items for sorting book listView columns
            lvBookItemSorter = new ListViewItemSorter();
            this.lvBookList.ListViewItemSorter = lvBookItemSorter;

            // assign items for sorting student listView columns
            lvStudentItemSorter = new ListViewItemSorter();
            this.lvStudentList.ListViewItemSorter = lvStudentItemSorter;
        }

        private void FrmBooksToIssueReserveForm_Load(object sender, EventArgs e)
        {
            btnIssueReserveSelectedBookToStudent.Enabled = false;

            ClearStudentFilter();
            ClearBookFilter();

            if (!LoadBookList())
            {
                NoBooksToDisplay();
            }
            else
            {
                DisplayBookList();
            }
        }

        private bool LoadBookList() //Gets all books from the database
        {
            string selectQuery = addIssueReserve.FilteredBookIssueSQL();

            bookDT = ConnectionManager.GetTable(selectQuery);
            if (bookDT.Rows.Count == 0)
            {
                return false;
            }
            return true;
        }

        private void NoBooksToDisplay()
        {
            //Create a response message based upon the state of the book search/filter
            string responseMessage = "No book records to display.\n";
            if (GlobalVariables.BookFilterSet())
            {
                responseMessage += "Filter will be cleared.";
                ClearBookFilter();
                DisplayBookList();
            }
            else
            {
                responseMessage += "Please add book records.";
            }
            MessageBox.Show(responseMessage);
        }

        private void DisplayBookList() //populates the book listView
        {
            lvBookList.Items.Clear();
            for (int record = 0; record < bookDT.Rows.Count; record++)
            {
                string tempTitle = bookDT.Rows[record]["title"].ToString();
                if (GlobalVariables.BookFilterSet() &&
                    !(tempTitle.ToUpper().Contains(GlobalVariables.BookTitle.ToUpper())))
                {
                    continue;
                }
                ListViewItem listViewItem = new ListViewItem(bookDT.Rows[record]["bookID"].ToString());  //Hidden Column
                listViewItem.SubItems.Add(tempTitle);
                listViewItem.SubItems.Add(bookDT.Rows[record]["authorName"].ToString());
                listViewItem.SubItems.Add(bookDT.Rows[record]["ISBN"].ToString());
                listViewItem.SubItems.Add(bookDT.Rows[record]["noOfAvailableBooks"].ToString());
                listViewItem.SubItems.Add(bookDT.Rows[record]["noOfBorrowedBooks"].ToString());
                listViewItem.SubItems.Add(bookDT.Rows[record]["noOfReservedBooks"].ToString());
                lvBookList.Items.Add(listViewItem);
            }
            if (lvBookList.Items.Count == 0)
            {
                NoBooksToDisplay();
            }
        }

        private void DisplayStudentList()
        {
            //This function displays reserved book students or other students based upon existing reserves or
            // newReserveIssue state (this is set during button click event)

            lvStudentList.Items.Clear();
            if (lvBookList.SelectedItems.Count == 0)
            {
                return; //No books selected - do not display students
            }

            //If the book has reserves only display those students
            string selectQuery = "";
            int numberOfReserved = int.Parse(lvBookList.SelectedItems[0].SubItems[6].Text);

            //#reserved > 0 and newReserveIssue not true - display reserved students only
            if (noReserved > 0 && !newReservationIssue)
            {
                selectQuery = "SELECT Student.studentID, Student.firstName, Student.lastName, Student.contactNo, reserveDate " +
                    "FROM BookReserve LEFT JOIN Student ON BookReserve.StudentID = Student.studentID " +
                    "WHERE BookReserve.bookID = " + addIssueReserve.BookID;
                if (GlobalVariables.StudentFilterSet())
                {
                    selectQuery += " AND Student.lastName LIKE ('%" + GlobalVariables.StudentLastName + "%')";
                }
                selectQuery += " ORDER BY reserveDate ASC";
                lblStudentList.Text = "Student List (Reserved):";
            }
            else
            {
                //Display everyone if newReserveIssue is true or no existing reservations or when no books available
                //SQL query to gather all other students (includes those where issued and no return)
                //Filter those with no returns later.
                selectQuery = "SELECT DISTINCT Student.studentID, BookReserve.studentID AS tempStudentID" +
                    ", firstName, lastName, contactNo, BookReserve.reserveDate, BookIssue.issueID as biIssueID" +
                    ", BookReturn.issueID as brIssueID FROM Student " +
                    "LEFT JOIN BookReserve ON Student.studentID = BookReserve.studentID " +
                    "AND BookReserve.bookID = " + addIssueReserve.BookID +
                    " LEFT JOIN BookIssue ON Student.studentID = BookIssue.studentID " +
                    "AND BookIssue.bookID = " + addIssueReserve.BookID +
                    " LEFT JOIN BookReturn ON BookIssue.issueID = BookReturn.issueID ";

                //Working sql function
                //selectQuery = "SELECT Student.studentID, firstName, lastName, contactNo, BookReserve.reserveDate " +
                //    "FROM Student LEFT JOIN BookReserve ON Student.studentID = BookReserve.studentID " +
                //    "AND BookReserve.bookID = " + addIssueReserve.BookID + "";
                if (GlobalVariables.StudentFilterSet())
                {
                    selectQuery += " WHERE lastName LIKE ('%" + GlobalVariables.StudentLastName + "%')";
                }
                selectQuery += " ORDER BY lastName";
                lblStudentList.Text = "Student List (Non-Reserved):";
            }

            string tempBookIssuedID = "", tempBookReturnedID = "";

            DataTable studentDT = ConnectionManager.GetTable(selectQuery);
            //moves through the studentDT (DataTable) and adds the records to the listView
            for (int record = 0; record < studentDT.Rows.Count; record++)
            {

                string tempDate = studentDT.Rows[record]["reserveDate"].ToString();
                if (newReservationIssue) //dataTable only has these rows when displaying books without reserves
                {
                    tempBookIssuedID = studentDT.Rows[record]["biIssueID"].ToString();
                    tempBookReturnedID = studentDT.Rows[record]["brIssueID"].ToString();
                }

                //there was an issue where multiple reservations and deletion of these were 
                //showing the existing reservation records (multiples) - tried to fix it using DISTINCT but still showing
                //This now only shows the one record - I read up on it - maybe something to do with the multiple joins
                if (record > 0 && studentDT.Rows[record]["studentID"].ToString()
                    .Equals(studentDT.Rows[record - 1]["studentID"].ToString()))
                {
                    continue;
                }
                //if NOT a new reserve and 'blank' reserve date
                //or there is an issue without a matching return
                if ((newReservationIssue && tempDate.Length > 0)
                    || (tempBookIssuedID.Length > 0 && !tempBookIssuedID.Equals(tempBookReturnedID)))
                {
                    //skip when a valid reservation date and when newReservationIssue is true (dont display reserved student records)
                    continue;
                }

                // new reserve - display only those students that haven't a reserve 
                // (eg date is blank from no record on join) OR display those with a valid reservation date (not blank)
                //the DataTable is filled based upon the query
                string tempLastName = studentDT.Rows[record]["lastName"].ToString();
                ListViewItem listViewItem = new ListViewItem(studentDT.Rows[record]["studentID"].ToString());
                listViewItem.SubItems.Add(studentDT.Rows[record]["firstName"].ToString());
                listViewItem.SubItems.Add(studentDT.Rows[record]["lastName"].ToString());
                listViewItem.SubItems.Add(studentDT.Rows[record]["contactNo"].ToString());
                if (noReserved > 0 && !newReservationIssue)
                { //where a reserve record is displayed in the listView - the reserved date is shown
                    tempDate = studentDT.Rows[record]["reserveDate"].ToString();
                    listViewItem.SubItems.Add(tempDate.Substring(0, 10));
                }
                lvStudentList.Items.Add(listViewItem);
            }
            lvStudentList.Enabled = true; //re-enables the listView in case a student was selected previously

            if (lvStudentList.Items.Count == 0)
            {
                NoStudentsToDisplay();
            }
        }

        private void NoStudentsToDisplay()
        {
            //Create a response message based upon the state of the student search/filter
            string responseMessage = "No student records to display.\n";
            if (GlobalVariables.StudentFilterSet())
            {
                responseMessage += "Filter will be cleared.";
                ClearStudentFilter();
                DisplayStudentList();
            }
            else
            {
                responseMessage += "Please add student records.";
            }
            MessageBox.Show(responseMessage);
        }

        private void BtnCancelReturn_Click(object sender, EventArgs e)
        {
            //Clears the student listView and displays the book list again without filters
            if (lvBookList.SelectedItems.Count > 0)
            {
                // Clears the student list (if there were any records)
                lvStudentList.Items.Clear();

                // Clears Book Filter - local and global
                ClearBookFilter();

                // Clears Student Filter - local and global
                ClearStudentFilter();

                DisplayBookList(); //Should only clear the listView as no books selected

                //Set button states and text
                btnIssueReserveSelectedBookToStudent.Text = "Issue / Reserve Book to Student";
                btnIssueReserveSelectedBookToStudent.Enabled = false;
                newReservationIssue = false;

                lblStudentList.Text = "Student List:";
                return;
            }
            else
            {
                // if no books selected and cancel button clicked, user exits the form
                // on closing the form, this clears the Student Global Variables
                CloseForm();
            }
        }

        private void CloseForm()
        {
            ClearStudentFilter();
            ClearBookFilter();
            this.Close();
        }

        private void ClearStudentFilter()
        {
            txtLastNameFilter.Text = "";
            GlobalVariables.ClearStudentFilter();
        }

        private void ClearBookFilter()
        {
            txtTitleFilter.Text = "";
            GlobalVariables.ClearBookFilter();
        }

        private void TxtTitleFilter_TextChanged(object sender, EventArgs e)
        {
            //Where global filter not set and filter < 3 chars - doesn't require access to database
            if (txtTitleFilter.TextLength < 3 && !GlobalVariables.BookFilterSet())
            {
                return;
            }
            else if (txtTitleFilter.TextLength > 2)
            {
                GlobalVariables.BookTitle = txtTitleFilter.Text;
            }
            else if (GlobalVariables.BookFilterSet())
            {
                ClearBookFilter();
            }
            DisplayBookList();
        }

        private void TxtLastNameFilter_TextChanged(object sender, EventArgs e)
        {
            //Where no global filter set and filter is < 3 chars - doesn't require access to database
            if (txtLastNameFilter.TextLength < 3 && !GlobalVariables.StudentFilterSet())
            {
                return;
            }
            else if (txtLastNameFilter.TextLength > 2)
            {
                GlobalVariables.StudentLastName = txtLastNameFilter.Text;
            }
            else if (GlobalVariables.StudentFilterSet())
            {
                GlobalVariables.ClearStudentFilter();
            }
            DisplayStudentList();
        }

        private void LvBookList_SelectedIndexChanged(object sender, EventArgs e)
        {
            //This function determines the state of the button and text based upon available books
            // and/or reserved books (Stage 1)

            newReservationIssue = false; //ensure the button state test is reset to not pushed
            if (lvBookList.SelectedItems.Count > 0) //A book has been selected from the list
            {
                addIssueReserve.BookID = int.Parse(lvBookList.SelectedItems[0].Text);
                noAvail = int.Parse(lvBookList.SelectedItems[0].SubItems[4].Text); //# Books Available
                noReserved = int.Parse(lvBookList.SelectedItems[0].SubItems[6].Text); // # Books reserved

                // This could be displaying the reserved students or all students
                if (noAvail - noReserved < 1) //Where books can only be issued to reserved students or a new reservation
                {
                    // Button to only allow new reservations - re-test if a student selected or button pressed
                    btnIssueReserveSelectedBookToStudent.Text = "New Book Reservation";
                    if (noReserved > 0)
                    {
                        btnIssueReserveSelectedBookToStudent.Enabled = true; //Shows when existing reserves
                    }
                    else
                    {
                        newReservationIssue = true; //Determines this will be a newIssue therefore display non reserves students
                    }
                }
                else if ((noAvail - noReserved) > 0)
                {
                    if (noReserved > 0)
                    {
                        // Button will allow issue to student as more available than reserved - re-test if student selected or button pressed
                        btnIssueReserveSelectedBookToStudent.Text = "Book Issue to another Student";
                        btnIssueReserveSelectedBookToStudent.Enabled = true;
                    }
                    else
                    {
                        //When no reserves for the book and spare books - leaves button disabled until student selected
                        ButtonIssueBookToStudent();
                        newReservationIssue = true; //Treat as a new issue of a book
                    }
                }
            }
            DisplayStudentList(); //Display student screen
        }

        private void LvStudentList_SelectedIndexChanged(object sender, EventArgs e)
        {
            //once student selected - cannot select another one - proceed or cancel
            lvStudentList.Enabled = false;

            //This is the stage where either existing student reserved book records or other student records are displayed
            //and selected (Stage 3)

            //Check to see that book and student items selected
            if (lvBookList.SelectedItems.Count > 0 && lvStudentList.SelectedItems.Count > 0)
            {
                //where no books are spare and button has been clicked after reserved student selection
                if (noAvail > 0 && !newReservationIssue)
                {
                    //Option for selected reserve student to be issued a book when book in library
                    ButtonIssueBookToStudent();
                    btnIssueReserveSelectedBookToStudent.Enabled = true; //Allow clicking if #availablebooks > 0
                }
                //where no books are spare and button has already been pressed before student selection
                else if ((noAvail - noReserved) < 1 && newReservationIssue)
                {
                    btnIssueReserveSelectedBookToStudent.Text = "Reserve Book for Student";
                    btnIssueReserveSelectedBookToStudent.Enabled = true;
                }
                else
                    if ((noAvail - noReserved) > 0) //Possibility of reserved books but some spare - issue to other student
                {
                    ButtonIssueBookToStudent();
                    //Check if previous reserve and delete the reservation
                    btnIssueReserveSelectedBookToStudent.Enabled = true; //Allow clicking if #availablebooks > 0
                }
                else
                {
                    ButtonIssueBookToStudent();
                    //Doesnt allow clicking if no book spare
                    btnIssueReserveSelectedBookToStudent.Enabled = false;
                }
            }
            //Book selected and Button pressed with no student selected as yet.
            //function to allow display of non-reserved student list
            else if (lvBookList.SelectedItems.Count > 0 && lvStudentList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Test of process - shouldn't be displayed");
                newReservationIssue = true;
                DisplayStudentList();
            }
        }

        private void ButtonIssueBookToStudent()
        {
            btnIssueReserveSelectedBookToStudent.Text = "Issue Book to Student";
        }

        private void BtnIssueReserveSelectedBookToStudent_Click(object sender, EventArgs e)
        {
            // Multiple states and options based upon: -
            // lvBookList selected, #Available, #Reserved, lvStudent selected && newReservation state

            //BookList - selected / StudentList - not selected / existingIssueNewReserve == false
            // change state to newReserved = true - Display all students 
            //Stage 2 - if button pressed before student selected
            if (lvBookList.SelectedItems.Count > 0 && lvStudentList.SelectedItems.Count == 0
                && !newReservationIssue)
            {
                //Button Clicked - book selected - student not selected
                newReservationIssue = true;
                btnIssueReserveSelectedBookToStudent.Enabled = false;
                DisplayStudentList();
                return;
            }

            //Stage 4 - save the selected book / student
            //BookList - selected / StudentList - selected / newReserve == false
            // if(available > 0) issue book to selected student
            // (Button should not be displayed if there are no available books)
            addIssueReserve.StudentID = int.Parse(lvStudentList.SelectedItems[0].Text); //StudentID
            addIssueReserve.LibrarianID = int.Parse(System.Environment.GetEnvironmentVariable("librarianID"));
            string bookTitle = lvBookList.SelectedItems[0].SubItems[1].Text; //to pass to confirmation form
            string studentName = lvStudentList.SelectedItems[0].SubItems[1].Text + " "
                + lvStudentList.SelectedItems[0].SubItems[2].Text; //to pass to the confirmation form

            if (lvBookList.SelectedItems.Count > 0 && lvStudentList.SelectedItems.Count > 0)
            {
                //Button Clicked - book selected - student selected - may/may not have an existing reservation
                //create a new book issue for selected student
                //where there are books available and a student book reserve has been selected 
                //or where there are spare books and other students have been selected
                if ((noAvail > 0 && !newReservationIssue) || (noAvail - noReserved) > 0)
                {
                    frmBookIssueConfirmSave subForm = new frmBookIssueConfirmSave(addIssueReserve, true
                        , bookTitle, studentName); //true is an issue book layout
                    DialogResult result = subForm.ShowDialog();
                    if (result == DialogResult.Yes)
                    {
                        addIssueReserve.BookIssueAdd(); // Save book and no check for reservation
                    }
                }
                //(if none availalbe) new book reservation record for the selected student
                else
                {
                    frmBookIssueConfirmSave subForm = new frmBookIssueConfirmSave(addIssueReserve, false
                        , bookTitle, studentName); //false is a book reservation layout
                    DialogResult result = subForm.ShowDialog();
                    if (result == DialogResult.Yes)
                    {
                        addIssueReserve.BookReserveAdd();
                    }
                }
            }
            //Once a save have been completed, then close the form
            CloseForm();
        }

        private void LvBookList_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // This section of code handles the sorting of listView columns
            // General code structure was taken from links highlighted in ListViewItemSorter.cs and modified to suit
            int testClickColumn = e.Column;

            switch (testClickColumn)
            {
                case 4: //no sort on column 4, 5 or 6
                case 5:
                case 6:
                    return;
                default:
                    //checks performed within ListViewItemSorter class
                    lvBookItemSorter.checkPreviousOrder(testClickColumn);

                    // Perform the sort with these new sort options.
                    this.lvBookList.Sort();
                    return;
            }
        }

        private void LvStudentList_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // This section of code handles the sorting of listView columns
            // General code structure was taken from links highlighted in ListViewItemSorter.cs and modified to suit
            int testClickColumn = e.Column;

            switch (testClickColumn)
            {
                case 3: //no sort on column 3 or 4
                case 4:
                    return;
                default:
                    //checks performed within ListViewItemSorter class
                    lvStudentItemSorter.checkPreviousOrder(testClickColumn);

                    // Perform the sort with these new sort options.
                    this.lvStudentList.Sort();
                    return;
            }
        }
    }
}
