﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmVerifyUser : Form
    {
        int loginAttemps = 0;

        public frmVerifyUser()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //https://stackoverflow.com/questions/5233502/how-to-return-a-value-from-a-form-in-c
            this.DialogResult = DialogResult.No;
            this.Close();
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            if (ValidateInput() == false)
            {
                //https://stackoverflow.com/questions/5233502/how-to-return-a-value-from-a-form-in-c
                this.DialogResult = DialogResult.No;
                this.Close();
            }
            DataTable dataTable = ConnectionManager.GetTable("SELECT * FROM Librarian WHERE userName='" 
                + txtUserName.Text + "' and password='" + txtPassword.Text + "' ");
            if (dataTable != null && dataTable.Rows.Count != 0)
            {
                //https://stackoverflow.com/questions/5233502/how-to-return-a-value-from-a-form-in-c
                this.DialogResult = DialogResult.Yes;
                this.Close();
            }
            else
            {
                loginAttemps += 1;
                if (loginAttemps > 2)
                {
                    MessageBox.Show("Too many attempts. Program is shutting down.");
                    this.Close();
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show("Invalid user name or password, try again.");
                    txtUserName.Clear();
                    txtPassword.Clear();
                    txtUserName.Focus();
                }
            }                
        }
        private bool ValidateInput()
        {
            if(txtUserName.TextLength > 0 && !GlobalVariables.TestFilterIsValid(txtUserName.Text))
            {
                MessageBox.Show("User name can not contain special characters");
                txtUserName.Text = "";
                txtUserName.Focus();
                return false;
            }
            if(txtPassword.Text.Trim().Contains(" "))
            {
                MessageBox.Show("Password is invalid. Please try again.");
                txtPassword.Text = "";
                txtPassword.Focus();
                return false;
            }
            if (txtUserName.Text == "")
            {
                MessageBox.Show("User name can not be null.");
                txtUserName.Focus();
                return false ;
            }
            if (txtPassword.Text == "")
            {
                MessageBox.Show("Password can not be null.");
                txtPassword.Focus();
                return false ;
            }
            return true;
        }
    }
}
