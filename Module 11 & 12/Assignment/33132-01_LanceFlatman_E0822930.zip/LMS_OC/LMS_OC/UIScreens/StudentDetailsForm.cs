﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmStudentDetailsForm : Form
    {
        //This form allows Add and Modify of student information. Determined by the stored StudentID variable
        Student student = new Student();
        public void SetStudentID(int selectedRecord) //Method used to specify the form type
        {
            student.StudentID = selectedRecord;
        }

        public frmStudentDetailsForm()
        {
            InitializeComponent();
        }

        private void BtnCloseForm_Click(object sender, EventArgs e)
        {
            CloseForm();
        }

        private void StudentDetailsForm_Load(object sender, EventArgs e)
        {
            //This determines which form heading is displayed and items are accessible / relevant labels display 
            if (student.StudentID == 0)
            {
                this.Text = "Add Student Details Form";
                txtFine.ReadOnly = false;
                txtFine.Enabled = true;
                txtFine.TabStop = true;
            }
            else
            {
                this.Text = "Modify Student Details Form";
                btnAddModifyRecord.Text = "Edit Student Record";

                //If a single student record for the studentID is found the information is loaded 
                //into student and then copied to the form
                DataTable studentDT = ConnectionManager.GetTable("SELECT * FROM Student WHERE studentID=" + student.StudentID + "");
                if (studentDT.Rows.Count == 0)
                {
                    //This code should not run as the record was selected from the listView item on the maintenance screen
                    MessageBox.Show("Student with student ID " + student.StudentID + "doesn't exist");
                    ResetTextBoxes();
                }
                else
                {
                    txtStudentID.Text = studentDT.Rows[0]["studentID"].ToString();
                    txtFirstName.Text = studentDT.Rows[0]["firstName"].ToString();
                    txtLastName.Text = studentDT.Rows[0]["lastName"].ToString();
                    txtAddress1.Text = studentDT.Rows[0]["address1"].ToString();
                    txtAddress2.Text = studentDT.Rows[0]["address2"].ToString();
                    txtSuburb.Text = studentDT.Rows[0]["suburb"].ToString();
                    cbState.Text = studentDT.Rows[0]["state"].ToString();
                    txtPostCode.Text = studentDT.Rows[0]["postCode"].ToString();

                    //interim process to display Fine as 2 decimal places
                    decimal tempFine = decimal.Parse(studentDT.Rows[0]["fine"].ToString());
                    txtFine.Text = tempFine.ToString("0.00");

                    txtEmail.Text = studentDT.Rows[0]["email"].ToString();
                    txtContactNo.Text = studentDT.Rows[0]["contactNo"].ToString();
                }
            }
        }

        private void BtnCancelReturn_Click(object sender, EventArgs e)
        {
            CloseForm();
        }

        private void BtnAddModifyRecord_Click(object sender, EventArgs e)
        {
            //Once the information has been checked, this is updated into the student object and saved into the database
            if (CheckFields()) 
            {
                student.FirstName = txtFirstName.Text;
                student.LastName = txtLastName.Text;
                student.Address1 = txtAddress1.Text;
                student.Address2 = txtAddress2.Text;
                student.Suburb = txtSuburb.Text;
                student.State = cbState.Text;
                student.PostCode = int.Parse(txtPostCode.Text);
                if (txtFine.Text.Length == 0)
                {
                    student.Fine = 0.0d;
                }
                else
                {
                    student.Fine = double.Parse(txtFine.Text);
                }

                student.ContactNumber = txtContactNo.Text;
                student.Email = txtEmail.Text;

                int recordSaved = student.StudentAddModify();
                if (recordSaved == 0)
                {
                    MessageBox.Show("Update Operation failed. Check the values provided and try again.");
                }
                else
                {
                    if (student.StudentID == 0)
                    {
                        MessageBox.Show("Student added successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Student updated successfully.");
                    }
                }
                CloseForm();
            }
        }

        private string errorMessage = ""; //Used for error messages when checking fields
        private bool CheckFields()
        {
            errorMessage = "";
            CheckString(txtFirstName.Text, "First Name");
            CheckString(txtLastName.Text, "Last Name");
            CheckString(txtAddress1.Text, "Address 1");
            CheckString(txtSuburb.Text, "Suburb");
            CheckString(cbState.Text, "State");
            if (CheckString(txtPostCode.Text, "Post code"))
            {
                try
                {
                    if (int.Parse(txtPostCode.Text.Trim()) > 9999)
                    {
                        errorMessage += "  Post code is incorrect\n";
                    }
                }
                catch
                {
                    errorMessage += "  Post code must be numerical\n";
                }
            }

            //ContactNo can be blank but checks for general formatting ( ) and correct length
            if (txtContactNo.Text.Length > 0)
            {
                if (txtContactNo.Text.Length > 14 || !txtContactNo.Text.Contains("(") || !txtContactNo.Text.Contains(")") 
                    || txtContactNo.Text.Length < 14)
                {
                    errorMessage += "  Phone number is incorrect. Format is: (##) #### ####\n";
                }
            }

            //email can be blank - this checks for general format of @ . and no spaces
            if (txtEmail.Text.Length > 0)
            {
                if (!txtEmail.Text.Contains("@") || !txtEmail.Text.Contains(".") || txtEmail.Text.Contains(" "))
                {
                    errorMessage += "  Email address is formatted incorrectly\n";
                }
            }

            if (errorMessage.Length > 0) //field information errors
            {
                MessageBox.Show("This information needs to be corrected:\n" + errorMessage);
                return false;
            }
            return true; //no field information errors
        }

        private bool CheckString(string item, string name)
        {
            if(item.Length == 0)
            {
                errorMessage += "  " + name + " cannot be blank\n";
                return false;
            }
            return true;
        }

        private void ResetTextBoxes()
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtAddress1.Text = "";
            txtAddress2.Text = "";
            txtSuburb.Text = "";
            cbState.Text = "";
            txtPostCode.Text = "";
            txtFine.Text = "";
            txtContactNo.Text = "";
            txtEmail.Text = "";
        }

        private void TxtContactNo_Leave(object sender, EventArgs e)
        {
            //Allows the user to enter a full phone number and the program converts it to the standard format
            if (txtContactNo.Text.Length == 10)
            {
                string holdContactNo = "";
                for (int i = 0; i < txtContactNo.Text.Length; i++)
                {
                    switch (i)
                    {
                        case 0:
                            holdContactNo += "(" + txtContactNo.Text.Substring(i, 1);
                            break;
                        case 2:
                            holdContactNo += ") " + txtContactNo.Text.Substring(i, 1);
                            break;
                        case 6:
                            holdContactNo += " " + txtContactNo.Text.Substring(i, 1);
                            break;
                        default:
                            holdContactNo += txtContactNo.Text.Substring(i, 1);
                            break;
                    }
                }
                txtContactNo.Text = holdContactNo;
            }
        }

        private void TxtFine_Leave(object sender, EventArgs e)
        {
            //checks the Fine information and changes the format to currency if entered incorrectly. Sets to 0.00 if incorrect
            if (txtFine.Text.Length > 0)
            {
                try
                {
                    decimal tempFine = decimal.Parse(txtFine.Text);
                    txtFine.Text = tempFine.ToString("0.00");
                }
                catch
                {
                    txtFine.Text = "0.00";
                }
            }
        }

        private void CloseForm()
        {
            GlobalVariables.ClearStudentFilter();
            this.Close();
        }
    }
}
