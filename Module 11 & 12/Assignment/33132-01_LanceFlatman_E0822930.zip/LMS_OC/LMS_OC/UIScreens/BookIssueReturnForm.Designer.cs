﻿namespace LMS_OC.UIScreens
{
    partial class frmBookIssueReturn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIssueReturnDetails = new System.Windows.Forms.Label();
            this.lblStudentID = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.lblReturnDate = new System.Windows.Forms.Label();
            this.lblFineAmount = new System.Windows.Forms.Label();
            this.dtpReturnDate = new System.Windows.Forms.DateTimePicker();
            this.txtFineAmount = new System.Windows.Forms.TextBox();
            this.gbReturnDetails = new System.Windows.Forms.GroupBox();
            this.lblDaysOverdue = new System.Windows.Forms.Label();
            this.lblExpectedReturn = new System.Windows.Forms.Label();
            this.txtExpectedReturnDate = new System.Windows.Forms.TextBox();
            this.txtDaysOverdue = new System.Windows.Forms.TextBox();
            this.gbOfficeUse = new System.Windows.Forms.GroupBox();
            this.txtStudentName = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirmReturn = new System.Windows.Forms.Button();
            this.gbReturnDetails.SuspendLayout();
            this.gbOfficeUse.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblIssueReturnDetails
            // 
            this.lblIssueReturnDetails.AutoSize = true;
            this.lblIssueReturnDetails.Location = new System.Drawing.Point(9, 109);
            this.lblIssueReturnDetails.Name = "lblIssueReturnDetails";
            this.lblIssueReturnDetails.Size = new System.Drawing.Size(275, 13);
            this.lblIssueReturnDetails.TabIndex = 0;
            this.lblIssueReturnDetails.Text = "Please enter Issued Book Return information and confirm";
            // 
            // lblStudentID
            // 
            this.lblStudentID.AutoSize = true;
            this.lblStudentID.Location = new System.Drawing.Point(10, 21);
            this.lblStudentID.Name = "lblStudentID";
            this.lblStudentID.Size = new System.Drawing.Size(64, 13);
            this.lblStudentID.TabIndex = 1;
            this.lblStudentID.Text = "Student ID :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Student Name :";
            // 
            // txtStudentID
            // 
            this.txtStudentID.Enabled = false;
            this.txtStudentID.Location = new System.Drawing.Point(97, 18);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.ReadOnly = true;
            this.txtStudentID.Size = new System.Drawing.Size(81, 20);
            this.txtStudentID.TabIndex = 3;
            // 
            // lblReturnDate
            // 
            this.lblReturnDate.AutoSize = true;
            this.lblReturnDate.Location = new System.Drawing.Point(9, 23);
            this.lblReturnDate.Name = "lblReturnDate";
            this.lblReturnDate.Size = new System.Drawing.Size(71, 13);
            this.lblReturnDate.TabIndex = 2;
            this.lblReturnDate.Text = "Return Date :";
            // 
            // lblFineAmount
            // 
            this.lblFineAmount.AutoSize = true;
            this.lblFineAmount.Location = new System.Drawing.Point(10, 53);
            this.lblFineAmount.Name = "lblFineAmount";
            this.lblFineAmount.Size = new System.Drawing.Size(84, 13);
            this.lblFineAmount.TabIndex = 2;
            this.lblFineAmount.Text = "Fine Amount :  $";
            // 
            // dtpReturnDate
            // 
            this.dtpReturnDate.CustomFormat = "dd/MM/yyyy";
            this.dtpReturnDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpReturnDate.Location = new System.Drawing.Point(97, 20);
            this.dtpReturnDate.Name = "dtpReturnDate";
            this.dtpReturnDate.Size = new System.Drawing.Size(96, 20);
            this.dtpReturnDate.TabIndex = 0;
            this.dtpReturnDate.Value = new System.DateTime(2019, 1, 1, 0, 0, 0, 0);
            this.dtpReturnDate.ValueChanged += new System.EventHandler(this.DtpReturnDate_ValueChanged);
            // 
            // txtFineAmount
            // 
            this.txtFineAmount.Enabled = false;
            this.txtFineAmount.Location = new System.Drawing.Point(97, 50);
            this.txtFineAmount.Name = "txtFineAmount";
            this.txtFineAmount.ReadOnly = true;
            this.txtFineAmount.Size = new System.Drawing.Size(96, 20);
            this.txtFineAmount.TabIndex = 1;
            this.txtFineAmount.Leave += new System.EventHandler(this.TxtFineAmount_Leave);
            // 
            // gbReturnDetails
            // 
            this.gbReturnDetails.Controls.Add(this.lblDaysOverdue);
            this.gbReturnDetails.Controls.Add(this.lblExpectedReturn);
            this.gbReturnDetails.Controls.Add(this.lblReturnDate);
            this.gbReturnDetails.Controls.Add(this.txtExpectedReturnDate);
            this.gbReturnDetails.Controls.Add(this.txtDaysOverdue);
            this.gbReturnDetails.Controls.Add(this.dtpReturnDate);
            this.gbReturnDetails.Controls.Add(this.lblFineAmount);
            this.gbReturnDetails.Controls.Add(this.txtFineAmount);
            this.gbReturnDetails.Location = new System.Drawing.Point(12, 122);
            this.gbReturnDetails.Name = "gbReturnDetails";
            this.gbReturnDetails.Size = new System.Drawing.Size(410, 88);
            this.gbReturnDetails.TabIndex = 0;
            this.gbReturnDetails.TabStop = false;
            // 
            // lblDaysOverdue
            // 
            this.lblDaysOverdue.AutoSize = true;
            this.lblDaysOverdue.Location = new System.Drawing.Point(213, 53);
            this.lblDaysOverdue.Name = "lblDaysOverdue";
            this.lblDaysOverdue.Size = new System.Drawing.Size(81, 13);
            this.lblDaysOverdue.TabIndex = 1;
            this.lblDaysOverdue.Text = "Days Overdue :";
            // 
            // lblExpectedReturn
            // 
            this.lblExpectedReturn.AutoSize = true;
            this.lblExpectedReturn.Location = new System.Drawing.Point(213, 23);
            this.lblExpectedReturn.Name = "lblExpectedReturn";
            this.lblExpectedReturn.Size = new System.Drawing.Size(93, 13);
            this.lblExpectedReturn.TabIndex = 2;
            this.lblExpectedReturn.Text = "Expected Return :";
            // 
            // txtExpectedReturnDate
            // 
            this.txtExpectedReturnDate.Enabled = false;
            this.txtExpectedReturnDate.Location = new System.Drawing.Point(312, 20);
            this.txtExpectedReturnDate.Name = "txtExpectedReturnDate";
            this.txtExpectedReturnDate.ReadOnly = true;
            this.txtExpectedReturnDate.Size = new System.Drawing.Size(81, 20);
            this.txtExpectedReturnDate.TabIndex = 3;
            // 
            // txtDaysOverdue
            // 
            this.txtDaysOverdue.Enabled = false;
            this.txtDaysOverdue.Location = new System.Drawing.Point(312, 50);
            this.txtDaysOverdue.Name = "txtDaysOverdue";
            this.txtDaysOverdue.ReadOnly = true;
            this.txtDaysOverdue.Size = new System.Drawing.Size(81, 20);
            this.txtDaysOverdue.TabIndex = 3;
            // 
            // gbOfficeUse
            // 
            this.gbOfficeUse.Controls.Add(this.lblStudentID);
            this.gbOfficeUse.Controls.Add(this.label3);
            this.gbOfficeUse.Controls.Add(this.txtStudentName);
            this.gbOfficeUse.Controls.Add(this.txtStudentID);
            this.gbOfficeUse.Location = new System.Drawing.Point(12, 12);
            this.gbOfficeUse.Name = "gbOfficeUse";
            this.gbOfficeUse.Size = new System.Drawing.Size(410, 83);
            this.gbOfficeUse.TabIndex = 6;
            this.gbOfficeUse.TabStop = false;
            this.gbOfficeUse.Text = "Office Use";
            // 
            // txtStudentName
            // 
            this.txtStudentName.Enabled = false;
            this.txtStudentName.Location = new System.Drawing.Point(97, 48);
            this.txtStudentName.Name = "txtStudentName";
            this.txtStudentName.ReadOnly = true;
            this.txtStudentName.Size = new System.Drawing.Size(296, 20);
            this.txtStudentName.TabIndex = 3;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(332, 216);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 38);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // btnConfirmReturn
            // 
            this.btnConfirmReturn.Location = new System.Drawing.Point(12, 216);
            this.btnConfirmReturn.Name = "btnConfirmReturn";
            this.btnConfirmReturn.Size = new System.Drawing.Size(90, 38);
            this.btnConfirmReturn.TabIndex = 1;
            this.btnConfirmReturn.Text = "Confirm Book Return";
            this.btnConfirmReturn.UseVisualStyleBackColor = true;
            this.btnConfirmReturn.Click += new System.EventHandler(this.BtnConfirmReturn_Click);
            // 
            // frmBookIssueReturn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 267);
            this.ControlBox = false;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfirmReturn);
            this.Controls.Add(this.gbOfficeUse);
            this.Controls.Add(this.gbReturnDetails);
            this.Controls.Add(this.lblIssueReturnDetails);
            this.MaximumSize = new System.Drawing.Size(448, 306);
            this.MinimumSize = new System.Drawing.Size(448, 306);
            this.Name = "frmBookIssueReturn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Issued Book Return Form";
            this.Load += new System.EventHandler(this.FrmBookIssueReturn_Load);
            this.gbReturnDetails.ResumeLayout(false);
            this.gbReturnDetails.PerformLayout();
            this.gbOfficeUse.ResumeLayout(false);
            this.gbOfficeUse.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblIssueReturnDetails;
        private System.Windows.Forms.Label lblStudentID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.Label lblReturnDate;
        private System.Windows.Forms.Label lblFineAmount;
        private System.Windows.Forms.DateTimePicker dtpReturnDate;
        private System.Windows.Forms.TextBox txtFineAmount;
        private System.Windows.Forms.GroupBox gbReturnDetails;
        private System.Windows.Forms.GroupBox gbOfficeUse;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirmReturn;
        private System.Windows.Forms.TextBox txtStudentName;
        private System.Windows.Forms.Label lblDaysOverdue;
        private System.Windows.Forms.Label lblExpectedReturn;
        private System.Windows.Forms.TextBox txtExpectedReturnDate;
        private System.Windows.Forms.TextBox txtDaysOverdue;
    }
}