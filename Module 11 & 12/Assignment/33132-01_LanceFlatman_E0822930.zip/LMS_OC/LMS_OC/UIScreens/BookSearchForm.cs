﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmBookSearchForm : Form
    {
        public frmBookSearchForm()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnSetFilter_Click(object sender, EventArgs e)
        {
            //Checks for valid information e.g. does not allow special characters (minimise SQLinjection)
            if ((txtBookTitle.TextLength > 0 && !GlobalVariables.TestFilterIsValid(txtBookTitle.Text))
                || (txtAuthorName.TextLength > 0 && !GlobalVariables.TestFilterIsValid(txtAuthorName.Text)))
            {
                MessageBox.Show("Characters or Numbers only for valid filter conditions.");
                txtBookTitle.Text = "";
                txtAuthorName.Text = "";
                txtBookTitle.Focus();
                return;
            }

            GlobalVariables.BookTitle = txtBookTitle.Text.Trim();
            GlobalVariables.AuthorName = txtAuthorName.Text.Trim();
            this.Close();

        }
    }
}
