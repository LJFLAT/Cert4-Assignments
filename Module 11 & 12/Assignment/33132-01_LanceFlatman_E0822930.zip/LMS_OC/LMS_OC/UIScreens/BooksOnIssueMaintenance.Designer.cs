﻿namespace LMS_OC.UIScreens
{
    partial class frmBooksOnIssueForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvBooksOnIssueList = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSearchFilterBooksOnIssue = new System.Windows.Forms.Button();
            this.btnBookReturnCancelReserve = new System.Windows.Forms.Button();
            this.btnIssueReserveBooks = new System.Windows.Forms.Button();
            this.btnCloseForm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvBooksOnIssueList
            // 
            this.lvBooksOnIssueList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lvBooksOnIssueList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader2,
            this.columnHeader1,
            this.columnHeader3,
            this.columnHeader6,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader7});
            this.lvBooksOnIssueList.FullRowSelect = true;
            this.lvBooksOnIssueList.GridLines = true;
            this.lvBooksOnIssueList.HideSelection = false;
            this.lvBooksOnIssueList.Location = new System.Drawing.Point(13, 10);
            this.lvBooksOnIssueList.MultiSelect = false;
            this.lvBooksOnIssueList.Name = "lvBooksOnIssueList";
            this.lvBooksOnIssueList.Size = new System.Drawing.Size(1169, 573);
            this.lvBooksOnIssueList.TabIndex = 9;
            this.lvBooksOnIssueList.UseCompatibleStateImageBehavior = false;
            this.lvBooksOnIssueList.View = System.Windows.Forms.View.Details;
            this.lvBooksOnIssueList.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.LvBooksOnIssueList_ColumnClick);
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "BookID";
            this.columnHeader8.Width = 0;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Title";
            this.columnHeader2.Width = 180;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Author Name";
            this.columnHeader1.Width = 150;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "ISBN";
            this.columnHeader3.Width = 110;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Next Return";
            this.columnHeader6.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "# Available";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 70;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "# Issued";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 70;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "# Reserved";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 70;
            // 
            // btnSearchFilterBooksOnIssue
            // 
            this.btnSearchFilterBooksOnIssue.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSearchFilterBooksOnIssue.Location = new System.Drawing.Point(622, 589);
            this.btnSearchFilterBooksOnIssue.Name = "btnSearchFilterBooksOnIssue";
            this.btnSearchFilterBooksOnIssue.Size = new System.Drawing.Size(90, 38);
            this.btnSearchFilterBooksOnIssue.TabIndex = 8;
            this.btnSearchFilterBooksOnIssue.Text = "Search / Filter Books on Issue";
            this.btnSearchFilterBooksOnIssue.UseVisualStyleBackColor = true;
            this.btnSearchFilterBooksOnIssue.Click += new System.EventHandler(this.BtnSearchFilterBooksOnIssue_Click);
            // 
            // btnBookReturnCancelReserve
            // 
            this.btnBookReturnCancelReserve.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnBookReturnCancelReserve.Location = new System.Drawing.Point(141, 589);
            this.btnBookReturnCancelReserve.Name = "btnBookReturnCancelReserve";
            this.btnBookReturnCancelReserve.Size = new System.Drawing.Size(104, 38);
            this.btnBookReturnCancelReserve.TabIndex = 7;
            this.btnBookReturnCancelReserve.Text = "Return Book / Cancel Reserve";
            this.btnBookReturnCancelReserve.UseVisualStyleBackColor = true;
            this.btnBookReturnCancelReserve.Click += new System.EventHandler(this.BtnBookReturnCancelReserve_Click);
            // 
            // btnIssueReserveBooks
            // 
            this.btnIssueReserveBooks.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnIssueReserveBooks.Location = new System.Drawing.Point(13, 589);
            this.btnIssueReserveBooks.Name = "btnIssueReserveBooks";
            this.btnIssueReserveBooks.Size = new System.Drawing.Size(104, 38);
            this.btnIssueReserveBooks.TabIndex = 6;
            this.btnIssueReserveBooks.Text = "Issue / Reserve Books";
            this.btnIssueReserveBooks.UseVisualStyleBackColor = true;
            this.btnIssueReserveBooks.Click += new System.EventHandler(this.BtnIssueReserveBooks_Click);
            // 
            // btnCloseForm
            // 
            this.btnCloseForm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloseForm.Location = new System.Drawing.Point(1089, 589);
            this.btnCloseForm.Name = "btnCloseForm";
            this.btnCloseForm.Size = new System.Drawing.Size(90, 38);
            this.btnCloseForm.TabIndex = 5;
            this.btnCloseForm.Text = "Close Books on Issue List";
            this.btnCloseForm.UseVisualStyleBackColor = true;
            this.btnCloseForm.Click += new System.EventHandler(this.BtnCloseForm_Click);
            // 
            // frmBooksOnIssueForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1194, 634);
            this.ControlBox = false;
            this.Controls.Add(this.lvBooksOnIssueList);
            this.Controls.Add(this.btnSearchFilterBooksOnIssue);
            this.Controls.Add(this.btnBookReturnCancelReserve);
            this.Controls.Add(this.btnIssueReserveBooks);
            this.Controls.Add(this.btnCloseForm);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinimumSize = new System.Drawing.Size(1210, 650);
            this.Name = "frmBooksOnIssueForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Books On Issue Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmBooksOnIssueForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lvBooksOnIssueList;
        private System.Windows.Forms.Button btnSearchFilterBooksOnIssue;
        private System.Windows.Forms.Button btnBookReturnCancelReserve;
        private System.Windows.Forms.Button btnIssueReserveBooks;
        private System.Windows.Forms.Button btnCloseForm;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader8;
    }
}