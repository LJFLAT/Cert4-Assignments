﻿namespace LMS_OC.UIScreens
{
    partial class frmBookIssueDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBookTitle = new System.Windows.Forms.Label();
            this.txtBookTitle = new System.Windows.Forms.TextBox();
            this.lvBookIssueDetails = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnCancelReturn = new System.Windows.Forms.Button();
            this.btnCancelReservation = new System.Windows.Forms.Button();
            this.btnReturnIssuedBook = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBookTitle
            // 
            this.lblBookTitle.AutoSize = true;
            this.lblBookTitle.Location = new System.Drawing.Point(13, 13);
            this.lblBookTitle.Name = "lblBookTitle";
            this.lblBookTitle.Size = new System.Drawing.Size(61, 13);
            this.lblBookTitle.TabIndex = 0;
            this.lblBookTitle.Text = "Book Title :";
            // 
            // txtBookTitle
            // 
            this.txtBookTitle.Enabled = false;
            this.txtBookTitle.Location = new System.Drawing.Point(80, 10);
            this.txtBookTitle.Name = "txtBookTitle";
            this.txtBookTitle.ReadOnly = true;
            this.txtBookTitle.Size = new System.Drawing.Size(485, 20);
            this.txtBookTitle.TabIndex = 1;
            // 
            // lvBookIssueDetails
            // 
            this.lvBookIssueDetails.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader5,
            this.columnHeader3,
            this.columnHeader4});
            this.lvBookIssueDetails.FullRowSelect = true;
            this.lvBookIssueDetails.GridLines = true;
            this.lvBookIssueDetails.HideSelection = false;
            this.lvBookIssueDetails.Location = new System.Drawing.Point(16, 37);
            this.lvBookIssueDetails.MultiSelect = false;
            this.lvBookIssueDetails.Name = "lvBookIssueDetails";
            this.lvBookIssueDetails.Size = new System.Drawing.Size(672, 372);
            this.lvBookIssueDetails.TabIndex = 0;
            this.lvBookIssueDetails.UseCompatibleStateImageBehavior = false;
            this.lvBookIssueDetails.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "IssueID";
            this.columnHeader6.Width = 0;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Student ID";
            this.columnHeader1.Width = 70;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Student Name";
            this.columnHeader2.Width = 285;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Contact #";
            this.columnHeader5.Width = 125;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Return Date";
            this.columnHeader3.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Reserve Date";
            this.columnHeader4.Width = 80;
            // 
            // btnCancelReturn
            // 
            this.btnCancelReturn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCancelReturn.Location = new System.Drawing.Point(598, 415);
            this.btnCancelReturn.Name = "btnCancelReturn";
            this.btnCancelReturn.Size = new System.Drawing.Size(90, 38);
            this.btnCancelReturn.TabIndex = 3;
            this.btnCancelReturn.Text = "Close Form";
            this.btnCancelReturn.UseVisualStyleBackColor = true;
            this.btnCancelReturn.Click += new System.EventHandler(this.BtnCancelReturn_Click);
            // 
            // btnCancelReservation
            // 
            this.btnCancelReservation.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnCancelReservation.Location = new System.Drawing.Point(128, 415);
            this.btnCancelReservation.Name = "btnCancelReservation";
            this.btnCancelReservation.Size = new System.Drawing.Size(90, 38);
            this.btnCancelReservation.TabIndex = 2;
            this.btnCancelReservation.Text = "Cancel Reservation";
            this.btnCancelReservation.UseVisualStyleBackColor = true;
            this.btnCancelReservation.Click += new System.EventHandler(this.BtnCancelReservation_Click);
            // 
            // btnReturnIssuedBook
            // 
            this.btnReturnIssuedBook.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnReturnIssuedBook.Location = new System.Drawing.Point(16, 415);
            this.btnReturnIssuedBook.Name = "btnReturnIssuedBook";
            this.btnReturnIssuedBook.Size = new System.Drawing.Size(90, 38);
            this.btnReturnIssuedBook.TabIndex = 1;
            this.btnReturnIssuedBook.Text = "Return Issued Book";
            this.btnReturnIssuedBook.UseVisualStyleBackColor = true;
            this.btnReturnIssuedBook.Click += new System.EventHandler(this.BtnReturnIssuedBook_Click);
            // 
            // frmBookIssueDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 465);
            this.ControlBox = false;
            this.Controls.Add(this.btnReturnIssuedBook);
            this.Controls.Add(this.btnCancelReservation);
            this.Controls.Add(this.btnCancelReturn);
            this.Controls.Add(this.lvBookIssueDetails);
            this.Controls.Add(this.txtBookTitle);
            this.Controls.Add(this.lblBookTitle);
            this.MaximumSize = new System.Drawing.Size(716, 504);
            this.MinimumSize = new System.Drawing.Size(716, 504);
            this.Name = "frmBookIssueDetail";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Issued Books / Reservations Detail Form";
            this.Load += new System.EventHandler(this.FrmBookIssueDetail_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBookTitle;
        private System.Windows.Forms.TextBox txtBookTitle;
        private System.Windows.Forms.ListView lvBookIssueDetails;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button btnCancelReturn;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.Button btnCancelReservation;
        private System.Windows.Forms.Button btnReturnIssuedBook;
        private System.Windows.Forms.ColumnHeader columnHeader6;
    }
}