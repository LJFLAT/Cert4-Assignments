﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LMS_OC.DataAccessLayer;

//Class designed by OpenColleges Copyright 2013 (Based upon earliest record in the original database)
//Modifications to the original code by Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class LoginForm : Form
    {
        int loginAttemps = 1;
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (ValidateInput() == false)
            {
                return;
            }
            DataTable dataTable = ConnectionManager.GetTable("SELECT * FROM Librarian WHERE userName='" + txtUserName.Text + "' and password='" + txtPassword.Text + "' ");
            if (dataTable != null && dataTable.Rows.Count != 0)
            {
                System.Environment.SetEnvironmentVariable("librarianID", dataTable.Rows[0]["librarianID"].ToString());
                System.Environment.SetEnvironmentVariable("librarianName", dataTable.Rows[0]["firstName"].ToString());
                new frmMainForm().Show();
                this.Hide();
            }
            else
            {
                loginAttemps += 1;
                if (loginAttemps > 3)
                {
                    MessageBox.Show("Too many attempts. Program is shutting down.");
                    this.Close();
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show("Invalid user name or password, try again.");
                    txtUserName.Clear();
                    txtPassword.Clear();
                    txtUserName.Focus();
                }
            }                
        }
        private bool ValidateInput()
        {
            if(txtUserName.TextLength > 0 && !GlobalVariables.TestFilterIsValid(txtUserName.Text))
            {
                MessageBox.Show("User name can not contain special characters");
                txtUserName.Text = "";
                txtUserName.Focus();
                return false;
            }
            if(txtPassword.Text.Trim().Contains(" "))
            {
                MessageBox.Show("Password is invalid. Please try again.");
                txtPassword.Text = "";
                txtPassword.Focus();
                return false;
            }
            if (txtUserName.Text == "")
            {
                MessageBox.Show("User name can not be null.");
                txtUserName.Focus();
                return false ;
            }
            if (txtPassword.Text == "")
            {
                MessageBox.Show("Password can not be null.");
                txtPassword.Focus();
                return false ;
            }
            return true;
        }
    }
}
