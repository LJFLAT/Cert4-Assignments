﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.BusinessLogicLayer;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.UIScreens
{
    public partial class frmBookMaintenanceForm : Form
    {
        Book book = new Book(); //create a book instance
        SearchFilterButtonState bookSearchFilterButtonState;  // holds the state of the search / filter button

        private ListViewItemSorter lvItemSorter; //used to sort columns in listView items

        public frmBookMaintenanceForm()
        {
            InitializeComponent();

            // assign items for sorting listView columns
            lvItemSorter = new ListViewItemSorter();
            this.lvBookList.ListViewItemSorter = lvItemSorter;

            // link the Search / Filter button to the button state class
            bookSearchFilterButtonState = new SearchFilterButtonState(btnSearchFilterBookList);
        }

        private void FrmBookMaintenanceForm_Load(object sender, EventArgs e)
        {            
            //Opens the form and loads all book data
            LoadBookList();
        }

        private void LoadBookList()
        {
            lvBookList.Items.Clear();
            DataTable bookDT = ConnectionManager.GetTable(book.FilteredBookSQL());
            if (bookDT.Rows.Count == 0)
            {
                //Create a response message based upon the state of the book search/filter
                string responseMessage = "No book records to display.\nPlease ";
                if (GlobalVariables.BookFilterSet())
                {
                    responseMessage += "clear and change the filter.";
                }
                else
                {
                    responseMessage += "add book records.";
                }
                MessageBox.Show(responseMessage);
            }
            else
            {
                //moves through the bookDT (DataTable) and adds the records to the listView
                for (int record = 0; record < bookDT.Rows.Count; record++)
                {
                    ListViewItem listViewItem = new ListViewItem(bookDT.Rows[record]["bookID"].ToString());
                    listViewItem.SubItems.Add(bookDT.Rows[record]["title"].ToString());
                    listViewItem.SubItems.Add(bookDT.Rows[record]["authorName"].ToString());
                    listViewItem.SubItems.Add(bookDT.Rows[record]["ISBN"].ToString());
                    listViewItem.SubItems.Add(bookDT.Rows[record]["rackNo"].ToString());
                    listViewItem.SubItems.Add(bookDT.Rows[record]["noOfAvailableBooks"].ToString());
                    listViewItem.SubItems.Add(bookDT.Rows[record]["noOfBorrowedBooks"].ToString());
                    listViewItem.SubItems.Add(bookDT.Rows[record]["noOfReservedBooks"].ToString());
                    lvBookList.Items.Add(listViewItem);
                }
            }
        }

        private void BtnCloseForm_Click(object sender, EventArgs e)
        {
            GlobalVariables.ClearBookFilter();
            this.Close();
        }

        private void BtnSearchFilterBookList_Click(object sender, EventArgs e)
        {            
            //This section manages the book search filter process and button state
            //State already set
            if (GlobalVariables.BookFilterSet())
            {
                ResetFilterAndDisplayForm();
            }
            else
            {
                //State not set
                frmBookSearchForm searchForm = new frmBookSearchForm();
                searchForm.ShowDialog();

                if (GlobalVariables.BookFilterSet())
                {
                    bookSearchFilterButtonState.SearchFilterState("Press to Clear Book Filter");
                    LoadBookList();
                }
            }
        }

        private void ResetFilterAndDisplayForm()
        {            
            //When the program returns it resets the book filter and refreshes the form
            GlobalVariables.ClearBookFilter();
            bookSearchFilterButtonState.ResetFilterState();
            LoadBookList();
        }

        private void BtnAddBook_Click(object sender, EventArgs e)
        {
            frmBookDetailsForm subForm = new frmBookDetailsForm();
            subForm.SetBookID(0); //Passes this as bookID - if 0 then new book record
            subForm.ShowDialog();
            ResetFilterAndDisplayForm();
        }

        private void BtnModifyBook_Click(object sender, EventArgs e)
        {
            if (lvBookList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Book Record to Modify the information.","Book not selected", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // This opens the book details form setting it to modify existing book record to update the table
                frmBookDetailsForm subForm = new frmBookDetailsForm();
                subForm.SetBookID(int.Parse(lvBookList.SelectedItems[0].Text)); //passes the bookID to the form
                subForm.ShowDialog();
                ResetFilterAndDisplayForm();
            }
        }

        private void BtnAdjustBookQuantity_Click(object sender, EventArgs e)
        {
            //checks if a book is selected from the listView
            if (lvBookList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please select a Book Record to enter an Adjustment.","Book not selected",MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                //Opens the BookAdjustmentQuantity form and sets the relevant book as selected from the listView
                frmBookQuantityAdjustments subForm = new frmBookQuantityAdjustments(int.Parse(lvBookList.SelectedItems[0].Text));
                subForm.ShowDialog();
                ResetFilterAndDisplayForm();
            }
        }

        private void LvBookList_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // This section of code handles the sorting of listView columns
            // General code structure was taken from links highlighted in ListViewItemSorter.cs and modified to suit
            int testClickColumn = e.Column;

            switch(testClickColumn)
            {
                case 5: //no sort on column 5, 6 or 7
                case 6:
                case 7:
                    return;
                default:
                    //checks performed within ListViewItemSorter class
                    lvItemSorter.checkPreviousOrder(testClickColumn);

                    // Perform the sort with these new sort options.
                    this.lvBookList.Sort();
                    return;
            }
        }
    }
}
