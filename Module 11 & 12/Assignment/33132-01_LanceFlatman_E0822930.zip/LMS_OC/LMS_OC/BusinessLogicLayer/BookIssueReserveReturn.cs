﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.BusinessLogicLayer
{
    //A class to hold information about a book, student and details of an issued book
    public class BookIssueReserveReturn
    {
        private int _issueID; //self generated record number (used to identify issueID or returnID)
        private DateTime _issueReserveDate; //issue date of the book
        private DateTime _returnDate; //Expected return of book
        private int _librarianID;
        private int _studentID;
        private int _bookID;
        private double _fine;

        //Constant
        private int DEFAULT_BORROWING_DAYS = 7;
        private int MAX_RETURN_DAYS = 28;
        private double FINE_PER_DAY = 0.50;
        private double MAXIMUM_FINE = 0.65; //65% of current book value

        public BookIssueReserveReturn() { }

        public BookIssueReserveReturn(int issueID, int librarianID, int studentID, int bookID, double fine)
        {
            _issueID = issueID; //0 represents a new bookIssue
            _issueReserveDate = DateTime.Today; //Default issue / reserve date
            _returnDate = DateTime.Today.AddDays(DEFAULT_BORROWING_DAYS); //Default borrowing days
            _librarianID = librarianID;
            _studentID = studentID;
            _bookID = bookID;
            _fine = fine;
        }

        public int IssueID
        {
            //0 represents a new record
            get { return _issueID; }
            set { _issueID = value; }
        }

        public int BookID
        {
            get { return _bookID; }
            set { _bookID = value; }
        }

        public int StudentID
        {
            get { return _studentID; }
            set { _studentID = value; }
        }

        public int LibrarianID
        {
            get { return _librarianID; }
            set { _librarianID = value; }
        }

        public DateTime IssueReserveDate
        {
            get { return _issueReserveDate; }
            set { _issueReserveDate = value; }
        }

        public DateTime ReturnDate
        {
            get { return _returnDate; }
            set { _returnDate = value; }
        }

        public double Fine
        {
            get { return _fine; }
            set { _fine = value; }
        }

        public DateTime StandardReturnDays(DateTime initialDate)
        {
            return initialDate.AddDays(DEFAULT_BORROWING_DAYS);
        }

        public DateTime MaximumReturnDays(DateTime initialDate)
        {
            return initialDate.AddDays(MAX_RETURN_DAYS);
        }

        public string FilteredBookIssueSQL()
        {
            //used to populate the BookIssueMaintenanceForm listview item
            //Multi table joins

            //two potential options for this (Keep this in code and test once the number of books and reserved books increase.
            //There may be a speed increase / decrease and can be tested later with each option).
            // https://stackoverflow.com/questions/6599011/sql-to-gather-data-from-one-table-while-counting-records-in-another

            //string selectQuery = "SELECT BookIssue.bookID, Book.title, Author.authorName, Book.ISBN
            //    , MIN(BookIssue.returnDate) AS earliestReturn, noOfAvailableBooks, noOfBorrowedBooks, 
            //    (SELECT COUNT(BookReserve.studentID) FROM BookReserve " +
            //    "AS noOfReservedBooks FROM BookIssue LEFT JOIN Book ON BookIssue.bookID = Book.bookID " +
            //    "LEFT JOIN BookReserve ON BookIssue.bookID = BookReserve.bookID " +
            //    "LEFT JOIN Author ON Book.authorID = Author.authorID WHERE Book.bookID = BookReserve.bookID)"

            //This was based on BookIssue data
            //string selectQuery = "SELECT BookIssue.bookID, Book.title, Author.authorName, Book.ISBN, " +
            //    "MIN(BookIssue.returnDate) AS earliestReturn, Book.noOfAvailableBooks, Book.noOfBorrowedBooks, " +
            //    "COUNT(BookReserve.bookID) AS noOfReservedBooks FROM BookIssue " +
            //    "LEFT JOIN Book ON BookIssue.bookID = Book.bookID " +
            //    "LEFT JOIN BookReserve ON BookIssue.bookID = BookReserve.bookID " +
            //    "LEFT JOIN Author ON Book.authorID = Author.authorID ";

            //This query is based on book data which has records showing from BookIssue or BookReserved
            //string selectQuery = "SELECT Book.booID, title, Author.authorName, ISBN, " +
            //    "MIN(BookIssue.returnDate) AS earliestReturn, noOfAvailableBooks, noOfBorrowedBooks, " +
            //    "COUNT(BookReserve.BookID) AS noOfReservedBooks FROM Book " +
            //    "LEFT JOIN BookIssue ON Book.bookID = BookIssue.bookID " +
            //    "LEFT JOIN BookReserve ON Book.bookID = BookReserve.bookID " +
            //    "LEFT JOIN Author ON Book.bookID = Author.authorID "

            //Query which returns all book records (based upon filters if set) - calling function determines which records to display
            string selectQuery = "SELECT Book.bookID, title, Author.authorName, ISBN, " +
                "MIN(BookIssue.returnDate) AS earliestReturn, Book.noOfAvailableBooks, Book.noOfBorrowedBooks, " +
                "(SELECT COUNT(BookReserve.reserveID) FROM BookReserve " +
                "WHERE BookReserve.bookID = Book.bookID) AS noOfReservedBooks FROM Book " +
                "LEFT JOIN BookIssue ON Book.bookID = BookIssue.bookID " +
                "LEFT JOIN BookReserve ON Book.bookID = BookReserve.bookID " +
                "LEFT JOIN Author ON Book.authorID = Author.authorID ";

            //Checks if filter is set and uses Search / Filter criteria to create a query
            if (GlobalVariables.BookFilterSet())
            {
                selectQuery += " WHERE ";
                if (GlobalVariables.BookTitle.Length > 0)
                {
                    selectQuery += "Book.title LIKE ('%" + GlobalVariables.BookTitle + "%')";
                }
                if (GlobalVariables.AuthorName.Length > 0)
                {
                    AddAnd(GlobalVariables.BookTitle, selectQuery);
                    selectQuery += "Author.authorName LIKE ('%" + GlobalVariables.AuthorName + "%')";
                }
            }
            selectQuery += "GROUP BY Book.bookID, Book.title, Author.authorName, Book.ISBN, " +
                "BookIssue.returnDate, noOfAvailableBooks, noOfBorrowedBooks, BookIssue.returnDate";
            selectQuery += " ORDER BY BookIssue.returnDate ASC";

            return selectQuery;
        }

        private ProcessTableActions bookDataChanges; //declared and used for update database operations (within this class)
        public int BookIssueAdd() //Add Issue book record
        {
            //Check for overdue books to student - dont allow issue
            if (CheckStudentOverdue())
            {
                if (!CheckStudentExistingReserve()) //Check to see if already a reservation - if not ask user to reserve instead
                { 
                    DialogResult result = MessageBox.Show("Would you like to create a reservation for this book instead?"
                        , "Overdue Book - Book Issue not Allowed", MessageBoxButtons.YesNo, MessageBoxIcon.Warning
                        , MessageBoxDefaultButton.Button2);
                    if (result == DialogResult.Yes)
                    {
                        BookReserveAdd();
                    }
                }
                MessageBox.Show("Book issue cancelled.", "Book issue did not proceed"
                    , MessageBoxButtons.OK, MessageBoxIcon.Information);
                return 0; //If any overdues - return the user to the calling screen
            }

            //Check for existing issued book to student - dont allow duplicate issue of book
            //Students should not be listed if they have a reserve or an issued book therefore this should pass
            if (CheckStudentExistingIssue())
            {
                MessageBox.Show("This student has already been issued this book.\nIssue cannot proceed."
                    , "Book already issued", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return 0;
            }

            string newBookIssue = "", adjustBookStats = "";
            newBookIssue = "INSERT INTO BookIssue (studentID, issueDate, returnDate, librarianID, bookID) " +
                "VALUES (" + this.StudentID + ", @issueDate, @returnDate, " + this.LibrarianID + ", " + this.BookID + ")";
            adjustBookStats = "UPDATE Book SET noOfAvailableBooks = noOfAvailableBooks-1" +
                ", noOfBorrowedBooks = noOfBorrowedBooks+1 WHERE bookID = " + this.BookID + "";

            bool saveFail = false; //Saving records has worked if false
            int recordCount = 10; //start with a number in excess of potential updates

            bookDataChanges = new ProcessTableActions(); //create instance - open connection - start a transaction
            //Once instance created - pass parameters
            bookDataChanges.command.Parameters.Add("@issueDate", SqlDbType.Date).Value = this.IssueReserveDate.Date;
            bookDataChanges.command.Parameters.Add("@returnDate", SqlDbType.Date).Value = this.ReturnDate.Date;

            //Deletes a reservation record if any exist
            if(BookReserveDelete(false) < 0) //false - treats this as a group of transactions (not as individual)
            {
                saveFail = true; //This can have a 0 recordCount if there were no previous reserves
            }
            if (!saveFail) //Bypass if previous was a fail
            {
                //Creates a new book issue record
                recordCount = Math.Min(recordCount, bookDataChanges.ExecuteCommands(newBookIssue));
                saveFail = bookDataChanges.SaveFail(recordCount);
            }
            if (!saveFail) //Bypass if previous was a fail
            {
                //adjusts the books availability and borrowed counts
                recordCount = bookDataChanges.ExecuteCommands(adjustBookStats);
                saveFail = bookDataChanges.SaveFail(recordCount);
            }
            //Save transaction - close connection (rollback if unsuccessful) 
            bookDataChanges.CloseConnection(!saveFail); //If saveFail = true, will rollback transactions
            return recordCount;
        }


        public int BookReserveAdd() //Add Reserve book record
        {
            //Check if existing reservation - this should not be possible but test anyway
            if(CheckStudentExistingReserve())
            {
                MessageBox.Show("This student already has a reservation for this book.\nReservation not recorded."
                    , "Reservation exists", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return 0;
            }

            //Code to save the reservation
            string newBookReservation = "";
            newBookReservation = "INSERT INTO BookReserve (studentID, reserveDate, librarianID, bookID) " +
                "VALUES (" + this.StudentID + ", @reserveDate, " + this.LibrarianID + ", " + this.BookID + ")";

            bookDataChanges = new ProcessTableActions(); //create instance - open connection - start a transaction
            //Once instance created - pass parameter
            bookDataChanges.command.Parameters.Add("@reserveDate", SqlDbType.Date).Value = this.IssueReserveDate.Date;

            //Code to execute the SQL statement
            int recordCount = bookDataChanges.ExecuteCommands(newBookReservation);
            bool saveFail = bookDataChanges.SaveFail(recordCount);

            //Save transaction - close connection (rollback if unsuccessful) 
            bookDataChanges.CloseConnection(!saveFail); //If saveFail is true, will rollback transactions
            return recordCount;
        }

        public int BookReturnAdd() //Add Return book record
        {
            //This code stores book return information - updates book and student fine where relevant
            string bookUpdate = "", returnBookInsert = "", studentFineUpdate = "";
            //Prepares the SQL statements
            returnBookInsert = "INSERT INTO BookReturn (studentID, returnDate, librarianID, issueID) " +
                "VALUES (" + this.StudentID + ", @returnDate ," + this.LibrarianID + "," + this.IssueID + ")";
            bookUpdate = "UPDATE Book SET noOfAvailableBooks = noOfAvailableBooks+1" +
                ", noOfBorrowedBooks = noOfBorrowedBooks-1 WHERE bookID = " + this.BookID + "";
            studentFineUpdate = "UPDATE Student SET fine = fine + " + this.Fine
                + " WHERE studentID = " + this.StudentID + "";


            bookDataChanges = new ProcessTableActions(); //create instance - open connection - start a transaction
            //Once instance created - pass parameter
            bookDataChanges.command.Parameters.Add("@returnDate", SqlDbType.Date).Value = this.ReturnDate.Date;

            bool saveFail = false; //Saving records has worked if false
            int recordCount = 10; //start with a number in excess of potential updates

            //Pass SQL statments to the instance
            if (this.Fine > 0)
            {
                //Updates the student record with the additional fine amount
                recordCount = bookDataChanges.ExecuteCommands(studentFineUpdate);
                saveFail = bookDataChanges.SaveFail(recordCount);
            }

            if (!saveFail) //Bypass if previous was a fail
            {
                //adjusts the books stats
                recordCount = Math.Min(recordCount, bookDataChanges.ExecuteCommands(bookUpdate));
                saveFail = bookDataChanges.SaveFail(recordCount);
            }

            if (!saveFail) //Bypass if previous was a fail
            {
                //creates a BookReturn record which cancels out an existing BookIssue (matching issueNo records)
                recordCount = bookDataChanges.ExecuteCommands(returnBookInsert);
                saveFail = bookDataChanges.SaveFail(recordCount);
            }

            //Save transaction - close connection (rollback if unsuccessful) 
            bookDataChanges.CloseConnection(!saveFail); //If saveFail is true, will rollback transactions
            return recordCount;
        }

        public int BookReserveDelete(bool individual) //This code deletes a BookReserve record
        {
            //individual = true when called from another form
            // false - when called within this class
            if (individual)
            {
                bookDataChanges = new ProcessTableActions();
            } //otherwise it should already be created

            string commandText = "";
            commandText = "DELETE BookReserve WHERE bookID=" + this.BookID + " AND studentID =" + this.StudentID + "";
            int recordCount = bookDataChanges.ExecuteCommands(commandText);

            if(individual)
            {
                if(!bookDataChanges.CloseConnection(!bookDataChanges.SaveFail(recordCount)))
                {
                    return -1;
                }
            }
            return recordCount;
        }

        //used to join multiple filters within the WHERE statement
        private void AddAnd(string checkItemLength, string selectQuery)
        {
            if (checkItemLength.Length > 0)
            {
                selectQuery += " AND ";
            }
            return;
        }

        public double CalculateFine(DateTime bookReturnDate)
        {
            //Assume 50c per day as standard (maximum of 65% of current book value?)
            // - treated as lost then it would be 'returned' on current day and additional charge 
            // as per the BookAdjustment cost value) - separate entry undertaken

            int daysOverdue = DaysOverdue(bookReturnDate);

            //Maximum fine of 65% of the present book value
            DataTable bookFine = ConnectionManager.GetTable("SELECT price FROM Book WHERE BookID = " + this.BookID + "");

            if (daysOverdue > 0)
            {
                double calculatedFine = ((double)daysOverdue * FINE_PER_DAY);
                if (calculatedFine > (double.Parse(bookFine.Rows[0]["price"].ToString()) * MAXIMUM_FINE))
                {
                    calculatedFine = (double.Parse(bookFine.Rows[0]["price"].ToString()) * MAXIMUM_FINE);
                }
                return calculatedFine;
            }
            else
            {
                return 0;
            }
        }

        public int DaysOverdue(DateTime bookReturnDate)
        {
            double calculatedDays = 0;
            calculatedDays = (bookReturnDate - ReturnDate).TotalDays;
            if(calculatedDays < 0.0)
            {
                calculatedDays = 0;
            }
            return int.Parse(System.Math.Floor(calculatedDays).ToString());
        }

        private bool CheckStudentExistingIssue()
        {
            //Check BookIssue for this.StudentID and this.BookID - if records > 0, cannot issue the same book
            //Display WHERE the BookReturns is NULL (Therefore a book has been issued but not returned)
            //https://www.dofactory.com/sql/where-isnull
            string selectQuery = "SELECT BookIssue.studentID,  BookReturn.studentID FROM BookIssue " +
                "LEFT JOIN BookReturn ON BookIssue.IssueID = BookReturn.IssueID " +
                "WHERE BookIssue.studentID=" + this.StudentID + " AND  BookIssue.bookID = " + this.BookID 
                + " AND BookReturn.studentID IS NULL";
            DataTable checkStudentExistingIssueDT = ConnectionManager.GetTable(selectQuery);
            if (checkStudentExistingIssueDT.Rows.Count > 0) //Represents and existing issue - no matching return
            {
                return true;
            }
            return false;
        }

        private bool CheckStudentExistingReserve()
        {
            //Check BookReserve table for this.StudentID and this.BookID - if records > 0, cannot reserve additional books
            string selectQuery = "SELECT studentID FROM BookReserve WHERE studentID = " + this.StudentID
                + " AND bookID = " + this.BookID + "";
            DataTable checkStudentExistingReserveDT = ConnectionManager.GetTable(selectQuery);

            if(checkStudentExistingReserveDT.Rows.Count > 0) //Existing reserves for this student and book
            {
                return true;
            }
            return false;
        }

        private bool CheckStudentOverdue()
        {
            //Check BookIssue table for this.StudentID & MIN(returnDate) - if any < Today then cannot issue books
            //Make a reserve instead?
            string selectQuery = "SELECT Book.title, BookIssue.returnDate" +
                ", BookIssue.issueID AS biIssueID, BookReturn.issueID as brIssueID FROM BookIssue " +
                "LEFT JOIN Book ON BookIssue.bookID = Book.bookID " +
                "LEFT JOIN BookReturn ON BookIssue.issueID = BookReturn.issueID " +
                "WHERE BookIssue.studentID = " + this.StudentID + " " +
                "ORDER BY BookIssue.returnDate ASC";
            DataTable checkStudentOverdueDT = ConnectionManager.GetTable(selectQuery);

            string overdueList = "";

            bool overdue = false;
            for (int record = 0; record < checkStudentOverdueDT.Rows.Count; record++)
            {
                //Looks through dataTable for student and checks if the returnDate < todays date
                //If there are overdue books, writes a list and warning to the screen
                //Confirms to make newReserve instead using todays date as default?

                string tempIssuedID = checkStudentOverdueDT.Rows[record]["biIssueID"].ToString();
                string tempReturnedID = checkStudentOverdueDT.Rows[record]["brIssueID"].ToString();

                DateTime tempReturnDate = DateTime.Parse(checkStudentOverdueDT.Rows[record]["returnDate"].ToString());
                if (!tempIssuedID.Equals(tempReturnedID) && tempReturnDate < DateTime.Today)
                {
                    overdueList += "  Due: " + tempReturnDate.ToString("dd/MM/yyyy") + " - "
                        + checkStudentOverdueDT.Rows[record]["title"].ToString() + "\n";
                    overdue = true;
                }
            }
            if (overdue)
            {
                MessageBox.Show("These books are overdue. Book Issue cannot be continued.\n\n" + overdueList 
                    , "Overdue Book List", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return overdue;
        }
    }
}
