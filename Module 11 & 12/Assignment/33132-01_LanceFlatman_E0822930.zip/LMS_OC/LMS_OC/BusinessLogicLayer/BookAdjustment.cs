﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using LMS_OC.DataAccessLayer;
using System.Windows.Forms;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.BusinessLogicLayer
{
    public class BookAdjustment
    {
        private int _bookID, _quantityAdjusted, _librarianID;
        private DateTime _adjustmentDate;
        private string _adjustmentComment;
        private decimal _costPerBookAdjusted;

        public BookAdjustment() { }

        public BookAdjustment(int bookID, DateTime adjustmentDate, string adjustmentComment, int quantityAdjusted, 
            decimal pricePerBookAdjusted, int librarianID)
        {
            _bookID = bookID;
            _adjustmentDate = adjustmentDate;
            _adjustmentComment = adjustmentComment;
            _quantityAdjusted = quantityAdjusted;
            if(pricePerBookAdjusted == 0) //New instance of BookAdjustment
            {
                //Set the default price to the price in the Book record
                DataTable bookPriceAverage = ConnectionManager.GetTable("SELECT * FROM Book WHERE bookID = " + bookID + "");
                pricePerBookAdjusted = decimal.Parse(bookPriceAverage.Rows[0]["price"].ToString());
            }
            else //Passing a previously stored value from a BookAdjustments record
            {
                _costPerBookAdjusted = pricePerBookAdjusted;
            }
        }

        public int BookID
        {
            get { return _bookID; }
            set { _bookID = value; }
        }

        public DateTime AdjustmentDate
        {
            get { return _adjustmentDate; }
            set { _adjustmentDate = value; }
        }

        public string AdjustmentComment
        {
            get { return _adjustmentComment; }
            set { _adjustmentComment = value; }
        }

        public int QuantityAdjusted
        {
            get { return _quantityAdjusted; }
            set { _quantityAdjusted = value; }
        }

        public decimal CostPerBook
        {
            get { return _costPerBookAdjusted; }
            set { _costPerBookAdjusted = value; }
        }

        public int LibrarianID
        {
            get { return _librarianID; }
            set { _librarianID = value; }
        }

        public int BookAdjustmentAdd(decimal newAdjustedAveragePrice)
        {
            //This code stores new / modified book information
            SqlConnection connection = ConnectionManager.DBConnection();
            SqlCommand command = new SqlCommand();
            string commandText = "";

            //Adjustments only can add - undertake another adjustment to alter incorrect entry
            commandText = "INSERT INTO BookAdjustments (bookID, quantityAdjusted, costPerBook, adjustmentComment" +
                ", dateAdjusted, librarianID) VALUES (" + this.BookID + ","+ this.QuantityAdjusted + "," 
                + this.CostPerBook + ",'" + this.AdjustmentComment + "', @AdjustmentDate, " 
                + this.LibrarianID + ")";

            command.Parameters.Add("@AdjustmentDate", SqlDbType.Date).Value = this.AdjustmentDate.Date;

            try
            {
                command.Connection = connection;
                connection.Open();
                command.Transaction = connection.BeginTransaction();

                string bookPriceAdjustment = "";
                //if the average price has been altered this section runs
                if (newAdjustedAveragePrice != 0)
                {
                    //creates a new record in book table using values stored in a librarian instance
                    bookPriceAdjustment = "UPDATE Book SET price = " + newAdjustedAveragePrice
                        + ", noOfAvailableBooks = noOfAvailableBooks + " + this.QuantityAdjusted 
                        + " WHERE bookID = " + this.BookID + "";
                }
                //if there has been a quantity adjusted
                else if (this.QuantityAdjusted != 0)
                {
                    bookPriceAdjustment = "UPDATE Book SET noOfAvailableBooks = noOfAvailableBooks+" 
                        + this.QuantityAdjusted + " WHERE bookID = " +  this.BookID + "";
                }
                //if either of the above are true then a condition has been set - update using valid statement
                if(bookPriceAdjustment.Length > 0)
                {
                    command.CommandText = bookPriceAdjustment;
                    command.ExecuteNonQuery();
                }

                command.CommandText = commandText;
                int recordCount = command.ExecuteNonQuery();
                command.Transaction.Commit();
                connection.Close();

                return recordCount;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Saving to the database failed. Please contact database admin for assistance." 
                    + "\nError Message: "+ ex);
            }
            return 0;
        }
    }
}
