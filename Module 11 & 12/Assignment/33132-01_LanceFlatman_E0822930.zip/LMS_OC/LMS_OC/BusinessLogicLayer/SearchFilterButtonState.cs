﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.BusinessLogicLayer
{
    public class SearchFilterButtonState
    {
        //Variables to hold the initial state of a search / filter button
        private Button originalButtonItem;
        private string originalButtonText;
        private Color originalButtonColour;

        //Stores the original search / filter button state
        public SearchFilterButtonState(Button buttonDetails)
        {
            this.originalButtonItem = buttonDetails;
            this.originalButtonText = buttonDetails.Text;
            this.originalButtonColour = buttonDetails.BackColor;
        }

        //Reverts the state of the search / filter button
        public void ResetFilterState()
        {
            this.originalButtonItem.Text = originalButtonText;
            this.originalButtonItem.BackColor = originalButtonColour;
        }

        //Changes the button name and background colour - new state
        public void SearchFilterState(string newButtonText)
        {
            this.originalButtonItem.Text = newButtonText;
            this.originalButtonItem.BackColor = Color.LightGreen;
        }
    }
}
