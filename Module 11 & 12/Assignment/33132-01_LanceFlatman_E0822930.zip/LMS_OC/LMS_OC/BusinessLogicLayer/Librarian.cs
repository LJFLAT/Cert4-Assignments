﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using LMS_OC.DataAccessLayer;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.BusinessLogicLayer
{
    public class Librarian
    {
        private int _librarianID, _postCode;
        private string _firstName, _lastName, _address, _suburb, _state, _contactNo, _email, _userName, _password;

        public Librarian() { }

        public Librarian(int librarianID, string firstName, string lastName, string address, string suburb,
            string state, int postCode, string contactNo, string email, string userName, string password)
        {
            this._librarianID = librarianID;
            this._firstName = firstName;
            this._lastName = lastName;
            this._address = address;
            this._suburb = suburb;
            this._state = state;
            this._postCode = postCode;
            this._contactNo = contactNo;
            this._email = email;
            this._userName = userName;
            this._password = password;
        }

        public int LibrarianID
        {
            get { return _librarianID; }
            set { _librarianID = value; }
        }

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }

        public string Suburb
        {
            get { return _suburb; }
            set { _suburb = value; }
        }

        public string State
        {
            get { return _state; }
            set { _state = value; }
        }

        public int PostCode
        {
            get { return _postCode; }
            set { _postCode = value; }
        }

        public string ContactNo
        {
            get { return _contactNo; }
            set { _contactNo = value; }
        }

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }

        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        public string FilteredLibrarianSQL()
        {
            string selectQuery = "SELECT * FROM Librarian";

            //Checks is filter is set and uses Search / Filter criteria to create a query
            if (GlobalVariables.LibrarianFilterSet())
            {
                selectQuery += " WHERE ";
                if (GlobalVariables.LibrarianLastName.Length > 0)
                {
                    selectQuery += "lastName LIKE ('%" + GlobalVariables.LibrarianLastName + "%')";
                }
                if (GlobalVariables.LibrarianFirstName.Length > 0)
                {
                    AddAnd(GlobalVariables.LibrarianLastName, selectQuery);
                    selectQuery += "firstName LIKE ('%" + GlobalVariables.LibrarianFirstName + "%')";
                }
            }
            selectQuery += " ORDER BY librarianID";

            return selectQuery;
        }

        public int LibrarianAddModify()
        {
            //This code stores new / modified librarian information
            SqlConnection connection = ConnectionManager.DBConnection();
            SqlCommand command = new SqlCommand();
            string commandText = "";

            if (this.LibrarianID == 0)
            {
                //creates a new record in librarian table using values stored in a librarian instance
                commandText = "INSERT INTO Librarian VALUES ('" + this.FirstName + "','" + this.LastName + "','" 
                    + this.Address + "','" + this.Suburb + "','" + this.State + "','" + this.PostCode + "','" 
                    + this.ContactNo + "','" + this.Email + "','" + this.UserName + "','" + this.Password +"')";
            }
            else
            {
                //doesn't change userName as this should not allow change once setup
                commandText = "UPDATE Librarian SET firstName='" + this.FirstName + "',lastName='" + this.LastName
                + "',address='" + this.Address + "', suburb='" + this.Suburb + "',state='" + this.State + "',postCode=" 
                + this.PostCode + ",email='" + this.Email + "', contactNo='" + this.ContactNo + "',password='"
                + this.Password + "' WHERE librarianID=" + this.LibrarianID + "";
            }

            try
            {
                command.CommandText = commandText;
                command.Connection = connection;
                connection.Open();
                command.Transaction = connection.BeginTransaction();
                int recordCount = command.ExecuteNonQuery();
                command.Transaction.Commit();
                connection.Close();

                return recordCount;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Saving to the database failed. Please contact database admin for assistance.\nError Message: " 
                    + ex);
            }
            return 0;
        }

        //used to join multiple filters within the WHERE statement
        private void AddAnd(string checkItemLength, string selectQuery)
        {
            if (checkItemLength.Length > 0)
            {
                selectQuery += " AND ";
            }
            return;
        }
    }
}
