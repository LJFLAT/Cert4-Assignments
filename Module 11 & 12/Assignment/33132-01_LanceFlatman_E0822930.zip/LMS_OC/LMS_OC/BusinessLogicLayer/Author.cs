﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using LMS_OC.DataAccessLayer;
using System.Windows.Forms;

//Copyright 2019 - Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.BusinessLogicLayer
{
    public class Author
    {
        private int _authorID;
        private string _authorName;

        public Author() { }

        public Author(int authorID, string authorName)
        {
            this._authorID = authorID;
            this._authorName = authorName;
        }

        public int AuthorID
        {
            get { return _authorID; }
            set { _authorID = value; }
        }

        public string AuthorName
        {
            get { return _authorName; }
            set { _authorName = value; }
        }

        public string FilteredAuthorSQL()
        {
            string selectQuery = "SELECT * FROM Author";

            //Checks is filter is set and uses Search / Filter criteria to create a query
            if (GlobalVariables.AuthorName.Length>0)
            {
                selectQuery += " WHERE authorName LIKE ('%" + GlobalVariables.AuthorName + "%')";
            }
            selectQuery += " ORDER BY authorID";

            return selectQuery;
        }

        public int AuthorAddModify()
        {
            //This code stores new / modified student information
            SqlConnection connection = ConnectionManager.DBConnection();
            SqlCommand command = new SqlCommand();
            string commandText = "";

            if (this.AuthorID == 0)
            {
                //creates a new record in author table using values stored in a author instance
                commandText = "INSERT INTO Author OUTPUT INSERTED.authorID VALUES ('" + @AuthorName + "')";
            }
            else
            {
                commandText = "UPDATE Author SET authorName ='" + @AuthorName 
                    + "' OUTPUT " + this.AuthorID + " WHERE authorID =" + this.AuthorID + "";
            }
            command.Parameters.Add("@AuthorName", System.Data.SqlDbType.NVarChar).Value = this.AuthorName;

            try
            {
                command.CommandText = commandText;
                command.Connection = connection;
                connection.Open();
                command.Transaction = connection.BeginTransaction();
                int returnedAuthorID = (int)command.ExecuteScalar();
                command.Transaction.Commit();
                connection.Close();

                return returnedAuthorID;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Saving to the database failed. Please contact database admin for assistance.\nError Message: "
                    + ex);
            }
            return 0;
        }
    }
}
