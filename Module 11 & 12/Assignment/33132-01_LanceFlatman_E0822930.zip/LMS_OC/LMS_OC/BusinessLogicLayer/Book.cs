﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using LMS_OC.DataAccessLayer;
using System.Windows.Forms;

//Class designed by OpenColleges Copyright 2013 (Based upon earliest record in the original database)
//Modifications to the original code by Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.BusinessLogicLayer
{
    public class Book
    {
        // Microsoft naming conventions where variables relate to fields, these should have an underline at the beginning.
        private int _bookID;
        private string _ISBN;
        private string _title;
        private int _authorID;
        private double _price;
        private string _rackNo;
        private int _availableBooks;
        private int _borrowedBooks;
        private int _librarianID;

        public Book() { }

        public Book(string isbn, string bookTitle, int authorID, double bookCost, string rackNumber, 
            int numberOfBooksAvailable, int numberOfBorrowedBooks,int librarianID)
        {
            this._ISBN = isbn;
            this._title = bookTitle;
            this._authorID = authorID;
            this._price = bookCost;
            this._rackNo = rackNumber;
            this._availableBooks = numberOfBooksAvailable;
            this._borrowedBooks = numberOfBorrowedBooks;
            this._librarianID = librarianID;
        }
        public int BookID
        {
            get { return _bookID; }
            set { _bookID = value; }
        }
        public string BookISBN
        {
            get { return _ISBN; }
            set { _ISBN = value; }
        }
        public string BookTitle
        {
            get { return _title; }
            set { _title = value; }
        }
        public int BookAuthorID
        {
            get { return _authorID; }
            set { _authorID = value; }
        }
        public double BookPrice
        {
            get { return _price; }
            set { _price = value; }
        }
        public string RackNumber
        {
            get { return _rackNo; }
            set { _rackNo = value; }
        }
        public int AvailableBooks
        {
            get { return _availableBooks; }
            set { _availableBooks = value; }
        }
        public int BorrowedBooks
        {
            get { return _borrowedBooks; }
            set { _borrowedBooks = value; }
        }

        public int LibrarianID
        {
            get { return _librarianID; }
            set { _librarianID = value; }
        }

        public string FilteredBookSQL()
        {
            //used to populte the BookMaintenanceForm listview item
            //Multi table joins

            //two potential options for this (Keep this in code and test once the number of books and reserved books increase.
            //There may be a speed increase / decrease and can be tested later with each option).
            // https://stackoverflow.com/questions/6599011/sql-to-gather-data-from-one-table-while-counting-records-in-another

            //string selectQuery = "SELECT Book.bookID AS bookID, title, authorName, ISBN, rackNo, noOfAvailableBooks, " +
            //    "noOfBorrowedBooks, " +
            //    "(SELECT COUNT(BookReserve.studentID) FROM BookReserve WHERE Book.bookID = BookReserve.bookID) " +
            //    "AS noOfReservedBooks " +
            //    "FROM Book "

            string selectQuery = "SELECT Book.bookID, title, Author.authorName, ISBN, rackNo, noOfAvailableBooks, " +
                "noOfBorrowedBooks, COUNT(BookReserve.bookID) AS noOfReservedBooks FROM Book " +
                "LEFT JOIN BookReserve ON Book.bookID = BookReserve.bookID " +
                "LEFT JOIN Author ON Book.authorID = Author.authorID ";
                                                       
            //Checks if filter is set and uses Search / Filter criteria to create a query
            if (GlobalVariables.BookFilterSet())
            {
                selectQuery += " WHERE ";
                if (GlobalVariables.BookTitle.Length > 0)
                {
                    selectQuery += "title LIKE ('%" + GlobalVariables.BookTitle + "%')";
                }
                if (GlobalVariables.AuthorName.Length > 0)
                {
                    AddAnd(GlobalVariables.BookTitle, selectQuery);
                    selectQuery += "Author.authorName LIKE ('%" + GlobalVariables.AuthorName + "%')";
                }
            }
            selectQuery += "GROUP BY Book.bookID, title, Author.authorName, ISBN, rackNo, noOfAvailableBooks, " +
                "noOfBorrowedBooks";
            selectQuery += " ORDER BY bookID";

            return selectQuery;
        }

        public int BookAddModify()
        {
            //This code stores new / modified book information
            SqlConnection connection = ConnectionManager.DBConnection();
            SqlCommand command = new SqlCommand();
            string commandText = "";

            if (this.BookID == 0)
            {
                //creates a new record in book table using values stored in a librarian instance
                commandText = "INSERT INTO Book (title,authorID,price,rackNo,noOfAvailableBooks,noOfBorrowedBooks," +
                "librarianID,ISBN) VALUES ('" + @BookTitle + "'," + this.BookAuthorID + ","
                    + this.BookPrice + ",'" + this.RackNumber + "'," + this.AvailableBooks + "," + this.BorrowedBooks + ","
                    + this.LibrarianID + ",'" + this.BookISBN + "')";
            }
            else
            {
                //doesn't change userName as this should not allow change
                commandText = "UPDATE Book SET title ='" + @BookTitle + "',authorID=" + this.BookAuthorID
                + ", rackNo ='" + this.RackNumber + "', ISBN='" + this.BookISBN + "', librarianID=" + this.LibrarianID 
                + " WHERE bookID=" + this.BookID + "";
            }
            command.Parameters.Add("@BookTitle", SqlDbType.NVarChar).Value = this.BookTitle;

            try
            {
                command.CommandText = commandText;
                command.Connection = connection;
                connection.Open();
                command.Transaction = connection.BeginTransaction();
                int recordCount = command.ExecuteNonQuery();
                command.Transaction.Commit();
                connection.Close();

                return recordCount;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Saving to the database failed. Please contact database admin for assistance.\nError Message: "
                    + ex);
            }
            return 0;
        }

        // places an AND in the relevant portion of an SQL WHERE statement
        private void AddAnd(string checkItemLength, string selectQuery)
        {
            if (checkItemLength.Length > 0)
            {
                selectQuery += " AND ";
            }
            return;
        }
    }
}
