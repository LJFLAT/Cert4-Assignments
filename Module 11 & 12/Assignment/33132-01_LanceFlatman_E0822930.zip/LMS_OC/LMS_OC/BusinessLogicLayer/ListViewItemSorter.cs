﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS_OC.BusinessLogicLayer
{
    // general code outline from https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.listview.listviewitemsorter?view=netframework-4.8
    // and https://support.microsoft.com/en-au/help/319401/how-to-sort-a-listview-control-by-a-column-in-visual-c
    // Code example modified by Tiama Investments Pty Ltd (ABN 93 085 303 260) 

    class ListViewItemSorter : IComparer
    {
        //This class is inherited from IComparer - it alters the Compare method
        //and links to the relevant listView item after it is initialised in the various forms.
        private int columnToSort;
        private SortOrder orderOfSort;
        private CaseInsensitiveComparer objectCompare;

        public ListViewItemSorter()
        {
            // Initialize the column to '0' (Sorting based upon first column)
            //(This is used to hold which was the last column sorted)
            columnToSort = 0;

            // Initialize the sort order to 'none'
            //(The original state of the sorting process is based upon 
            //the initial load of the information into the listView item)
            orderOfSort = SortOrder.Ascending;

            // Initialize the CaseInsensitiveComparer object
            objectCompare = new CaseInsensitiveComparer();
        }

        //this method works through the listView column items and reorders 
        //either A-Z or Z-A based upon if previously sorted.
        public int Compare(object x, object y)
        {
            int sortedValue = String.Compare(((ListViewItem)x).SubItems[columnToSort].Text,
                ((ListViewItem)y).SubItems[columnToSort].Text);
            if (orderOfSort == SortOrder.Ascending)
            {
                return sortedValue; //A-Z sorting
            }
            else
            {
                return (-sortedValue); //Z-A sorting
            }
        }
        // Gets or sets the number of the column to which to apply the sorting operation (Defaults to '0').
        public int SortColumn
        {
            set { columnToSort = value; }
            get { return columnToSort; }
        }

        // Gets or sets the order of sorting to apply (for example, 'Ascending' or 'Descending').
        public SortOrder Order
        {
            set { orderOfSort = value; }
            get { return orderOfSort; }
        }
        //method which passes the listViewSortOrder object and tests if the selected column is the previously selected column
        public void checkPreviousOrder(int testClickColumn)
        {
            // Determine if clicked column is already the column that is being sorted.
            if (testClickColumn == this.SortColumn)
            {
                // Reverse the current sort direction for this column.
                if (this.Order == SortOrder.Ascending)
                {
                    this.Order = SortOrder.Descending;
                }
                else
                {
                    this.Order = SortOrder.Ascending;
                }
            }
            else
            {
                // Set the column number that is to be sorted; default to ascending.
                this.SortColumn = testClickColumn;
                this.Order = SortOrder.Ascending;
            }
        }
    }
}
