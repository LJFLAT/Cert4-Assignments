﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using LMS_OC.DataAccessLayer;
using System.Windows.Forms;

//Class designed by OpenColleges Copyright 2013 (Based upon earliest record in the original database)
//Modifications to the original code by Tiama Investments Pty Ltd (ABN 93 085 303 260) 
namespace LMS_OC.BusinessLogicLayer
{
    public class Student
    {
        private int _studentID;
        private string _firstName, _lastName, _address1, _address2, _suburb, _state, _email, _contactNo;
        private int _postCode;
        private double _fine;
        
        public Student() { }
        
        public Student(int studentID,string firstName,string lastName,string address1,string address2,
            string suburb,string state,int postCode,string email,string contactNumber,double finePenalty)
        {
            this._studentID = studentID;
            this._firstName = firstName;
            this._lastName = lastName;
            this._address1 = address1;
            this._address2 = address2;
            this._suburb = suburb;
            this._state = state;
            this._postCode = postCode;
            this._email = email;
            this._contactNo = contactNumber;
            this._fine = finePenalty;
        }
        public int StudentID
        {
            get { return _studentID; }
            set { _studentID = value; }
        }
        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }
        public string Address1
        {
            get { return _address1; }
            set { _address1 = value; }
        }
        public string Address2
        {
            get { return _address2; }
            set { _address2 = value; }
        }
        public string Suburb
        {
            get { return _suburb; }
            set { _suburb = value; }
        }
        public string State
        {
            get { return _state; }
            set { _state = value; }
        }
        public int PostCode
        {
            get { return _postCode; }
            set { _postCode = value; }
        }
        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        public string ContactNumber
        {
            get { return _contactNo; }
            set { _contactNo = value; }
        }
        public double Fine
        {
            get { return _fine; }
            set { _fine = value; }
        }

        public string FilteredStudentSQL()
        {
            string selectQuery = "SELECT * FROM Student";

            //Checks is filter is set and uses Search / Filter criteria to create a query
            if (GlobalVariables.StudentFilterSet())
            {
                selectQuery += " WHERE ";
                if (GlobalVariables.StudentLastName.Length > 0)
                {
                    selectQuery += "lastName LIKE ('%" + GlobalVariables.StudentLastName + "%')";
                }
                if (GlobalVariables.StudentPostCode.Length > 0)
                {
                    AddAnd(GlobalVariables.StudentLastName, selectQuery);
                    selectQuery += "postCode LIKE ('%" + int.Parse(GlobalVariables.StudentPostCode) + "%')";
                }
                if (GlobalVariables.StudentSuburb.Length > 0)
                {
                    AddAnd(GlobalVariables.StudentLastName + GlobalVariables.StudentPostCode, selectQuery);
                    selectQuery += "suburb LIKE ('%" + GlobalVariables.StudentSuburb + "%')";
                }
            }
            selectQuery += " ORDER BY studentID";

            return selectQuery;
        }

        public int StudentAddModify()
        {
            //This code stores new / modified student information
            SqlConnection connection = ConnectionManager.DBConnection();
            SqlCommand command = new SqlCommand();
            string commandText = "";

            if (this.StudentID == 0)
            {
                string determineNewStudentID = "SELECT MAX(studentID) FROM Student";
                command.CommandText = determineNewStudentID;
                command.Connection = connection;
                connection.Open();

                //Determine the maximum studentID # - Code suggestion from 
                //https://stackoverflow.com/questions/9245197/maxid-using-sqldatareader-c-sharp
                //returns the first record
                int studentMaxID = Convert.ToInt32(command.ExecuteScalar());

                if (studentMaxID == 0)
                {
                    studentMaxID = 1001; //Used for the first student data entered
                }
                else
                {
                    studentMaxID += 1; //Adds 1 to the largest studentID found in the database
                }
                connection.Close();

                commandText = "INSERT INTO Student VALUES (" + studentMaxID + ",'" + this.FirstName + "','" + this.LastName + "','"
                + this.Address1 + "','" + this.Address2 + "','" + this.Suburb + "','" + this.State + "'," + this.PostCode + ",'" 
                + this.Email + "','" + this.ContactNumber + "'," + this.Fine + ")";
            }
            else
            {
                commandText = "UPDATE Student SET firstName='" + this.FirstName + "',lastName='" + this.LastName
                + "',address1='" + this.Address1 + "',address2='" + this.Address2 + "',suburb='" + this.Suburb + "',state='"
                + this.State + "',postCode=" + this.PostCode + ",email='" + this.Email + "', contactNo='"
                + this.ContactNumber + "' WHERE studentID=" + this.StudentID + "";
            }

            try
            {
                command.CommandText = commandText;
                command.Connection = connection;
                connection.Open();
                command.Transaction = connection.BeginTransaction();
                int recordCount = command.ExecuteNonQuery();
                command.Transaction.Commit();
                connection.Close();
                return recordCount;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Saving to the database failed. Please contact database admin for assistance.\nError Message: " 
                    + ex);
            }
            return 0;
        }

        // places an AND within the sql filter statement of the WHERE clause
        private void AddAnd(string checkItemLength, string selectQuery)
        {
            if (checkItemLength.Length > 0)
            {
                selectQuery += " AND ";
            }
            return;
        }
    }
}
