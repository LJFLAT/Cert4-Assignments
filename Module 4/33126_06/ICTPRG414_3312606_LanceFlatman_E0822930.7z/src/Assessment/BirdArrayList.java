package Assessment;
import javax.swing.JOptionPane;
import java.util.*;
/**
 * This is a class that stores a list of bird names and 
 * @author Lance Flatman
 * @version 1.0
 */
public class BirdArrayList {

	/**
	 * Allows the user to Add, Remove, Search and Display items within the BirdArrayList class.
	 * @param args none
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/** The response variable is used in the Menu System */
		char response = ' ';
		
		/** birdList is an ArrayList which stores bird names */
		ArrayList<String> birdList = new ArrayList<String>();
		birdList.add("Emu");
		birdList.add("Duck");
		birdList.add("Black Cockatoo");
		birdList.add("Sparrow");
		birdList.add("Gallah");

		// After the above information is added into the birdList ArrayList, under normal circumstances
		// I would suggest doing the sortArray() Method to ensure all the names are in alphabetical order when the program starts up.
		
		// I have included a display of the birdList at the start so the user can see what birds are on the list initially.
		displayArray(birdList);
		
		/**
		 * Menu Section Options:
		 *   (A) for Adding a bird to the birdList
		 *   (R) for Removing a bird from the birdList
		 *   (S) to Search for a bird within the birdList
		 *   (D) to Display the birds within the birdList
		 *   (Q) to Quit the program
		 */
		try
		{
			do 
			{
				String answer = JOptionPane.showInputDialog(null, "Please make a selection from the following \n  (A)dd a new bird name \n  (R)emove a bird from the list"
						+ "\n  (S)earch for a bird name \n  (D)isplay the bird name list \n  (Q)uit the program", "Select a Menu Item", JOptionPane.QUESTION_MESSAGE);
				if(answer.length() == 0)
					answer = " ";
				response = answer.toUpperCase().charAt(0);
				if(response == 'A')
					addEntry(birdList);
				else if(response == 'R')
					deleteEntry(birdList);
				else if(response == 'S')
					searchArray(birdList);
				else if(response == 'D')
					displayArray(birdList);
				else if(response == 'Q')
					;
				else
					JOptionPane.showMessageDialog(null, "Not a valid selection. Please press a key and try again.");
			} while(response != 'Q');
		}
		catch(Exception e)
		{
			System.out.println("Exception error: " + e);
		}
	}
	
	/** 
	 * Method which adds a bird name to the birdList array
	 * 
	 * @param birdList type ArrayList
	 */
	public static void addEntry(ArrayList<String> birdList)
	{
		String newName = JOptionPane.showInputDialog(null, "Please enter the name of the bird you wish to add to the list?");
		if(newName.isEmpty() == false && newName.charAt(0) != ' ')	// doesn't allow for the entry of a empty response.
			birdList.add(newName);
		displayArray(birdList);
	}
	
	/**
	 * Method which deletes a bird name from the birdList array
	 * 
	 * @param birdList type ArrayList
	 */
	public static void deleteEntry(ArrayList<String> birdList)
	{
		String deleteName = JOptionPane.showInputDialog(null, "Please enter the name of bird you wish to delete from the list?");
		int elements = birdList.size();
		boolean itemFound = false;
		for(int x = 0; x < elements; ++x)
		{
			if(birdList.get(x).equals(deleteName))
			{
				itemFound = true;
				int response = JOptionPane.showConfirmDialog(null, deleteName + " has been found in the list. Do you wish to delete?", "Confirm Delete",
						JOptionPane.YES_NO_OPTION);
				if(response == JOptionPane.YES_OPTION)
				{
					birdList.remove(x);
					JOptionPane.showMessageDialog(null, deleteName + " has been removed from the list.");
					x = elements;
				}
			}
		}
		if (!itemFound)
			JOptionPane.showMessageDialog(null, deleteName + " hasn't been found in the list.");
		displayArray(birdList);
	}
	
	// The searchArray Method is based upon information provided at
	// https://www.tutorialspoint.com/data_structures_algorithms/binary_search_algorithm.htm
	
	/**
	 * Method which allows the user to search the birdList array
	 * 
	 * @param birdList type ArrayList
	 */
	public static void searchArray(ArrayList<String> birdList)
	{
		int low = 0, high = birdList.size() - 1, mid = (high + low) / 2;
		String currentBird, searchValue;
		sortArray(birdList);
		
		searchValue = JOptionPane.showInputDialog(null, "Please enter the name of bird you wish to search for within the list?");
		
		boolean loopTrue = true, birdFound = false;
		do
		{
			mid = (high + low) / 2;
			currentBird = birdList.get(mid);
			if(currentBird.equals(searchValue))
			{
				birdFound = true;
				loopTrue = false;
			}
			else if(searchValue.compareTo(currentBird) < 0)
				high = mid - 1;
			else if(searchValue.compareTo(currentBird) > 0)
				low = mid + 1;
			if(low == high)
			{
				mid = low;
				if(birdList.get(low).equals(searchValue))
					birdFound = true;
				loopTrue = false;
			}
			
		} while(loopTrue);
		
		if(birdFound)
			JOptionPane.showMessageDialog(null, searchValue + " has been located at array index " + mid);
		else
			JOptionPane.showMessageDialog(null, searchValue + " has not been located. Please try again.");		
	}

	/**
	 * Method which sorts the bird names within the birdList array
	 * 
	 * @param birdList type ArrayList
	 */
	public static void sortArray(ArrayList<String> birdList)
	{
		birdList.sort(null);		
	}
	
	/**
	 * Method which displays the list of bird names from the birdList array.
	 * This is a separate Method as it is called multiple times from other Methods.
	 * 
	 * @param birdList type ArrayList
	 */
	public static void displayArray(ArrayList<String> birdList)
	{
		int elements = birdList.size();
		
		System.out.println("List of bird names:");
		
		if(elements != 0)
		{
			for(int x = 0; x < elements; ++x)
			{
				System.out.println(" - " + birdList.get(x));
			}
			System.out.println("Total items in list: " + elements);
		}
		else
			System.out.println("   List is empty");
		System.out.println();
	}
}